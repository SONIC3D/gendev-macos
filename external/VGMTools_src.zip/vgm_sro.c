// vgm_sro.c - VGM Sample-ROM Optimizer
//

#include <stdio.h>
#include <stdlib.h>
#include "stdbool.h"
#include <string.h>

#ifdef WIN32
#include <conio.h>
#include <windows.h>	// for GetTickCount
#endif

#include "zlib.h"

#include "stdtype.h"
#include "VGMFile.h"


static bool OpenVGMFile(const char* FileName);
static void WriteVGMFile(const char* FileName);
static void FindUsedROMData(void);
static void EnumerateROMRegions(void);
static void OptimizeVGMSampleROM(void);
static UINT8 GetRomRgnFromType(UINT8 ROMType);
static void PrintMinSec(const UINT32 SamplePos, char* TempStr);


void InitAllChips(void);
void FreeAllChips(void);
void SetChipSet(UINT8 ChipID);
void segapcm_mem_write(UINT16 Offset, UINT8 Data);
void ym2608_write(UINT8 Port, UINT8 Register, UINT8 Data);
void ym2610_write(UINT8 Port, UINT8 Register, UINT8 Data);
void y8950_write(UINT8 Register, UINT8 Data);
void ymz280b_write(UINT8 Register, UINT8 Data);
void rf5c68_write(UINT8 Register, UINT8 Data);
void rf5c164_write(UINT8 Register, UINT8 Data);
void ymf271_write(UINT8 Port, UINT8 Register, UINT8 Data);
void write_rom_data(UINT8 ROMType, UINT32 ROMSize, UINT32 DataStart, UINT32 DataLength,
					UINT8* ROMData);
UINT32 GetROMMask(UINT8 ROMType, UINT8** MaskData);
UINT32 GetROMData(UINT8 ROMType, UINT8** ROMData);


typedef struct rom_region
{
	UINT32 AddrStart;
	UINT32 AddrEnd;
} ROM_REGION;
typedef struct rom_region_list
{
	UINT32 RegionCount;
	ROM_REGION* Regions;
	bool IsWritten;
} ROM_RGN_LIST;


#define ROM_TYPES	0x09
const UINT8 ROM_LIST[ROM_TYPES] =
	{0x80, 0x81, 0x82, 0x83, 0x85, 0x86, 0x88, 0xC0, 0xC1};


VGM_HEADER VGMHead;
UINT32 VGMDataLen;
UINT8* VGMData;
UINT32 VGMPos;
INT32 VGMSmplPos;
ROM_RGN_LIST ROMRgnLst[ROM_TYPES];
UINT8* DstData;
UINT32 DstDataLen;
char FileBase[0x100];
bool CancelFlag;

int main(int argc, char* argv[])
{
	int ErrVal;
	char FileName[0x100];
	UINT8 CurROM;
	
	printf("VGM Sample-ROM Optimizer\n------------------------\n\n");
	
	ErrVal = 0;
	printf("File Name:\t");
	if (argc <= 0x01)
	{
		gets(FileName);
	}
	else
	{
		strcpy(FileName, argv[0x01]);
		printf("%s\n", FileName);
	}
	if (! strlen(FileName))
		return 1;
	
	if (! OpenVGMFile(FileName))
	{
		printf("Error opening the file!\n");
		ErrVal = 1;
		goto EndProgram;
	}
	printf("\n");
	
	DstData = NULL;
	if (! VGMHead.lngHzSPCM && ! VGMHead.lngHzYM2608 && ! VGMHead.lngHzYM2610 &&
		! VGMHead.lngHzY8950 && ! VGMHead.lngHzYMZ280B && ! VGMHead.lngHzRF5C68 &&
		! VGMHead.lngHzRF5C164 && ! VGMHead.lngHzYMF271)
	{
		printf("No chips with Sample-ROM used!\n");
		ErrVal = 2;
		goto BreakProgress;
	}
	
	CancelFlag = false;
	FindUsedROMData();
	if (CancelFlag)
	{
		ErrVal = 9;
		goto BreakProgress;
	}
	EnumerateROMRegions();
	OptimizeVGMSampleROM();
	
	if (argc > 0x02)
		strcpy(FileName, argv[0x02]);
	else
		strcpy(FileName, "");
	if (! FileName[0x00])
	{
		strcpy(FileName, FileBase);
		strcat(FileName, "_optimized.vgm");
	}
	WriteVGMFile(FileName);
	
BreakProgress:
	free(VGMData);
	free(DstData);
	for (CurROM = 0x00; CurROM < ROM_TYPES; CurROM ++)
		free(ROMRgnLst[CurROM].Regions);
	
EndProgram:
#ifdef WIN32
	if (argv[0][1] == ':')
	{
		// Executed by Double-Clicking (or Drap and Drop)
		if (_kbhit())
			_getch();
		_getch();
	}
#endif
	
	return ErrVal;
}

static bool OpenVGMFile(const char* FileName)
{
	gzFile hFile;
	UINT32 CurPos;
	UINT32 TempLng;
	char* TempPnt;
	
	hFile = gzopen(FileName, "rb");
	if (hFile == NULL)
		return false;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &TempLng, 0x04);
	if (TempLng != FCC_VGM)
		goto OpenErr;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &VGMHead, sizeof(VGM_HEADER));
	
	// Header preperations
	if (VGMHead.lngVersion < 0x00000150)
	{
		VGMHead.lngDataOffset = 0x00000000;
	}
	if (VGMHead.lngVersion < 0x00000151)
	{
		VGMHead.lngHzSPCM = 0x0000;
		VGMHead.lngSPCMIntf = 0x00000000;
		// all others are zeroed by memset
	}
	// relative -> absolute addresses
	VGMHead.lngEOFOffset += 0x00000004;
	if (VGMHead.lngGD3Offset)
		VGMHead.lngGD3Offset += 0x00000014;
	if (VGMHead.lngLoopOffset)
		VGMHead.lngLoopOffset += 0x0000001C;
	if (! VGMHead.lngDataOffset)
		VGMHead.lngDataOffset = 0x0000000C;
	VGMHead.lngDataOffset += 0x00000034;
	
	CurPos = VGMHead.lngDataOffset;
	if (VGMHead.lngVersion < 0x00000150)
		CurPos = 0x40;
	TempLng = sizeof(VGM_HEADER);
	if (TempLng > CurPos)
		TempLng -= CurPos;
	else
		TempLng = 0x00;
	memset((UINT8*)&VGMHead + CurPos, 0x00, TempLng);
	
	// Read Data
	VGMDataLen = VGMHead.lngEOFOffset;
	VGMData = (UINT8*)malloc(VGMDataLen);
	if (VGMData == NULL)
		goto OpenErr;
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, VGMData, VGMDataLen);
	
	gzclose(hFile);
	
	strcpy(FileBase, FileName);
	TempPnt = strrchr(FileBase, '.');
	if (TempPnt != NULL)
		*TempPnt = 0x00;
	
	return true;

OpenErr:

	gzclose(hFile);
	return false;
}

static void WriteVGMFile(const char* FileName)
{
	FILE* hFile;
	
	hFile = fopen(FileName, "wb");
	fwrite(DstData, 0x01, DstDataLen, hFile);
	fclose(hFile);
	
	printf("File written.\n");
	
	return;
}

static void FindUsedROMData(void)
{
	UINT32 CmdTimer;
	UINT8 ChipID;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 ROMSize;
	UINT32 DataStart;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	
	printf("Creating ROM-Usage Mask ...\n");
	VGMPos = VGMHead.lngDataOffset;
	
	CmdTimer = 0;
	InitAllChips();
	StopVGM = false;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			// Cheat Mode (to use 2 instances of 1 chip)
			ChipID = 0x00;
			switch(Command)
			{
			case 0x30:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x20;
					ChipID = 0x01;
				}
				break;
			case 0x3F:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x10;
					ChipID = 0x01;
				}
				break;
			case 0xA1:
				if (VGMHead.lngHzYM2413 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA2:
			case 0xA3:
				if (VGMHead.lngHzYM2612 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA4:
				if (VGMHead.lngHzYM2151 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA5:
				if (VGMHead.lngHzYM2203 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA6:
			case 0xA7:
				if (VGMHead.lngHzYM2608 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA8:
			case 0xA9:
				if (VGMHead.lngHzYM2610 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAA:
				if (VGMHead.lngHzYM3812 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAB:
				if (VGMHead.lngHzYM3526 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAC:
				if (VGMHead.lngHzY8950 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAE:
			case 0xAF:
				if (VGMHead.lngHzYMF262 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAD:
				if (VGMHead.lngHzYMZ280B & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			}
			SetChipSet(ChipID);
			
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&TempLng, &VGMData[VGMPos + 0x03], 0x04);
				
				switch(TempByt & 0xC0)
				{
				case 0x00:	// Database Block
				case 0x40:
					/*switch(TempByt)
					{
					case 0x00:	// YM2612 PCM Database
						break;
					case 0x01:	// RF5C68 PCM Database
						break;
					case 0x02:	// RF5C164 PCM Database
						break;
					}*/
					break;
				case 0x80:	// ROM/RAM Dump
					memcpy(&ROMSize, &VGMData[VGMPos + 0x07], 0x04);
					memcpy(&DataStart, &VGMData[VGMPos + 0x0B], 0x04);
					DataLen = TempLng - 0x08;
					write_rom_data(TempByt, ROMSize, DataStart, DataLen,
									&VGMData[VGMPos + 0x0F]);
					break;
				case 0xC0:	// RAM Write
					memcpy(&TempSht, &VGMData[VGMPos + 0x07], 0x02);
					DataLen = TempLng - 0x02;
					write_rom_data(TempByt, 0x00, TempSht, DataLen, &VGMData[VGMPos + 0x09]);
					break;
				}
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				segapcm_mem_write(TempSht, VGMData[VGMPos + 0x03]);
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
				// PCM, but doesn't have ROM - but RAM
				rf5c68_write(VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
				printf("RF5Cxx Memory Write aren't supported.\n");
				CancelFlag = true;
				StopVGM = true;
				CmdLen = 0x04;
				break;
			case 0x55:	// YM2203
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				ym2608_write(Command & 0x01, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				ym2610_write(Command & 0x01, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				y8950_write(VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				ymz280b_write(VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0xD0:	// YMF278B write
				//chip_reg_write(0x0D, CurChip, VGMData[VGMPos + 0x01],
				//				VGMData[VGMPos + 0x02], VGMData[VGMPos + 0x03]);
				CmdLen = 0x04;
				break;
			case 0xD1:	// YMF271 write
				ymf271_write(VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02],
							VGMData[VGMPos + 0x03]);
				CmdLen = 0x04;
				break;
			case 0xB1:	// RF5C164 register write
				rf5c164_write(VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				CmdLen = 0x03;
				break;
			case 0xC2:	// RF5C164 memory write
				printf("RF5Cxx Memory Write aren't supported.\n");
				CancelFlag = true;
				StopVGM = true;
				CmdLen = 0x04;
				break;
			case 0xB2:	// PWM channel write
				CmdLen = 0x03;
				break;
			case 0x68:	// PCM RAM write
				printf("Streamed RF-PCM-Data can't be optimized.\n");
				CancelFlag = true;
				StopVGM = true;
				CmdLen = 0x0C;
				break;
			case 0xA0:	// AY8910 write
				CmdLen = 0x03;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			ROMSize = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / ROMSize * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	printf("\t\t\t\t\t\t\t\t\r");
		
	return;
}

static void EnumerateROMRegions(void)
{
	const char* STATUS_TEXT[] = {"unused", "USED", "Empty", "Empty/USED"};
	UINT8 CurROM;
	UINT32 ROMSize;
	UINT8* ROMMask;
	ROM_RGN_LIST* TempRRL;
	UINT32 RgnMemCount;
	ROM_REGION* RgnMemory;
	UINT32 CurRgn;
	UINT32 CurPos;
	UINT32 PosStart;
	UINT8 MaskVal;
	
	RgnMemCount = 0x100;
	RgnMemory = (ROM_REGION*)malloc(RgnMemCount * sizeof(ROM_REGION));
	
	printf("\nROM Region List\n---------------\n");
	printf("From\tTo\tLength\tStatus\n");
	for (CurROM = 0x00; CurROM < ROM_TYPES; CurROM ++)
	{
		TempRRL = &ROMRgnLst[CurROM];
		
		TempRRL->RegionCount = 0x00;
		
		ROMSize = GetROMMask(ROM_LIST[CurROM], &ROMMask);
		if (! ROMSize || ROMMask == NULL)
			continue;
		
		switch(ROM_LIST[CurROM])
		{
		case 0x80:	// SegaPCM ROM
			printf("  SegaPCM\n");
			break;
		case 0x81:	// YM2608 DELTA-T ROM
			printf("  YM2608 DELTA-T\n");
			break;
		case 0x82:	// YM2610 ADPCM ROM
			printf("  YM2610 ADPCM\n");
			break;
		case 0x83:	// YM2610 DELTA-T ROM
			printf("  YM2610 DELTA-T\n");
			break;
		case 0x85:	// YMF271 ROM
			printf("  YMF271\n");
			break;
		case 0x86:	// YMZ280B ROM
			printf("  YMZ280B\n");
			break;
		case 0x88:	// Y8950 DELTA-T ROM
			printf("  Y8950 DELTA-T\n");
			break;
		case 0xC0:	// RF5C68 RAM
			printf("  RF5C68\n");
			break;
		case 0xC1:	// RF5C164 RAM
			printf("  RF5C164\n");
			break;
		}
		
		CurRgn = 0x00;
		RgnMemory[CurRgn].AddrStart = 0xFFFFFFFF;
		PosStart = 0x00;
		MaskVal = ROMMask[0x00];
		for (CurPos = 0x01; CurPos <= ROMSize; CurPos ++)
		{
			if (CurPos >= ROMSize || MaskVal != ROMMask[CurPos])
			{
				printf("%06lX\t%06lX\t%6lX\t%s\n", PosStart, CurPos - 1, CurPos - PosStart,
						STATUS_TEXT[MaskVal]);
				
				if (MaskVal == 0x01)
				{
					if (! CurRgn)
					{
						if (PosStart < 0x20)
							PosStart = 0x00;
					}
					else
					{
						if ((PosStart - RgnMemory[CurRgn - 0x01].AddrEnd) < 0x20)
							CurRgn --;
					}
				}
				if (MaskVal == 0x01)	// (MaskVal & 0x01) would also write empty (used) blocks
				{
					// Used ROM Data
					if (RgnMemory[CurRgn].AddrStart == 0xFFFFFFFF)
						RgnMemory[CurRgn].AddrStart = PosStart;	// Set Address if not already set
					RgnMemory[CurRgn].AddrEnd = CurPos;
					CurRgn ++;
					if (CurRgn >= RgnMemCount)
					{	// I really don't expect this, but I want to be safe
						RgnMemCount += 0x100;
						RgnMemory = (ROM_REGION*)realloc(RgnMemory,
														RgnMemCount * sizeof(ROM_REGION));
					}
					RgnMemory[CurRgn].AddrStart = 0xFFFFFFFF;
				}
				
				if (CurPos < ROMSize)
					MaskVal = ROMMask[CurPos];
				PosStart = CurPos;
			}
		}
		
		if (! CurRgn)
		{
			// to make sure that the ROM is at least allocated,
			// an empty region is created
			RgnMemory[CurRgn].AddrStart = 0x00;
			RgnMemory[CurRgn].AddrEnd = 0x00;
			CurRgn ++;
		}
		
		TempRRL->RegionCount = CurRgn;
		TempRRL->Regions = (ROM_REGION*)malloc(TempRRL->RegionCount * sizeof(ROM_REGION));
		for (CurRgn = 0x00; CurRgn < TempRRL->RegionCount; CurRgn ++)
			TempRRL->Regions[CurRgn] = RgnMemory[CurRgn];
		TempRRL->IsWritten = false;
	}
	
	free(RgnMemory);
	return;
}

static void OptimizeVGMSampleROM(void)
{
	UINT32 DstPos;
	UINT32 CmdTimer;
	UINT8 ChipID;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 ROMSize;
	UINT32 DataStart;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	bool WriteEvent;
	UINT32 NewLoopS;
	UINT8* ROMData;
	UINT8 CurRgn;
	ROM_RGN_LIST* TempRRL;
	ROM_REGION* TempRgn;
	
	DstData = (UINT8*)malloc(VGMDataLen + 0x100);
	VGMPos = VGMHead.lngDataOffset;
	DstPos = VGMHead.lngDataOffset;
	NewLoopS = 0x00;
	memcpy(DstData, VGMData, VGMPos);	// Copy Header
	
	CmdTimer = 0;
	SetChipSet(0x00);
	StopVGM = false;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		WriteEvent = true;
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			// Cheat Mode (to use 2 instances of 1 chip)
			ChipID = 0x00;
			switch(Command)
			{
			case 0x30:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x20;
					ChipID = 0x01;
				}
				break;
			case 0x3F:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x10;
					ChipID = 0x01;
				}
				break;
			case 0xA1:
				if (VGMHead.lngHzYM2413 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA2:
			case 0xA3:
				if (VGMHead.lngHzYM2612 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA4:
				if (VGMHead.lngHzYM2151 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA5:
				if (VGMHead.lngHzYM2203 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA6:
			case 0xA7:
				if (VGMHead.lngHzYM2608 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA8:
			case 0xA9:
				if (VGMHead.lngHzYM2610 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAA:
				if (VGMHead.lngHzYM3812 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAB:
				if (VGMHead.lngHzYM3526 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAC:
				if (VGMHead.lngHzY8950 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAE:
			case 0xAF:
				if (VGMHead.lngHzYMF262 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAD:
				if (VGMHead.lngHzYMZ280B & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			}
			SetChipSet(ChipID);
			
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&TempLng, &VGMData[VGMPos + 0x03], 0x04);
				
				switch(TempByt & 0xC0)
				{
				case 0x00:	// Database Block
				case 0x40:
					/*switch(TempByt)
					{
					case 0x00:	// YM2612 PCM Database
						break;
					case 0x01:	// RF5C68 PCM Database
						break;
					case 0x02:	// RF5C164 PCM Database
						break;
					}*/
					break;
				case 0x80:	// ROM/RAM Dump
					//memcpy(&ROMSize, &VGMData[VGMPos + 0x07], 0x04);
					//memcpy(&DataStart, &VGMData[VGMPos + 0x0B], 0x04);
					//DataLen = TempLng - 0x08;
					//ROMData = &VGMData[VGMPos + 0x0F];
					ROMSize = GetROMData(TempByt, &ROMData);
					TempRRL = &ROMRgnLst[GetRomRgnFromType(TempByt)];
					if (! TempRRL->IsWritten)
					{
						for (CurRgn = 0x00; CurRgn < TempRRL->RegionCount; CurRgn ++)
						{
							TempRgn = &TempRRL->Regions[CurRgn];
							DataLen = TempRgn->AddrEnd - TempRgn->AddrStart;
							// Note: There are empty ROM Blocks to set the ROM Size
							CmdLen = 0x08 + DataLen;
							DataStart = TempRgn->AddrStart;
							
							DstData[DstPos + 0x00] = 0x67;
							DstData[DstPos + 0x01] = 0x66;
							DstData[DstPos + 0x02] = TempByt;
							memcpy(&DstData[DstPos + 0x03], &CmdLen, 0x04);
							memcpy(&DstData[DstPos + 0x07], &ROMSize, 0x04);
							memcpy(&DstData[DstPos + 0x0B], &DataStart, 0x04);
							memcpy(&DstData[DstPos + 0x0F], &ROMData[DataStart], DataLen);
							DstPos += 0x07 + CmdLen;
						}
						TempRRL->IsWritten = true;
					}
					WriteEvent = false;
					break;
				case 0xC0:	// RAM Write
					ROMSize = GetROMData(TempByt, &ROMData);
					TempRRL = &ROMRgnLst[GetRomRgnFromType(TempByt)];
					if (! TempRRL->IsWritten)
					{
						for (CurRgn = 0x00; CurRgn < TempRRL->RegionCount; CurRgn ++)
						{
							TempRgn = &TempRRL->Regions[CurRgn];
							DataLen = TempRgn->AddrEnd - TempRgn->AddrStart;
							if (! DataLen)	// empty RAM write make no sense, since the RAM
								continue;	// Size isn't changeable
							CmdLen = 0x02 + DataLen;
							TempSht = TempRgn->AddrStart & 0xFFFF;
							
							DstData[DstPos + 0x00] = 0x67;
							DstData[DstPos + 0x01] = 0x66;
							DstData[DstPos + 0x02] = TempByt;
							memcpy(&DstData[DstPos + 0x03], &CmdLen, 0x04);
							memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
							memcpy(&DstData[DstPos + 0x09], &ROMData[TempSht], DataLen);
							DstPos += 0x07 + CmdLen;
						}
						TempRRL->IsWritten = true;
					}
					WriteEvent = false;
					break;
				}
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
				CmdLen = 0x04;
				break;
			case 0x55:	// YM2203
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				CmdLen = 0x03;
				break;
			case 0xD0:	// YMF278B write
				CmdLen = 0x04;
				break;
			case 0xD1:	// YMF271 write
				CmdLen = 0x04;
				break;
			case 0xB1:	// RF5C164 register write
				CmdLen = 0x03;
				break;
			case 0xC2:	// RF5C164 memory write
				CmdLen = 0x04;
				break;
			case 0xB2:	// PWM channel write
				CmdLen = 0x03;
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			case 0xA0:	// AY8910 write
				CmdLen = 0x03;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		if (WriteEvent)
		{
			if (VGMPos == VGMHead.lngLoopOffset)
				NewLoopS = DstPos;
			memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
			DstPos += CmdLen;
		}
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			ROMSize = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / ROMSize * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	if (VGMHead.lngLoopOffset)
	{
		TempLng = NewLoopS - 0x1C;
		memcpy(&DstData[0x1C], &TempLng, 0x04);
	}
	printf("\t\t\t\t\t\t\t\t\r");
	
	if (VGMHead.lngGD3Offset)
	{
		VGMPos = VGMHead.lngGD3Offset;
		memcpy(&TempLng, &VGMData[VGMPos + 0x00], 0x04);
		if (TempLng == FCC_GD3)
		{
			memcpy(&CmdLen, &VGMData[VGMPos + 0x08], 0x04);
			CmdLen += 0x0C;
			
			TempLng = DstPos - 0x14;
			memcpy(&DstData[0x14], &TempLng, 0x04);
			memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
			DstPos += CmdLen;
		}
	}
	DstDataLen = DstPos;
	TempLng = DstDataLen - 0x04;
	memcpy(&DstData[0x04], &TempLng, 0x04);
	
	FreeAllChips();
	
	return;
}

static UINT8 GetRomRgnFromType(UINT8 ROMType)
{
	UINT8 CurType;
	
	for (CurType = 0x00; CurType < ROM_TYPES; CurType ++)
	{
		if (ROM_LIST[CurType] == ROMType)
			return CurType;
	}
	
	return 0x00;
}

static void PrintMinSec(const UINT32 SamplePos, char* TempStr)
{
	float TimeSec;
	UINT16 TimeMin;
	
	TimeSec = (float)SamplePos / (float)44100.0;
	TimeMin = (UINT16)TimeSec / 60;
	TimeSec -= TimeMin * 60;
	sprintf(TempStr, "%02hu:%05.2f", TimeMin, TimeSec);
	
	return;
}
