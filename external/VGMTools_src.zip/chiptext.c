// this file generates text lines form chip writes

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "stdbool.h"

#include "stdtype.h"

#define INLINE	__inline


typedef struct chip_count
{
	UINT32 SN76496;
	UINT32 YM2413;
	UINT32 YM2612;
	UINT32 YM2151;
	UINT32 SegaPCM;
	UINT32 RF5C68;
	UINT32 YM2203;
	UINT32 YM2608;
	UINT32 YM2610;
	UINT32 YM3812;
	UINT32 YM3526;
	UINT32 Y8950;
	UINT32 YMF262;
	UINT32 YMF278B;
	UINT32 YMF271;
	UINT32 YMZ280B;
	UINT32 RF5C164;
	UINT32 PWM;
	UINT32 AY8910;
	UINT32 GBDMG;
	UINT32 NESAPU;
} CHIP_CNT;


const char* ONOFF_STR[0x02] = {"On", "Off"};
const char* ENABLE_STRS[0x02] = {"Enable", "Disable"};
const char* NOTE_STRS[0x0C] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};

const char* T6W28_PORT[0x02] = {"L/T", "R/N"};
const char* SN76496_NOISE_TYPE[0x04] = {"Periodic", "White"};
const char* SN76496_NOISE_FREQ[0x04] = {"High (6927Hz)", "Med (3463Hz)", "Low (1731Hz)", "Ch 2"};
const char* YM2413_INS_NAMES[0x10] = {"User instrument", "Violin", "Guitar", "Piano", "Flute",
	"Clarinet", "Oboe", "Trumpet", "Organ", "Horn", "Synthesizer", "Harpsichord",
	"Vibraphone", "Synthesizer Bass", "Acoustic Bass", "Electric Guitar"};
const char* YM2413_RHYTHM_NAMES[0x05] = {"High Hat", "Cymbal", "Tom-Tom", "Snare Drum",
	"Bass Drum"};
const char* YM2151_WAVE_FORM[0x04] = {"Sawtooth", "Square", "Triangle", "Random Noise"};
const UINT32 dt2_tab[0x04] = {0, 384, 500, 608};
const char* YMZ280B_MODES[0x04] = {"Unknown", "ADPCM", "PCM8", "PCM16"};

const char* OPN_LFOFreqs[0x08]= {"3.98", "5.56", "6.02", "6.37", "6.88", "9.63", "48.1", "72.2"};
const double PI = 3.1415926535897932;
//const double PI_HLF = PI / 2;

const char* PWM_PORTS[0x06] = {"Control Reg", "Cycle Reg", "Left Ch", "Right Ch", "Both Ch", "Invalid"};

const char* ADDR_2S_STR[0x02] = {"Low", "High"};
const char* ADDR_3S_STR[0x03] = {"Low", "Mid", "High"};


#define OPN_TYPE_SSG	0x01	// SSG support
#define OPN_TYPE_LFOPAN	0x02	// OPN type LFO and PAN
#define OPN_TYPE_6CH	0x04	// FM 6CH / 3CH
#define OPN_TYPE_DAC	0x08	// YM2612's DAC device
#define OPN_TYPE_ADPCM	0x10	// two ADPCM units
#define OPN_TYPE_2610	0x20	// bogus flag to differentiate 2608 from 2610

#define OPN_TYPE_YM2203 (OPN_TYPE_SSG)
#define OPN_TYPE_YM2608 (OPN_TYPE_SSG | OPN_TYPE_LFOPAN | OPN_TYPE_6CH | OPN_TYPE_ADPCM)
#define OPN_TYPE_YM2610 (OPN_TYPE_SSG | OPN_TYPE_LFOPAN | OPN_TYPE_6CH | OPN_TYPE_ADPCM | OPN_TYPE_2610)
#define OPN_TYPE_YM2612 (OPN_TYPE_DAC | OPN_TYPE_LFOPAN | OPN_TYPE_6CH)

#define OPN_YM2203 0x00
#define OPN_YM2608 0x01
#define OPN_YM2610 0x02
#define OPN_YM2612 0x03
const char FMOPN_TYPES[0x04] = {OPN_TYPE_YM2203, OPN_TYPE_YM2608, OPN_TYPE_YM2610,
								OPN_TYPE_YM2612};


#define OPL_TYPE_WAVESEL	0x01	// waveform select
#define OPL_TYPE_ADPCM		0x02	// DELTA-T ADPCM unit
#define OPL_TYPE_KEYBOARD	0x04	// keyboard interface
#define OPL_TYPE_IO			0x08	// I/O port
#define OPL_TYPE_OPL3		0x10	// OPL3 Mode
#define OPL_TYPE_OPL4		0x20	// OPL4 Mode

#define OPL_TYPE_YM3526	(0)
#define OPL_TYPE_YM3812	(OPL_TYPE_WAVESEL)
#define OPL_TYPE_Y8950	(OPL_TYPE_ADPCM | OPL_TYPE_KEYBOARD | OPL_TYPE_IO)
#define OPL_TYPE_YMF262	(OPL_TYPE_YM3812 | OPL_TYPE_OPL3)
#define OPL_TYPE_YMF278	(OPL_TYPE_YMF262 | OPL_TYPE_OPL4)

#define OPL_YM3526	0x00
#define OPL_YM3812	0x01
#define OPL_Y8950	0x02
#define OPL_YMF262	0x03
#define OPL_YMF278	0x04
const char FMOPL_TYPES[0x05] = {OPL_TYPE_YM3526, OPL_TYPE_YM3812, OPL_TYPE_Y8950,
								OPL_TYPE_YMF262, OPL_TYPE_YMF278};

#define NR10 0x00
#define NR11 0x01
#define NR12 0x02
#define NR13 0x03
#define NR14 0x04
#define NR21 0x06
#define NR22 0x07
#define NR23 0x08
#define NR24 0x09
#define NR30 0x0A
#define NR31 0x0B
#define NR32 0x0C
#define NR33 0x0D
#define NR34 0x0E
#define NR41 0x10
#define NR42 0x11
#define NR43 0x12
#define NR44 0x13
#define NR50 0x14
#define NR51 0x15
#define NR52 0x16
const float GB_WAVE_DUTY[4] = {12.5f, 25.0f, 50.0f, 75.0f};	// in %
const char* GB_NOISE_MODE[0x02] = {"Counter", "Consecutive"};


typedef struct ymf271_chip
{
	UINT8 group_sync[12];
} YMF271_DATA;


char WriteStr[0x100];
char RedirectStr[0x100];
char* ChipStr;
CHIP_CNT ChpCnt;
UINT8 ChpCur;

YMF271_DATA CacheYMF271;

void InitChips(UINT32* ChipCounts)
{
	memcpy(&ChpCnt, ChipCounts, 0x04 * 0x10);
	ChpCur = 0x00;
	ChipStr = RedirectStr + 0xF0;
	
	return;
}

void SetChip(UINT8 ChipID)
{
	ChpCur = ChipID;
	
	return;
}

static INLINE const char* OnOff(UINT32 Value)
{
	return ONOFF_STR[Value ? 0x00 : 0x01];
}

static INLINE const char* Enable(UINT32 Value)
{
	return ENABLE_STRS[Value ? 0x00 : 0x01];
}

static INLINE UINT8 YM2151_Note(UINT8 FNum, UINT8 Block)
{
	UINT8 NoteVal;
	
	if (FNum > 0xF)
		return 0xFF;	// Invalid FNum
	if (Block > 0x07)
		Block = 0x07;
	
	if (! ((FNum & 0x03) == 0x03))
	{
		NoteVal = FNum >> 2;
		NoteVal = NoteVal * 3 + (FNum & 0x03);
		NoteVal = 61 + NoteVal;
	}
	else
	{
		NoteVal = 0xFF;
	}
	
	if (NoteVal == 0xFF)
		return 0xFF;
	
	return NoteVal + (Block - 0x04) * 12;
}

static INLINE void WriteChipID(UINT8 ChipType)
{
	const char* ChipName;
	UINT32 ChipCnt;
	
	switch(ChipType)
	{
	case 0x00:	// SN76496
		ChipName = "SN76496";
		ChipCnt = ChpCnt.SN76496;
		if (ChpCnt.SN76496 & 0x80000000)
		{
			ChipName = "T6W28";
			sprintf(ChipStr, "%s %s:\t", ChipName, T6W28_PORT[ChpCur]);
			return;
		}
		break;
	case 0x01:	// YM2413
		ChipName = "YM2413";
		ChipCnt = ChpCnt.YM2413;
		break;
	case 0x02:	// YM2612
		ChipName = "YM2612";
		ChipCnt = ChpCnt.YM2612;
		break;
	case 0x03:	// YM2151
		ChipName = "YM2151";
		ChipCnt = ChpCnt.YM2151;
		break;
	case 0x04:	// SegaPCM
		ChipName = "SegaPCM";
		ChipCnt = ChpCnt.SegaPCM;
		break;
	case 0x05:	// RF5C68
		ChipName = "RF5C68";
		ChipCnt = ChpCnt.RF5C68;
		break;
	case 0x06:	// YM2203
		ChipName = "YM2203";
		ChipCnt = ChpCnt.YM2203;
		break;
	case 0x07:	// YM2608
		ChipName = "YM2608";
		ChipCnt = ChpCnt.YM2608;
		break;
	case 0x08:	// YM2610
		ChipName = (ChpCnt.YM2610 & 0x80000000) ? "YM2610B" : "YM2610";
		ChipCnt = ChpCnt.YM2610;
		break;
	case 0x09:	// YM3812
		ChipName = "YM3812";
		ChipCnt = ChpCnt.YM3812;
		break;
	case 0x0A:	// YM3526
		ChipName = "YM3526";
		ChipCnt = ChpCnt.YM3526;
		break;
	case 0x0B:	// Y8950
		ChipName = "Y8950";
		ChipCnt = ChpCnt.Y8950;
		break;
	case 0x0C:	// YMF262
		ChipName = "YMF262";
		ChipCnt = ChpCnt.YMF262;
		break;
	case 0x0D:	// YMF278B
		ChipName = "YMF278B";
		ChipCnt = ChpCnt.YMF278B;
		break;
	case 0x0E:	// YMF271
		ChipName = "YMF271";
		ChipCnt = ChpCnt.YMF271;
		break;
	case 0x0F:	// YMZ280B
		ChipName = "YMZ280B";
		ChipCnt = ChpCnt.YMZ280B;
		break;
	case 0x10:	// RF5C164
		ChipName = "RF5C164";
		ChipCnt = ChpCnt.RF5C164;
		break;
	case 0x11:	// PWM
		ChipName = "PWM";
		ChipCnt = ChpCnt.PWM;
		break;
	case 0x12:	// AY8910
		ChipName = "AY8910";
		ChipCnt = ChpCnt.AY8910;
		break;
	case 0x13:	// GB DMG
		ChipName = "GB DMG";
		ChipCnt = ChpCnt.GBDMG;
		break;
	case 0x14:	// NES APU
		ChipName = "NES APU";
		ChipCnt = ChpCnt.NESAPU;
		break;
	default:
		ChipName = "Unknwon";
		ChipCnt = 0x00;
		break;
	}
	ChipCnt &= ~0x80000000;
	if (ChipCnt <= 0x01)
		sprintf(ChipStr, "%s:", ChipName);
	else
		sprintf(ChipStr, "%s #%lu:", ChipName, ChpCur);
	if (strlen(ChipStr) < 0x08)
		strcat(ChipStr, "\t");
	strcat(ChipStr, "\t");
	
	return;
}

void GGStereo(char* TempStr, UINT8 Data)
{
	UINT8 CurChn;
	char ChnChar;
	UINT32 StrPos;
	bool ChnEn;
	
	WriteChipID(0x00);
	sprintf(TempStr, "%sGG Stereo:\t", ChipStr);
	StrPos = strlen(TempStr);
	for (CurChn = 0x00; CurChn < 0x08; CurChn ++)
	{
		if ((CurChn & 0x03) != 0x03)
			ChnChar = '0' + (CurChn & 0x03);
		else
			ChnChar = 'N';
		ChnEn = (Data & (0x01 << (0x07 - CurChn))) != 0x00;
		TempStr[StrPos] = ChnEn ? ChnChar : '-';
		StrPos ++;
	}
	TempStr[StrPos] = 0x00;
	
	return;
}

void sn76496_write(char* TempStr, UINT8 Command)
{
	UINT8 CurChn;
	UINT8 CurData;
	
	WriteChipID(0x00);
	if (! (Command & 0x80))
	{
		CurData = Command & 0x7F;
		sprintf(TempStr, "%sData: %02X", ChipStr, CurData);
	}
	else
	{
		CurChn = (Command & 0x60) >> 5;
		CurData = Command & 0x0F;
		switch(Command & 0xF0)
		{
		case 0x80:
		case 0xA0:
		case 0xC0:
			sprintf(TempStr, "%sLatch/Data: Tone Ch %hu -> 0x%03lX", ChipStr, CurChn, CurData);
			break;
		case 0xE0:
			sprintf(WriteStr, "%s, %s", SN76496_NOISE_TYPE[(Command & 0x04) >> 2],
					SN76496_NOISE_FREQ[Command & 0x03]);
			
			sprintf(TempStr, "%sNoise Type: %hu - %s", ChipStr, CurData, WriteStr);
			break;
		case 0x90:
		case 0xB0:
		case 0xD0:
		case 0xF0:
			sprintf(TempStr, "%sLatch/Data: Volume Ch %hu -> 0x%01X = %u%%",
					ChipStr, CurChn, CurData, 100 * (0x0F - CurData) / 0x0F);
			break;
		}
	}
	
	return;
}

void ym2413_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x01);
	sprintf(TempStr, "%sReg 0x%02X Data 0x%02X", ChipStr, Register, Data);
	
	return;
}

void opn_write(char* TempStr, UINT8 Mode, UINT8 Port, UINT8 Register,
			   UINT8 Data)
{
	UINT16 RegVal;
	UINT8 Channel;
	UINT8 Slot;
	float TempSng;
	UINT8 TempByt;
	
	RegVal = (Port << 8) | Register;
	if (Register >= 0x20 && Register < 0x30)
	{
		if (Port)
			goto WriteRegData;
		
		// write a OPN mode register 0x20-0x2f
		switch(Register)
		{
		case 0x21:	// Test
			sprintf(TempStr, "Test Register");
			break;
		case 0x22:	// LFO FREQ (YM2608/YM2610/YM2610B/YM2612)
			if (! (FMOPN_TYPES[Mode] & OPN_TYPE_LFOPAN))
				goto WriteRegData;
			
			if (Data & 0x08) // LFO enabled ?
				sprintf(TempStr, "Low Frequency Oscillator: %s Hz",
						OPN_LFOFreqs[Data & 0x07]);
			else
				sprintf(TempStr, "Low Frequency Oscillator: Disable");
			break;
		case 0x24:	// timer A High 8
			sprintf(TempStr, "Timer A MSB: %02X", Data);
			break;
		case 0x25:	// timer A Low 2
			sprintf(TempStr, "Timer A LSB: %02X", Data & 0x03);
			break;
		case 0x26:	// timer B
			sprintf(TempStr, "Timer B: %02X", Data);
			break;
		case 0x27:	// mode, timer control
			sprintf(TempStr, "CSM Mode: %s", Enable(Data & 0x80));
			sprintf(TempStr, "%s, 3 Slot Mode: %s", TempStr, Enable(Data & 0x40));
			
			if (Data & 0x20)	// reset Timer b flag
				sprintf(TempStr, "%s, Reset Timer B", TempStr);
			if (Data & 0x10)	// reset timer A flag
				sprintf(TempStr, "%s, Reset Timer A", TempStr);
			
			sprintf(TempStr, "%s, Timer B %s", TempStr, Enable(Data & 0x08));
			sprintf(TempStr, "%s, Timer A %s", TempStr, Enable(Data & 0x04));
			
			if (Data & 0x02)	// load b
				sprintf(TempStr, "%s, Load/Start Timer B", TempStr);
			else				// stop timer b
				sprintf(TempStr, "%s, Stop Timer B", TempStr);
			if (Data & 0x01)	// load a
				sprintf(TempStr, "%s, Load/Start Timer A", TempStr);
			else				// stop timer a
				sprintf(TempStr, "%s, Stop Timer A", TempStr);
			break;
		case 0x28:	// key on / off
			Channel = Data & 0x03;
			if (Channel == 0x03)
			{
				sprintf(TempStr, "Key On/Off: Invalid Channel");
				break;
			}
			if ((Data & 0x04) && (FMOPN_TYPES[Mode] & OPN_TYPE_6CH))
				Channel += 3;
			
			sprintf(TempStr, "Channel %hu Key On/Off: ", Channel);
			
			sprintf(TempStr, "%sSlot1 %s, Slot2 %s, Slot3 %s, Slot4 %s", TempStr,
					OnOff(Data & 0x10), OnOff(Data & 0x20), OnOff(Data & 0x40),
					OnOff(Data & 0x80));
			break;
		case 0x2A:	// DAC data (YM2612)
			if (! (FMOPN_TYPES[Mode] & OPN_TYPE_DAC))
				goto WriteRegData;
			
			sprintf(TempStr, "DAC = %02X", Data);
			break;
		case 0x2B:	// DAC Sel  (YM2612)
			if (! (FMOPN_TYPES[Mode] & OPN_TYPE_DAC))
				goto WriteRegData;
			
			// b7 = dac enable
			sprintf(TempStr, "DAC %s", Enable(Data & 0x80));
			break;
		default:
			goto WriteRegData;
		}
	}
	else
	{
		Channel = (Register & 0x03);
		if (Channel == 0x03)	// 0xX3,0xX7,0xXB,0xXF
		{
			sprintf(TempStr, "Invalid Channel");
			return;
		}
		if (Port)
			Channel += 3;
		Slot = (Register & 0x0C) >> 2;
		
		switch(Register & 0xF0)
		{
		case 0x30:	// DET , MUL
			sprintf(WriteStr, "Detune: %hu", (Data & 0x10) >> 4);
			if (Data & 0x0F)
				TempSng = (float)(Data & 0x0F);
			else
				TempSng = 0.5f;
			sprintf(WriteStr, "%s, Multiple: Freq * %.1d", WriteStr, TempSng);
			break;
		case 0x40:	// TL
			sprintf(WriteStr, "Total Level: 0x%02X = %.0f%%",
					Data & 0x7F, 100.0 * cos((Data & 0x7F) / (double)0x7F * (PI / 2)));
			break;
		case 0x50:	// KS, AR
			sprintf(WriteStr, "Attack Rate: %02X, Key Scale: 1 / %01X",
					(Data & 0x1F) >> 0, (~Data & 0xC0) >> 6);
			break;
		case 0x60:	// bit7 = AM ENABLE, DR
			if (FMOPN_TYPES[Mode] & OPN_TYPE_LFOPAN)
				sprintf(WriteStr, "Amplitude Modulation: %s, ", Enable(Data & 0x80));
			else
				strcpy(WriteStr, "");
			sprintf(WriteStr, "%sDecay Rate: %02X", WriteStr,
					Data & 0x1F);
			break;
		case 0x70:	//     SR
			sprintf(WriteStr, "Sustain Rate: %02X",
					Data & 0x1F);
			break;
		case 0x80:	// SL, RR
			sprintf(WriteStr, "Sustain Level: %01X, Release Rate: %01X",
					(Data & 0xF0) >> 4, (Data & 0x0F) >> 0);
			break;
		case 0x90:	// SSG-EG
			//SLOT->ssg  =  v&0x0f;
			//SLOT->ssgn = (v&0x04)>>1; // bit 1 in ssgn = attack
			sprintf(WriteStr, "SSG-EG Flags: Envelope %s, Attack %s, Alternate %s, Hold %s",
					OnOff(Data & 0x08), OnOff(Data & 0x04), OnOff(Data & 0x02),
					OnOff(Data & 0x01));
			break;
		case 0xA0:
			switch(Register & 0x0C)
			{
			case 0x00:	// 0xa0-0xa2 : FNUM1
				/*{
					UINT32 fn = (((UINT32)( (OPN->ST.fn_h)&7))<<8) + v;
					UINT8 blk = OPN->ST.fn_h>>3;
					// keyscale code
					CH->kcode = (blk<<2) | opn_fktable[fn >> 7];
					// phase increment counter
					CH->fc = OPN->fn_table[fn*2]>>(7-blk);

					// store fnum in clear form for LFO PM calculations
					CH->block_fnum = (blk<<11) | fn;

					CH->SLOT[SLOT1].Incr=-1;
				}*/
				sprintf(WriteStr, "F-Num (set) LSB = %02X", Data);
				break;
			case 0x04:	// 0xa4-0xa6 : FNUM2,BLK
				//OPN->ST.fn_h = v&0x3f;
				sprintf(WriteStr, "F-Num (prepare) MSB = %01X, Octave %hu", Data & 0x07,
						(Data & 0x38) >> 3);
				break;
			case 0x08:	// 0xa8-0xaa : 3CH FNUM1
				if (Port)
					goto WriteRegData;
				
				/*UINT32 fn = (((UINT32)(OPN->SL3.fn_h&7))<<8) + v;
				UINT8 blk = OPN->SL3.fn_h>>3;
				// keyscale code
				OPN->SL3.kcode[c]= (blk<<2) | opn_fktable[fn >> 7];
				// phase increment counter
				OPN->SL3.fc[c] = OPN->fn_table[fn*2]>>(7-blk);
				OPN->SL3.block_fnum[c] = (blk<<11) | fn;
				(OPN->P_CH)[2].SLOT[SLOT1].Incr=-1;*/
				sprintf(WriteStr, "F-Num2 (set) LSB = %02X", Data);
				break;
			case 0x0C:	// 0xac-0xae : 3CH FNUM2,BLK
				if (Port)
					goto WriteRegData;
				
				//OPN->SL3.fn_h = v&0x3f;
				sprintf(WriteStr, "F-Num2 (prepare) MSB = %01X, Octave %hu", Data & 0x07,
						(Data & 0x38) >> 3);
				break;
			}
			break;
		case 0xB0:
			switch(Register & 0x0C)
			{
			case 0x00:	// 0xb0-0xb2 : FB,ALGO
				TempByt = (Data & 0x38) >> 3;
				if (TempByt)
					TempByt += 6;
				sprintf(WriteStr, "Feedback: %hu, Algorithm: %hu", TempByt, Data & 0x07);
				break;
			case 0x04:	// 0xb4-0xb6 : L , R , AMS , PMS (YM2612/YM2610B/YM2610/YM2608)
				if (! (FMOPN_TYPES[Mode] & OPN_TYPE_LFOPAN))
					goto WriteRegData;
				
				// b0-2 PMS
				//CH->pms = (v & 7) * 32; // CH->pms = PM depth * 32 (index in lfo_pm_table)
				
				// b4-5 AMS
				//CH->ams = lfo_ams_depth_shift[(v>>4) & 0x03];
				
				// PAN :  b7 = L, b6 = R
				/*OPN->pan[ c*2   ] = (v & 0x80) ? ~0 : 0;
				OPN->pan[ c*2+1 ] = (v & 0x40) ? ~0 : 0;*/
				sprintf(WriteStr, "PMS: 0x%01X, AMS: 0x%01X, Stereo: %c%c", Data & 0x07,
						(Data & 0x30) >> 4, (Data & 0x40) ? 'L' : '-',
						(Data & 0x80) ? 'R' : '-');
				break;
			default:
				goto WriteRegData;
			}
			break;
		default:
			goto WriteRegData;
		}
		
		if (Register < 0xA0)
			sprintf(TempStr, "Ch %hu Slot %hu %s", Channel, Slot, WriteStr);
		else
			sprintf(TempStr, "Ch %hu %s", Channel, WriteStr);
	}
	
	return;

WriteRegData:

	if (! (FMOPN_TYPES[Mode] & OPL_TYPE_OPL3) || ! Port)
		sprintf(TempStr, "Reg 0x%02X Data 0x%02X", Register, Data);
	else
		sprintf(TempStr, "Reg 0x%01X%02X Data 0x%02X", Port, Register, Data);
	
	return;
}

void ym2612_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x02);
	opn_write(RedirectStr, OPN_YM2612, Port, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void ym2151_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 Channel;
	UINT8 Operator;
	
	WriteChipID(0x03);
	//sprintf(TempStr, "%sReg 0x%02X Data 0x%02X", ChipStr, Register, Data);
	if (Register < 0x20)
	{
		switch(Register)
		{
		case 0x01:	// LFO reset(bit 1), Test Register (other bits)
			sprintf(TempStr, "Test Register, LFO %s", OnOff(Data & 0x02));
			break;
		case 0x08:
			sprintf(TempStr, "Ch %hu Key On/Off: M1 %s, M2 %s, C1 %s, C2 %s", Data & 0x07,
					OnOff(Data & 0x08), OnOff(Data & 0x20),
					OnOff(Data & 0x10), OnOff(Data & 0x40));
			break;
		case 0x0f:	// noise mode enable, noise period
			sprintf(TempStr, "Noise Mode %s, Noise Period 0x%02X",
					Enable(Data & 0x80), Data & 0x1F);
			break;
		case 0x10:	// timer A hi
			sprintf(TempStr, "Set Timer A High: 0x%02X", Data & 0xFF);
			//chip->timer_A_index = (chip->timer_A_index & 0x003) | (v<<2);
			break;
		case 0x11:	// timer A low
			sprintf(TempStr, "Set Timer A High: 0x%02X", Data & 0x03);
			//chip->timer_A_index = (chip->timer_A_index & 0x3fc) | (v & 3);
			break;
		case 0x12:	// timer B
			sprintf(TempStr, "Set Timer B: 0x%02X", Data);
			//chip->timer_B_index = v;
			break;
		case 0x14:	// CSM, irq flag reset, irq enable, timer start/stop
			sprintf(TempStr, "CSM %s", OnOff(Data & 0x80));
			//chip->irq_enable = v;	// bit 3-timer B, bit 2-timer A, bit 7 - CSM
			
			if (Data & 0x10)	// reset timer A irq flag
			{
				sprintf(TempStr, "%s, Reset Timer A IRQ Flag", TempStr);
			}
			
			if (Data & 0x20)	// reset timer B irq flag
			{
				sprintf(TempStr, "%s, Reset Timer B IRQ Flag", TempStr);
			}
			
			if (Data & 0x02)
			{	// load and start timer B
				sprintf(TempStr, "%s, Load/Start Timer B", TempStr);
			}
			else
			{	// stop timer B
				sprintf(TempStr, "%s, Stop Timer B", TempStr);
			}
			
			if (Data & 0x01)
			{	// load and start timer A
				sprintf(TempStr, "%s, Load/Start Timer A", TempStr);
			}
			else
			{	// stop timer A
				sprintf(TempStr, "%s, Stop Timer A", TempStr);
			}
			break;
		case 0x18:	// LFO frequency
			sprintf(TempStr, "LFO Frequency 0x%02X", Data);
			//chip->lfo_overflow    = ( 1 << ((15-(v>>4))+3) ) * (1<<LFO_SH);
			//chip->lfo_counter_add = 0x10 + (v & 0x0f);
			break;
		case 0x19:	// PMD (bit 7==1) or AMD (bit 7==0)
			if (Data & 0x80)
			{
				sprintf(TempStr, "LFO Phase Modul. Depth: 0x%02X", Data & 0x7F);
				//chip->pmd = v & 0x7f;
			}
			else
			{
				sprintf(TempStr, "LFO Amplitude Modul. Depth: 0x%02X", Data & 0x7F);
				//chip->amd = v & 0x7f;
			}
			break;
		case 0x1b:	// CT2, CT1, LFO waveform
			sprintf(TempStr, "LFO Wave Select: %s, CT1 %s, CT2 %s",
					YM2151_WAVE_FORM[Data & 0x03], OnOff(Data & 0x40), OnOff(Data & 0x80));
			//chip->ct = v >> 6;
			//chip->lfo_wsel = v & 3;
			break;
		default:
			sprintf(TempStr, "Undocumented register #%02X, Value 0x%02X", Register, Data);
			break;
		}
	}
	else
	{
		Channel = Register & 0x07;
		Operator = (Register & 0x18) >> 3;
		switch(Register & 0xE0)
		{
		case 0x20:
			switch(Register & 0x18)
			{
			case 0x00:	// RL enable, Feedback, Connection
				sprintf(WriteStr, "Stereo: %c%c, Feedback: %lu, Connection: %lu",
						(Data & 0x40) ? 'L' : '-', (Data & 0x80) ? 'R' : '-',
						(Data >> 3) & 0x07, Data & 0x07);
				break;
			case 0x08:	// Key Code
				Data &= 0x7F;
				Operator = YM2151_Note((UINT8)(Data & 0x0F), (UINT8)(Data >> 4));
				if (! Data)
					sprintf(WriteStr, "Key Code: 0x%02X = --", Data);
				else if (Operator != 0xFF)
					sprintf(WriteStr, "Key Code: 0x%02X = %s%ld", Data,
							NOTE_STRS[Operator % 12], (Operator / 12) - 2);
				else
					sprintf(WriteStr, "Key Code: 0x%02X = ??", Data);
				/*if (v != op->kc)
				{
					UINT32 kc, kc_channel;

					kc_channel = (v - (v>>2))*64;
					kc_channel += 768;
					kc_channel |= (op->kc_i & 63);

					(op+0)->kc = v;
					(op+0)->kc_i = kc_channel;
					(op+1)->kc = v;
					(op+1)->kc_i = kc_channel;
					(op+2)->kc = v;
					(op+2)->kc_i = kc_channel;
					(op+3)->kc = v;
					(op+3)->kc_i = kc_channel;

					kc = v>>2;

					(op+0)->dt1 = chip->dt1_freq[ (op+0)->dt1_i + kc ];
					(op+0)->freq = ( (chip->freq[ kc_channel + (op+0)->dt2 ] + (op+0)->dt1) * (op+0)->mul ) >> 1;

					(op+1)->dt1 = chip->dt1_freq[ (op+1)->dt1_i + kc ];
					(op+1)->freq = ( (chip->freq[ kc_channel + (op+1)->dt2 ] + (op+1)->dt1) * (op+1)->mul ) >> 1;

					(op+2)->dt1 = chip->dt1_freq[ (op+2)->dt1_i + kc ];
					(op+2)->freq = ( (chip->freq[ kc_channel + (op+2)->dt2 ] + (op+2)->dt1) * (op+2)->mul ) >> 1;

					(op+3)->dt1 = chip->dt1_freq[ (op+3)->dt1_i + kc ];
					(op+3)->freq = ( (chip->freq[ kc_channel + (op+3)->dt2 ] + (op+3)->dt1) * (op+3)->mul ) >> 1;

					refresh_EG( op );
				}*/
				break;

			case 0x10:	// Key Fraction
				Data >>= 2;
				sprintf(WriteStr, "Key Fraction: 0x%02X", Data);
				/*if (v !=  (op->kc_i & 63))
				{
					UINT32 kc_channel;

					kc_channel = v;
					kc_channel |= (op->kc_i & ~63);

					(op+0)->kc_i = kc_channel;
					(op+1)->kc_i = kc_channel;
					(op+2)->kc_i = kc_channel;
					(op+3)->kc_i = kc_channel;

					(op+0)->freq = ( (chip->freq[ kc_channel + (op+0)->dt2 ] + (op+0)->dt1) * (op+0)->mul ) >> 1;
					(op+1)->freq = ( (chip->freq[ kc_channel + (op+1)->dt2 ] + (op+1)->dt1) * (op+1)->mul ) >> 1;
					(op+2)->freq = ( (chip->freq[ kc_channel + (op+2)->dt2 ] + (op+2)->dt1) * (op+2)->mul ) >> 1;
					(op+3)->freq = ( (chip->freq[ kc_channel + (op+3)->dt2 ] + (op+3)->dt1) * (op+3)->mul ) >> 1;
				}*/
				break;

			case 0x18:	// PMS, AMS
				sprintf(WriteStr, "PMS: 0x%02X, AMS: 0x%02X", (Data >> 4) & 0x07, Data & 0x03);
				//op->pms = (v>>4) & 7;
				//op->ams = (v & 3);
				break;
			}
			break;
		case 0x40:		// DT1, MUL
			sprintf(WriteStr, "Detune 1: 0x%02X, Freq Multipler: 0x%02X",
					(Data & 0x70) << 1, Data & 0x0F);
			/*{
				UINT32 olddt1_i = op->dt1_i;
				UINT32 oldmul = op->mul;

				op->dt1_i = (v&0x70)<<1;
				op->mul   = (v&0x0f) ? (v&0x0f)<<1: 1;

				if (olddt1_i != op->dt1_i)
					op->dt1 = chip->dt1_freq[ op->dt1_i + (op->kc>>2) ];

				if ( (olddt1_i != op->dt1_i) || (oldmul != op->mul) )
					op->freq = ( (chip->freq[ op->kc_i + op->dt2 ] + op->dt1) * op->mul ) >> 1;
			}*/
			break;
		case 0x60:		// TL
			sprintf(WriteStr, "Total Level: 0x%02X = %u%%",
					Data & 0x7F, 100 * (Data & 0x7F) / 0x7F);
			//op->tl = (v&0x7f)<<(10-7); // 7bit TL
			break;
		case 0x80:		// KS, AR
			sprintf(WriteStr, "Key Scale: 0x%02X, Attack Rate: 0x%02X",
					0x05 - (Data >> 6), Data & 0x1F);
			/*{
				UINT32 oldks = op->ks;
				UINT32 oldar = op->ar;
				
				op->ks = 5-(v>>6);
				op->ar = (v&0x1f) ? 32 + ((v&0x1f)<<1) : 0;
				
				if ( (op->ar != oldar) || (op->ks != oldks) )
				{
					if ((op->ar + (op->kc>>op->ks)) < 32+62)
					{
						op->eg_sh_ar  = eg_rate_shift [op->ar  + (op->kc>>op->ks) ];
						op->eg_sel_ar = eg_rate_select[op->ar  + (op->kc>>op->ks) ];
					}
					else
					{
						op->eg_sh_ar  = 0;
						op->eg_sel_ar = 17*RATE_STEPS;
					}
				}
				
				if (op->ks != oldks)
				{
					op->eg_sh_d1r = eg_rate_shift [op->d1r + (op->kc>>op->ks) ];
					op->eg_sel_d1r= eg_rate_select[op->d1r + (op->kc>>op->ks) ];
					op->eg_sh_d2r = eg_rate_shift [op->d2r + (op->kc>>op->ks) ];
					op->eg_sel_d2r= eg_rate_select[op->d2r + (op->kc>>op->ks) ];
					op->eg_sh_rr  = eg_rate_shift [op->rr  + (op->kc>>op->ks) ];
					op->eg_sel_rr = eg_rate_select[op->rr  + (op->kc>>op->ks) ];
				}
			}*/
			break;
		case 0xA0:		// LFO AM enable, D1R
			sprintf(WriteStr, "LFO Amplitude Modul. %s, Decay Rate 1: 0x%02X",
					OnOff(Data & 0x80), Data & 0x1F);
			/*op->AMmask = (v&0x80) ? ~0 : 0;
			op->d1r    = (v&0x1f) ? 32 + ((v&0x1f)<<1) : 0;
			op->eg_sh_d1r = eg_rate_shift [op->d1r + (op->kc>>op->ks) ];
			op->eg_sel_d1r= eg_rate_select[op->d1r + (op->kc>>op->ks) ];*/
			break;
		case 0xC0:		// DT2, D2R
			sprintf(WriteStr, "Detune 2: %lu, Decay Rate 2: 0x%02X",
					dt2_tab[Data >> 6], Data & 0x1F);
			/*{
				UINT32 olddt2 = op->dt2;
				op->dt2 = dt2_tab[ v>>6 ];
				if (op->dt2 != olddt2)
					op->freq = ( (chip->freq[ op->kc_i + op->dt2 ] + op->dt1) * op->mul ) >> 1;
			}
			op->d2r = (v&0x1f) ? 32 + ((v&0x1f)<<1) : 0;
			op->eg_sh_d2r = eg_rate_shift [op->d2r + (op->kc>>op->ks) ];
			op->eg_sel_d2r= eg_rate_select[op->d2r + (op->kc>>op->ks) ];*/
			break;
		case 0xE0:		// D1L, RR
			sprintf(WriteStr, "D1L: 0x%02X, Release Rate: 0x%02X",
					Data >> 4, 34 + ((Data & 0x0F) << 2));
			/*op->d1l = d1l_tab[ v>>4 ];
			op->rr  = 34 + ((v&0x0f)<<2);
			op->eg_sh_rr  = eg_rate_shift [op->rr  + (op->kc>>op->ks) ];
			op->eg_sel_rr = eg_rate_select[op->rr  + (op->kc>>op->ks) ];*/
			break;
		}
		
		if (Register < 0x40)
			sprintf(TempStr, "%sCh %hu %s", ChipStr, Channel, WriteStr);
		else
			sprintf(TempStr, "%sCh %hu Op %hu %s", ChipStr, Channel, Operator, WriteStr);
	}
	
	return;
}

void segapcm_mem_write(char* TempStr, UINT16 Offset, UINT8 Data)
{
	UINT8 Channel;
	UINT16 RelOffset;
	
	WriteChipID(0x04);
	
	Offset &= 0x07FF;
	Channel = (Offset >> 3) & 0xF;
	RelOffset = Offset & ~0x0078;
	
	//sprintf(TempStr, "SegaPCM:\tOffset 0x%04X Data 0x%02X", Offset, Data);
	switch(RelOffset)
	{
	case 0x86:
		sprintf(WriteStr, "%s", Enable(~Data & 0x01));
		break;
	case 0x04:
	case 0x05:
		sprintf(WriteStr, "Loop Address %s 0x%02X", ADDR_2S_STR[RelOffset & 0x01], Data);
		break;
	case 0x84:
	case 0x85:
		sprintf(WriteStr, "Current Address %s 0x%02X", ADDR_2S_STR[RelOffset & 0x01], Data);
		break;
	case 0x06:
		sprintf(WriteStr, "End Address 0x%02X", Data);
		break;
	case 0x07:
		sprintf(WriteStr, "Sample Delta Time 0x%02X", Data);
		break;
	case 0x02:
		sprintf(WriteStr, "Volume L 0x%02X = %u%%", Data, 100 * Data / 0x3F);
		break;
	case 0x03:
		sprintf(WriteStr, "Volume R 0x%02X = %u%%", Data, 100 * Data / 0x3F);
		break;
	default:
		sprintf(WriteStr, "Write Offset 0x%03X, Data 0x%02X", Offset, Data);
		break;
	}
	
	sprintf(TempStr, "%sCh %hu %s", ChipStr, Channel, WriteStr);
	
	return;
}

void rf5c68_reg_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 CurChn;
	char ChnChar;
	UINT32 StrPos;
	bool ChnEn;
	
	WriteChipID(0x05);
	
	switch(Register)
	{
	case 0x00:	// Evelope
		sprintf(WriteStr, "Envelope %.2f %%", 100 * Data / 255.0f);
		break;
	case 0x01:	// Pan
		sprintf(WriteStr, "Pan: VolL %u %%, VolR %u %%",
				100 * (Data & 0x0F) / 0x0F, 100 * (Data >> 4) / 0x0F);
		break;
	case 0x02:	// Frequency Step (LB)
		sprintf(WriteStr, "Freq. Step Low: 0x%02X", Data);
		break;
	case 0x03:	// Frequency Step (HB)
		sprintf(WriteStr, "Freq. Step High: 0x%02X", Data);
		break;
	case 0x04:	// Loop Address Low
		sprintf(WriteStr, "Loop Address Low 0x%02X", Data);
		break;
	case 0x05:	// Loop Address High
		sprintf(WriteStr, "Loop Address High 0x%02X", Data);
		break;
	case 0x06:	// Start Address
		sprintf(WriteStr, "Start Address 0x%04X", Data << 8);
		break;
	case 0x07:	// Control Register
		sprintf(WriteStr, "Chip %s", Enable((Data & 0x80) >> 7));
		if (Data & 0x40)
			sprintf(WriteStr, "%s, Select Channel %hu", WriteStr, Data & 0x07);
		else
			sprintf(WriteStr, "%s, Select Bank 0x%hX (Memory Base 0x%04X)",
					WriteStr, Data & 0x0F, (Data & 0x0F) << 12);
		break;
	case 0x08:	// Sound On/Off
		sprintf(WriteStr, "Channel Enable:\t");
		StrPos = strlen(WriteStr);
		for (CurChn = 0x00; CurChn < 0x08; CurChn ++)
		{
			ChnEn = ! (Data & (0x01 << CurChn));
			ChnChar = '0' + CurChn;
			WriteStr[StrPos] = ChnEn ? ChnChar : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		break;
	default:
		sprintf(WriteStr, "Reg 0x%02X, Data 0x%02X", Register, Data);
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	//sprintf(TempStr, "%sReg 0x%02X Data 0x%02X", ChipStr, Register, Data);
	
	return;
}

void rf5c68_mem_write(char* TempStr, UINT16 Offset, UINT8 Data)
{
	WriteChipID(0x05);
	sprintf(TempStr, "%sMem 0x%04X Data 0x%02X", ChipStr, Offset, Data);
	
	return;
}

void ym2203_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x06);
	opn_write(RedirectStr, OPN_YM2203, 0x00, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void ym2608_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x07);
	opn_write(RedirectStr, OPN_YM2608, Port, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void ym2610_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x08);
	opn_write(RedirectStr, OPN_YM2610, Port, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void opl_write(char* TempStr, UINT8 Mode, UINT8 Port, UINT8 Register,
			   UINT8 Data)
{
	UINT8 Channel;
	UINT8 Operator;
	
	if (Register < 0x20)
	{
		// 00-1f:control
		switch(Register & 0x1F)
		{
		case 0x01:	// waveform select enable
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_WAVESEL) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "Waveform Select: %s", Enable(Data & 0x20));
			break;
		case 0x02:	// Timer 1
			if (Port)
				goto WriteRegData;
			
			sprintf(TempStr, "Timer 1 = %hu", (0x100 - Data) * 0x04);
			break;
		case 0x03:	// Timer 2
			if (Port)
				goto WriteRegData;
			
			sprintf(TempStr, "Timer 2 = %hu", (0x100 - Data) * 0x10);
			break;
		case 0x04:	// IRQ clear / mask and Timer enable
			switch(Port)
			{
			case 0x00:
				if (Data & 0x80)
				{	// IRQ flag clear
					sprintf(TempStr, "IRQ Flag Clear");
				}
				else
				{	// set IRQ mask ,timer enable
					sprintf(TempStr, "Set IRQ Mask: 0x%02X", Data >> 3);
					sprintf(TempStr, "%s, Timer 1: %s", TempStr, Enable(Data & 0x01));
					sprintf(TempStr, "%s, Timer 2: %s", TempStr, Enable(Data & 0x02));
					
					// IRQRST,T1MSK,t2MSK,EOSMSK,BRMSK,x,ST2,ST1
				}
				break;
			case 0x01:
				if (! (FMOPL_TYPES[Mode] & OPL_TYPE_OPL3))
					goto WriteRegData;
				
				sprintf(TempStr, "4-Op Mode: ");
				sprintf(TempStr, "%sCh 0-3: %s, ", TempStr, Enable(Data & 0x01));
				sprintf(TempStr, "%sCh 1-4: %s, ", TempStr, Enable(Data & 0x02));
				sprintf(TempStr, "%sCh 2-5: %s, ", TempStr, Enable(Data & 0x04));
				sprintf(TempStr, "%sCh 9-12: %s, ", TempStr, Enable(Data & 0x08));
				sprintf(TempStr, "%sCh 10-13: %s, ", TempStr, Enable(Data & 0x10));
				sprintf(TempStr, "%sCh 11-14: %s", TempStr, Enable(Data & 0x20));
				break;
			}
			break;
		case 0x05:	// OPL3/OPL4 Mode Enable
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_OPL3) || ! Port)
				goto WriteRegData;
			
			sprintf(TempStr, "OPL3 Mode: %s", Enable(Data & 0x01));
			if (FMOPL_TYPES[Mode] & OPL_TYPE_OPL4)
				sprintf(TempStr, ", OPL4 Mode: %s", Enable(Data & 0x02));
			break;
		case 0x06:		// Key Board OUT
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_KEYBOARD) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "Key Board Write: 0x%02X", Data);
			break;
		case 0x07:	// DELTA-T control 1 : START,REC,MEMDATA,REPT,SPOFF,x,x,RST
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "DELTA-T Control 1: 0x%02X", Data);
			//YM_DELTAT_ADPCM_Write(OPL->deltat,r-0x07,v);
			break;
		case 0x08:	// MODE,DELTA-T control 2 : CSM,NOTESEL,x,x,smpl,da/ad,64k,rom
			if (Port)
				goto WriteRegData;
			
			sprintf(TempStr, "CSM %s, Note Select: %s", OnOff(Data & 0x80), OnOff(Data & 0x40));
			
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM))
				break;
			
			sprintf(TempStr, "%s, DELTA-T Control 2: 0x%02X", TempStr, Data & 0x0F);
			//YM_DELTAT_ADPCM_Write(OPL->deltat,r-0x07,v&0x0f); // mask 4 LSBs in register 08 for DELTA-T unit
			break;
		case 0x09:		// START ADD
		case 0x0a:
		case 0x0b:		// STOP ADD
		case 0x0c:
		case 0x0d:		// PRESCALE
		case 0x0e:
		case 0x0f:		// ADPCM data write
		case 0x10: 		// DELTA-N
		case 0x11: 		// DELTA-N
		case 0x12: 		// ADPCM volume
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "DELTA-T Write Reg 0x%02X: 0x%02X", Register - 0x07, Data);
			//YM_DELTAT_ADPCM_Write(OPL->deltat,r-0x07,v);
			break;
		case 0x15:		// DAC data high 8 bits (F7,F6...F2)
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "DELTA-T DAC Write High: 0x%02X", Data);
			break;
		case 0x16:		// DAC data low 2 bits (F1, F0 in bits 7,6)
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "DELTA-T DAC Write Low: 0x%02X", Data);
			break;
		case 0x17:		// DAC data shift (S2,S1,S0 in bits 2,1,0)
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_ADPCM) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "DELTA-T DAC Write Data Shift: 0x%02X", Data);
			break;
		case 0x18:		// I/O CTRL (Direction)
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_IO) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "I/O Direction: 0x%02X", Data & 0x0F);
			break;
		case 0x19:		// I/O DATA
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_IO) || Port)
				goto WriteRegData;
			
			sprintf(TempStr, "I/O Data/Latch: 0x%02X", Data);
			break;
		default:
			goto WriteRegData;
		}
	}
	else
	{
		Channel = ((Register & 0x18) >> 3) * 3 + ((Register & 0x07) % 3);
		Operator = (Register & 0x07) / 3;
		switch(Register & 0xE0)
		{
		case 0x20:	// am ON, vib ON, ksr, eg_type, mul
			sprintf(WriteStr, "AM: %s, Vibrato: %s, KSR: %s, EG Type: %hu, Freq Multipler: %hu",
					OnOff(Data & 0x80), OnOff(Data & 0x40), OnOff(Data & 0x20),
					(Data & 0x10) >> 4, Data & 0x0F);
			break;
		case 0x40:
			sprintf(WriteStr, "Key Scaling: %01X, Total Level: 0x%02X = %u%%",
					(Data & 0xC0) >> 6, Data & 0x3F, 100 * (~Data & 0x3F) / 0x3F);
			break;
		case 0x60:
			sprintf(WriteStr, "Attack Rate: %01X, Decay Rate: %01X",
					(Data & 0xF0) >> 4, (Data & 0x0F) >> 0);
			break;
		case 0x80:
			sprintf(WriteStr, "Sustain Level: %01X, Release Rate: %01X",
					(Data & 0xF0) >> 4, (Data & 0x0F) >> 0);
			break;
		case 0xA0:
			if (Register == 0xBD)			// am depth, vibrato depth, r,bd,sd,tom,tc,hh
			{
				sprintf(WriteStr, "AM Depth: %.1f, Vibrato Depth: %hu cent, Rhythm Mode %s",
						(Data & 0x80) ? 4.8 : 1.0, (Data & 0x40) ? 14 : 7, Enable(Data & 0x20));
				
				if (Data & 0x20)
				{
					sprintf(WriteStr, "%s, BD %s, SD %s, TOM %s, CYM %s, HH %s", WriteStr,
							OnOff(Data & 0x10), OnOff(Data & 0x08), OnOff(Data & 0x04),
							OnOff(Data & 0x02), OnOff(Data & 0x01));
				}
				break;
			}
			
			// keyon,block,fnum
			if ((Register & 0x0F) > 8)
				goto WriteRegData;
			
			if (! (Register & 0x10))
			{	// a0-a8
				sprintf(WriteStr, "F-Num LSB = %02X", Data);
			}
			else
			{	// b0-b8
				sprintf(WriteStr, "F-Num MSB = %01X, Octave %hu, Key %s", Data & 0x03,
						(Data & 0x1C) >> 2, OnOff(Data & 0x20));
			}
			break;
		case 0xC0:
			// FB,C
			if ((Register & 0x1F) > 8)
				goto WriteRegData;
			
			sprintf(WriteStr, "Connect: %s, Feedback %hu", OnOff(Data & 0x01),
					(Data & 0x0E) >> 1);
			break;
		case 0xE0: // waveform select
			// TODO: - ignore write if Wave Select is not enabled in test register (OPL2 only)
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_WAVESEL))
				goto WriteRegData;
			
			if (! (FMOPL_TYPES[Mode] & OPL_TYPE_OPL3))
				Data &= 0x03;	// only 2 wave forms on OPL2
			sprintf(WriteStr, "Waveform Select: %hu", Data & 0x07);
			
			break;
		default:
			goto WriteRegData;
		}
		
		if (Register < 0xA0 || Register >= 0xE0)
			sprintf(TempStr, "Ch %hu Op %hu %s", Channel, Operator, WriteStr);
		else if (Register != 0xBD)
			sprintf(TempStr, "Ch %hu %s", Register & 0x0F, WriteStr);
		else
			sprintf(TempStr, "%s", WriteStr);
	}
	
	return;

WriteRegData:

	if (! (FMOPL_TYPES[Mode] & OPL_TYPE_OPL3) || ! Port)
		sprintf(TempStr, "Reg 0x%02X Data 0x%02X", Register, Data);
	else
		sprintf(TempStr, "Reg 0x%01X%02X Data 0x%02X", Port, Register, Data);
	
	return;
}

void ym3812_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x09);
	opl_write(RedirectStr, OPL_YM3812, 0x00, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void ym3526_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x0A);
	opl_write(RedirectStr, OPL_YM3526, 0x00, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void y8950_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x0B);
	opl_write(RedirectStr, OPL_Y8950, 0x00, Register, Data);
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void ymf262_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x0C);
	opl_write(RedirectStr, OPL_YMF262, Port, Register, Data);
	
	sprintf(TempStr, "%sPort %hX %s", ChipStr, Port, RedirectStr);
	//sprintf(TempStr, "YMF262:\tReg 0x%02X Data 0x%02X", Register | (Port << 8), Data);
	
	return;
}

void ymz280b_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 Voice;
	UINT8 Addr;
	
	WriteChipID(0x0F);
	if (Register < 0x80)
	{
		Voice = (Register >> 2) & 0x07;
		Addr = 0x3 - (Register >> 5);

		switch(Register & 0xE3)
		{
		case 0x00:		// pitch low 8 bits
			sprintf(WriteStr, "Pitch Low 0x%02X", Data);
			break;
		case 0x01:		// pitch upper 1 bit, loop, key on, mode
			sprintf(WriteStr, "Pitch High 0x%01X, Looping %s, Mode %s, Key %s",
					Data & 0x01, OnOff(Data & 0x10), YMZ280B_MODES[(Data & 0x60) >> 5],
					OnOff(Data & 0x80));
			break;
		case 0x02:		// total level
			sprintf(WriteStr, "Total Level %.0f %%", 100 * Data / 255.0f);
			break;
		case 0x03:		// pan
			sprintf(WriteStr, "Pan 0x%02X = %ld%%", Data, 200 * (Data - 0x08) / 0x0F);
			break;
		case 0x20:		// start address high
		case 0x40:		// start address middle
		case 0x60:		// start address low
			sprintf(WriteStr, "Start Address %s 0x%02X", ADDR_3S_STR[Addr], Data);
			break;
		case 0x21:		// loop start address high
		case 0x41:		// loop start address middle
		case 0x61:		// loop start address low
			sprintf(WriteStr, "Loop Start Address %s 0x%02X", ADDR_3S_STR[Addr], Data);
			break;
		case 0x22:		// loop end address high
		case 0x42:		// loop end address middle
		case 0x62:		// loop end address low
			sprintf(WriteStr, "Loop End Address %s 0x%02X", ADDR_3S_STR[Addr], Data);
			break;
		case 0x23:		// stop address high
		case 0x43:		// stop address middle
		case 0x63:		// stop address low
			sprintf(WriteStr, "Stop Address %s 0x%02X", ADDR_3S_STR[Addr], Data);
			break;
		default:
			sprintf(WriteStr, "Unknown Register Write %02X = %02X", Register, Data);
			break;
		}
		sprintf(TempStr, "%sCh %hu %s", ChipStr, Voice, WriteStr);
	}
	else	// upper registers are special
	{
		Addr = 0x02 - (Register & 0x03);
		switch(Register)
		{
		case 0x84:		// ROM readback / RAM write (high)
		case 0x85:		// ROM readback / RAM write (med)
		case 0x86:		// ROM readback / RAM write (low)
			sprintf(WriteStr, "ROM Readback / RAM Write Addres %s 0x%02X",
					ADDR_3S_STR[Addr], Data);
			break;
		case 0x87:		// RAM write
			sprintf(WriteStr, "RAM Write: 0x%02X", Data);
			break;
		case 0xFE:		// IRQ mask
			sprintf(WriteStr, "IRQ Mask 0x%02X", Data);
			break;
		case 0xFF:		// IRQ enable, test, etc
			sprintf(WriteStr, "IRQ %s", Enable(Data & 0x10));
			sprintf(WriteStr, "%s, KeyOn %s", WriteStr, Enable(Data & 0x80));
			break;
		default:
			sprintf(WriteStr, "Unknown Register Write %02X = %02X", Register, Data);
			break;
		}
		sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	}
	
	return;
}

void ymf278b_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x0D);
	
	if (Port <= 0x01)
	{
		opl_write(RedirectStr, OPL_YMF278, Port, Register, Data);
		
		sprintf(TempStr, "%sPort %hX %s", ChipStr, Port, RedirectStr);
	}
	else
	{
		sprintf(TempStr, "%sPort %x Reg 0x%02X Data 0x%02X", ChipStr, Port, Register, Data);
	}
	
	return;
}

/*void ymf271_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x0E);
	
	sprintf(TempStr, "%sPort %x Reg 0x%02X Data 0x%02X", ChipStr, Port, Register, Data);
	
	return;
}*/

void rf5c164_reg_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 CurChn;
	char ChnChar;
	UINT32 StrPos;
	bool ChnEn;
	
	WriteChipID(0x10);
	
	switch(Register)
	{
	case 0x00:	// Evelope
		sprintf(WriteStr, "Envelope %.0f %%", 100 * Data / 255.0f);
		break;
	case 0x01:	// Pan
		sprintf(WriteStr, "Pan: VolL %u %%, VolR %u %%",
				100 * (Data & 0x0F) / 0x0F, 100 * (Data >> 4) / 0x0F);
		break;
	case 0x02:	// Frequency Step (LB)
		sprintf(WriteStr, "Freq. Step Low: 0x%02X", Data);
		break;
	case 0x03:	// Frequency Step (HB)
		sprintf(WriteStr, "Freq. Step High: 0x%02X", Data);
		break;
	case 0x04:	// Loop Address Low
		sprintf(WriteStr, "Loop Address Low 0x%02X", Data);
		break;
	case 0x05:	// Loop Address High
		sprintf(WriteStr, "Loop Address High 0x%02X", Data);
		break;
	case 0x06:	// Start Address
		sprintf(WriteStr, "Start Address 0x%02X", Data);
		break;
	case 0x07:	// Control Register
		sprintf(WriteStr, "Chip %s", Enable((Data & 0x80) >> 7));
		if (Data & 0x40)
			sprintf(WriteStr, "%s, Select Channel %hu", WriteStr, Data & 0x07);
		else
			sprintf(WriteStr, "%s, Select Bank 0x%hX (Memory Base 0x%04X)",
					WriteStr, Data & 0x0F, (Data & 0x0F) << 12);
		break;
	case 0x08:	// Sound On/Off
		sprintf(WriteStr, "Channel Enable:\t");
		StrPos = strlen(WriteStr);
		for (CurChn = 0x00; CurChn < 0x08; CurChn ++)
		{
			ChnEn = ! (Data & (0x01 << CurChn));
			ChnChar = '0' + CurChn;
			WriteStr[StrPos] = ChnEn ? ChnChar : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		break;
	default:
		sprintf(WriteStr, "Reg 0x%02X, Data 0x%02X", Register, Data);
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	//sprintf(TempStr, "%sReg 0x%02X Data 0x%02X", ChipStr, Register, Data);
	
	return;
}

void rf5c164_mem_write(char* TempStr, UINT16 Offset, UINT8 Data)
{
	WriteChipID(0x10);
	sprintf(TempStr, "%sMem 0x%04X Data 0x%02X", ChipStr, Offset, Data);
	
	return;
}

void ay8910_reg_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 CurChn;
	char ChnChar;
	UINT32 StrPos;
	UINT8 ChnEn;
	
	WriteChipID(0x12);
	
	switch(Register)
	{
	case 0x00:	// AY_AFINE
	case 0x02:	// AY_BFINE
	case 0x04:	// AY_CFINE
		sprintf(WriteStr, "Chn %c Freq. Fine: 0x%02X", 'A' + (Register >> 2), Data);
		break;
	case 0x01:	// AY_ACOARSE
	case 0x03:	// AY_BCOARSE
	case 0x05:	// AY_CCOARSE
		sprintf(WriteStr, "Chn %c Freq. Coarse: 0x%01X", 'A' + (Register >> 2), Data & 0x0F);
		break;
	case 0x06:	// AY_NOISEPER
		sprintf(WriteStr, "Noise Period: 0x%02X", Data & 0x1F);
		break;
	case 0x07:	// AY_ENABLE
		sprintf(WriteStr, "Enable: Channel ");
		StrPos = strlen(WriteStr);
		for (CurChn = 0; CurChn < 3; CurChn ++)
		{
			ChnEn = ~Data & (0x01 << (CurChn + 0));
			ChnChar = 'A' + CurChn;
			WriteStr[StrPos] = ChnEn ? ChnChar : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		sprintf(WriteStr, "%s, Noise ", WriteStr);
		StrPos = strlen(WriteStr);
		for (CurChn = 0; CurChn < 3; CurChn ++)
		{
			ChnEn = ~Data & (0x01 << (CurChn + 3));
			ChnChar = 'A' + CurChn;
			WriteStr[StrPos] = ChnEn ? ChnChar : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		sprintf(WriteStr, "%s, Port ", WriteStr);
		StrPos = strlen(WriteStr);
		// TODO: Ports are just INPUUT (off) or OUTPUT (on) mode
		for (CurChn = 0; CurChn < 2; CurChn ++)
		{
			ChnEn = Data & (0x01 << (CurChn + 6));
			ChnChar = 'A' + CurChn;
			WriteStr[StrPos] = ChnEn ? ChnChar : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		break;
	case 0x08:	// AY_AVOL
	case 0x09:	// AY_BVOL
	case 0x0A:	// AY_CVOL
		sprintf(WriteStr, "Chn %c Volume %u%%, Enelope Mode: %hu", 'A' + (Register - 0x08),
				100 * (Data & 0x0F) / 0x0F, (Data & 0x10) >> 1);
		break;
	case 0x0B:	// AY_EFINE
		sprintf(WriteStr, "Envelope Freq. Fine: 0x%02X", Data);
		break;
	case 0x0C:	// AY_ECOARSE
		sprintf(WriteStr, "Envelope Freq. Coarse: 0x%02X", Data);
		break;
	case 0x0D:	// AY_ESHAPE
		sprintf(WriteStr, "Envelope Shape: 0x%02X", Data);
		break;
	case 0x0E:	// AY_PORTA
		sprintf(WriteStr, "Write Port A: 0x%02X", Data);
		break;
	case 0x0F:	// AY_PORTB
		sprintf(WriteStr, "Write Port B: 0x%02X", Data);
		break;
	default:
		sprintf(WriteStr, "Reg 0x%02X, Data 0x%02X", Register, Data);
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	
	return;
}

void pwm_write(char* TempStr, UINT16 Port, UINT16 Data)
{
	UINT8 PortVal;
	
	WriteChipID(0x11);
	
	PortVal = (Port > 0x05) ? 0x05 : Port;
	sprintf(WriteStr, "%s, Data 0x%03X", PWM_PORTS[PortVal], Data);
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	
	return;
}

static void ymf271_write_fm_reg(char* TempStr, UINT8 Register, UINT8 Data)
{
	switch(Register)
	{
	case 0:
		sprintf(TempStr, "Key %s, ExtOut: %X", OnOff(Data & 0x01), (Data >> 3) & 0x0F);
		break;
	case 1:
		sprintf(TempStr, "LFO Freq: %02X", Data);
		break;
	case 2:
		sprintf(TempStr, "LFO Wave: %u, PMS: %u, AMS: %u",
				Data & 0x03, (Data >> 3) & 0x07, (Data >> 6) & 0x03);
		break;
	case 3:
		sprintf(TempStr, "Multiple: %X, Detune: %u", Data & 0x0F, (Data >> 4) & 0x07);
		break;
	case 4:
		sprintf(TempStr, "Total Level: %02X = %u%%",
				Data & 0x7F, 100 * (Data & 0x7F) / 0x7F);
		break;
	case 5:
		sprintf(TempStr, "Attack Rate: %02X, Key Scale: %u", Data & 0x1F, (Data >> 5) & 0x07);
		break;
	case 6:
		sprintf(TempStr, "Decay 1 Rate: %02X", Data & 0x1F);
		break;
	case 7:
		sprintf(TempStr, "Decay 2 Rate: %02X", Data & 0x1F);
		break;
	case 8:
		sprintf(TempStr, "Release Rate: %X, Decay 1 Level: %X",
				Data & 0x0F, (Data >> 4) & 0x0F);
		break;
	case 9:
		sprintf(TempStr, "FNum LSB: %02X", Data);
		break;
	case 10:
		sprintf(TempStr, "FNum MSB: %02X, Block: %X",
				Data & 0x0F, (Data >> 4) & 0x0F);
		break;
	case 11:
		sprintf(TempStr, "Waveform: %u, Feedback: %u, AccOn: %s",
				Data & 0x07, (Data >> 4) & 0x07, Enable(Data & 0x80));
		break;
	case 12:
		sprintf(TempStr, "Algorithm: %X", Data & 0x0F);
		break;
	case 13:
		sprintf(TempStr, "Channel 0 Volume: %X = %u%%, Channel 1 Volume: %X = %u%%",
				(Data >> 4) & 0x0F, 100 * (Data >> 4) / 0x0F,
				Data & 0x0F, 100 * (Data & 0x0F) / 0x0F);
		break;
	case 14:
		sprintf(TempStr, "Channel 2 Volume: %X = %u%%, Channel 3 Volume: %X = %u%%",
				(Data >> 4) & 0x0F, 100 * (Data >> 4) / 0x0F,
				Data & 0x0F, 100 * (Data & 0x0F) / 0x0F);
		break;
	default:
		sprintf(TempStr, "Invalid Register");
		break;
	}
	
	return;
}

static void ymf271_write_fm(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	UINT8 SlotReg;
	UINT8 SlotNum;
	UINT8 SyncMode;
	UINT8 SyncReg;
	
	if ((Register & 0x03) == 0x03)
	{
		sprintf(RedirectStr, "Invalid Slot");
		return;
	}
	
	SlotNum = ((Register & 0x0F) / 0x04 * 0x03) + (Register & 0x03);
	SlotReg = (Register >> 4) & 0x0F;
	if (SlotNum >= 12 || 12 * Port > 48)
	{
		sprintf(RedirectStr, "Progrmm Error");
		return;
	}
	
	// check if the register is a synchronized register
	SyncReg = 0;
	switch(SlotReg)
	{
	case  0:
	case  9:
	case 10:
	case 12:
	case 13:
	case 14:
		SyncReg = 1;
		break;
	default:
		break;
	}
	
	// check if the slot is key on slot for synchronizing
	SyncMode = 0;
	switch (CacheYMF271.group_sync[SlotNum])
	{
	case 0:		// 4 slot mode
		if (Port == 0)
			SyncMode = 1;
		break;
	case 1:		// 2x 2 slot mode
		if (Port == 0 || Port == 1)
			SyncMode = 1;
		break;
	case 2:		// 3 slot + 1 slot mode
		if (Port == 0)
			SyncMode = 1;
		break;
	default:
		break;
	}
	
	ymf271_write_fm_reg(WriteStr, SlotReg, Data);
	
	if (SyncMode && SyncReg)		// key-on slot & synced register
	{
		switch(CacheYMF271.group_sync[SlotNum])
		{
		case 0:		// 4 slot mode
			sprintf(TempStr, "4-Slot (%u/%u/%u/%u): %s", (12 * 0) + SlotNum,
					(12 * 1) + SlotNum, (12 * 2) + SlotNum, (12 * 3) + SlotNum, WriteStr);
			break;
		case 1:		// 2x 2 slot mode
			if (Port == 0)		// Slot 1 - Slot 3
			{
				sprintf(TempStr, "2x 2-Slot (%u/%u): %s",
						(12 * 0) + SlotNum, (12 * 2) + SlotNum, WriteStr);
			}
			else				// Slot 2 - Slot 4
			{
				sprintf(TempStr, "2x 2-Slot (%u/%u): %s",
						(12 * 1) + SlotNum, (12 * 3) + SlotNum, WriteStr);
			}
			break;
		case 2:		// 3 slot + 1 slot mode
			// 1 slot is handled normally
			sprintf(TempStr, "3+1-Slot (%u/%u/%s): %s",
					(12 * 0) + SlotNum, (12 * 1) + SlotNum, (12 * 2) + SlotNum, WriteStr);
			break;
		default:
			sprintf(TempStr, "Invalid Sync: %s", WriteStr);
			break;
		}
	}
	else		// write register normally
	{
		sprintf(TempStr, "Slot %u: %s", (12 * Port) + SlotNum, WriteStr);
	}
	
	return;
}

void ymf271_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data)
{
	UINT8 SlotNum;
	UINT8 Addr;
	
	WriteChipID(0x0E);
	
	//sprintf(TempStr, "%sPort %x Reg 0x%02X Data 0x%02X", ChipStr, Port, Register, Data);
	
	switch(Port)
	{
	case 0x00:
	case 0x01:
	case 0x02:
	case 0x03:
		ymf271_write_fm(RedirectStr, Port, Register, Data);
		break;
	case 0x04:
		if ((Register & 0x03) == 0x03)
		{
			sprintf(WriteStr, "Invalid Slot");
		}
		else
		{
			SlotNum = ((Register & 0x0F) / 0x04 * 0x03) + (Register & 0x03);
			Addr = (Register >> 4) % 3;
			
			switch((Register >> 4) & 0x0F)
			{
			case 0:
			case 1:
			case 2:
				sprintf(RedirectStr, "Start Address %s: %02X", ADDR_3S_STR[Addr], Data);
				break;
			case 3:
			case 4:
			case 5:
				sprintf(RedirectStr, "End Address %s: %02X", ADDR_3S_STR[Addr], Data);
				break;
			case 6:
			case 7:
			case 8:
				sprintf(RedirectStr, "Loop Address %s: %02X", ADDR_3S_STR[Addr], Data);
				break;
			case 9:
				sprintf(RedirectStr, "FS: %u, Bits: %u, SrcNote: %u, SrcB: %u", Data & 0x03,
						(Data & 0x04) ? 12 : 8, (Data >> 3) & 0x03, (Data >> 5) & 0x07);
				break;
			default:
				sprintf(RedirectStr, "Invalid Register");
				break;
			}
			sprintf(WriteStr, "Slot %u %s", SlotNum, RedirectStr);
		}
		sprintf(RedirectStr, "PCM Write: %s", WriteStr);
		break;
	case 0x06:
		if (! (Register & 0xF0))
		{
			if ((Register & 0x03) == 0x03)
			{
				sprintf(RedirectStr, "Group Register: Invalid Channel");
				break;
			}
			
			SlotNum = ((Register & 0x0F) / 0x04 * 0x03) + (Register & 0x03);
			CacheYMF271.group_sync[SlotNum] = Data & 0x03;
			sprintf(RedirectStr, "Group Register: Slot %u, Sync Mode: %u", SlotNum, Data & 0x03);
		}
		else
		{
			switch (Register)
			{
			case 0x10:	// Timer A LSB
				sprintf(RedirectStr, "Timer A LSB: %02X", Data);
				break;
			case 0x11:	// Timer A MSB
				sprintf(RedirectStr, "Timer A MSB: %02X", Data & 0x03);
				break;
			case 0x12:	// Timer B
				sprintf(RedirectStr, "Timer B: %02X", Data);
				break;
			case 0x13:	// Timer A/B Load, Timer A/B IRQ Enable, Timer A/B Reset
				if (! (Data & 0x2F))
					sprintf(RedirectStr, "---");
				else
					strcpy(RedirectStr, "");
				
				if (Data & 0x01)
				{	// timer A load
					sprintf(RedirectStr, "%s, Load Timer A", RedirectStr);
				}
				if (Data & 0x02)
				{	// timer B load
					sprintf(RedirectStr, "%s, Load Timer B", RedirectStr);
				}
				if (Data & 0x04)
				{	// timer A IRQ enable
					sprintf(RedirectStr, "%s, Timer A IRQ Enable", RedirectStr);
				}
				if (Data & 0x08)
				{	// timer B IRQ enable
					sprintf(RedirectStr, "%s, Timer B IRQ Enable", RedirectStr);
				}
				if (Data & 0x10)
				{	// timer A reset
					sprintf(RedirectStr, "%s, Reset Timer A", RedirectStr);
				}
				if (Data & 0x20)
				{	// timer B reset
					sprintf(RedirectStr, "%s, Reset Timer B", RedirectStr);
				}
				break;
			case 0x14:
			case 0x15:
				sprintf(RedirectStr, "Set External Address %s: %02X",
						ADDR_3S_STR[Register & 0x03], Data);
				break;
			case 0x16:
				sprintf(RedirectStr, "Set External Address High: %02X, External Read: %s",
						Data & 0x7F, OnOff(~Data & 0x80));
				break;
			case 0x17:
				sprintf(RedirectStr, "External Write: Data %02X", Data);
				break;
			}
		}
		break;
	default:
		sprintf(RedirectStr, "Invalid Port");
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, RedirectStr);
	
	return;
}

void gb_sound_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	UINT8 TempByt;
	INT8 TempSByt;
	UINT32 StrPos;
	
	WriteChipID(0x13);
	
	switch(Register)
	{
	//MODE 1
	case NR10: // Sweep (R/W)
		TempSByt = (Data & 0x08) >> 3;
		TempSByt |= TempSByt - 1;	// 1 -> Dir 1, 0 -> Dir -1
		sprintf(WriteStr, "Ch 1 Sweep Shift: %hu, Sweep Dir: %hd, Sweep Time: %hu",
				Data & 0x07, TempSByt, (Data & 0x70) >> 4);
		break;
	case NR11: // Sound length/Wave pattern duty (R/W)
		sprintf(WriteStr, "Ch 1 Wave Pattern Duty: %hu%%, Sound Length: %hu",
				GB_WAVE_DUTY[(Data & 0xC0) >> 6], Data & 0x3F);
		break;
	case NR12: // Envelope (R/W)
		TempSByt = (Data & 0x08) >> 3;
		TempSByt |= TempSByt - 1;	// 1 -> Dir 1, 0 -> Dir -1
		sprintf(WriteStr, "Ch 1 Envelope Value: %hu, Env. Dir: %hd, Env. Length: %hu",
				(Data & 0xF0) >> 4, TempSByt, Data & 0x07);
		break;
	case NR13: // Frequency lo (R/W)
		sprintf(WriteStr, "Ch 1 Frequency LSB: %02hX", Data);
		break;
	case NR14: // Frequency hi / Initialize (R/W)
		sprintf(WriteStr, "Ch 1 Mode: %hu, Frequency MSB: %01hX",
				(Data & 0x40) >> 6, Data & 0x07);
		if (Data & 0x80)
			sprintf(WriteStr, "%s, Key On", WriteStr);
		break;
	//MODE 2
	case NR21: // Sound length/Wave pattern duty (R/W)
		sprintf(WriteStr, "Ch 2 Wave Pattern Duty: %hu%%, Sound Length: %hu",
				GB_WAVE_DUTY[(Data & 0xC0) >> 6], Data & 0x3F);
		break;
	case NR22: // Envelope (R/W)
		TempSByt = (Data & 0x08) >> 3;
		TempSByt |= TempSByt - 1;	// 1 -> Dir 1, 0 -> Dir -1
		sprintf(WriteStr, "Ch 2 Envelope Value: %hu, Env. Dir: %hd, Env. Length: %hu",
				(Data & 0xF0) >> 4, TempSByt, Data & 0x07);
		break;
	case NR23: // Frequency lo (R/W)
		sprintf(WriteStr, "Ch 2 Frequency LSB: %02hX", Data);
		break;
	case NR24: // Frequency hi / Initialize (R/W)
		sprintf(WriteStr, "Ch 2 Mode: %hu, Frequency MSB: %01hX",
				(Data & 0x40) >> 6, Data & 0x07);
		if (Data & 0x80)
			sprintf(WriteStr, "%s, Key On", WriteStr);
	//MODE 3
	case NR30: // Sound On/Off (R/W)
		sprintf(WriteStr, "Ch 3 Sound %s", OnOff(Data & 0x80));
		break;
	case NR31: // Sound Length (R/W)
		sprintf(WriteStr, "Ch 3 Sound Length: %hu", Data);
		break;
	case NR32: // Select Output Level
		TempByt = (Data & 0x60) >> 5;
		sprintf(WriteStr, "Ch 3 Output Level: %hX = %u%%", TempByt,
				100 * (0x03 - TempByt) / 0x03);
		break;
	case NR33: // Frequency lo (W)
		sprintf(WriteStr, "Ch 3 Frequency LSB: %02hX", Data);
		break;
	case NR34: // Frequency hi / Initialize (W)
		sprintf(WriteStr, "Ch 3 Mode: %hu, Frequency MSB: %01hX",
				(Data & 0x40) >> 6, Data & 0x07);
		if (Data & 0x80)
			sprintf(WriteStr, "%s, Key On", WriteStr);
		break;
	//MODE 4
	case NR41: // Sound Length (R/W)
		sprintf(WriteStr, "Ch N Sound Length: %hu", Data & 0x3F);
		break;
	case NR42: // Envelope (R/W)
		TempSByt = (Data & 0x08) >> 3;
		TempSByt |= TempSByt - 1;	// 1 -> Dir 1, 0 -> Dir -1
		sprintf(WriteStr, "Ch N Envelope Value: %hu, Env. Dir: %hd, Env. Length: %hu",
				(Data & 0xF0) >> 4, TempSByt, Data & 0x07);
		break;
	case NR43: // Polynomial Counter/Frequency
		sprintf(WriteStr, "Ch N Freq. Divider: %hu, Shift Freq.: %hu, Counter Size: %hu bit",
				Data & 0x07, (Data & 0xF0) >> 4, 0x08 + (Data & 0x08));
		break;
	case NR44: // Counter/Consecutive / Initialize (R/W)
		sprintf(WriteStr, "Ch N Mode: %s",
				GB_NOISE_MODE[(Data & 0x40) >> 6]);
		if (Data & 0x80)
			sprintf(WriteStr, "%s, Key On", WriteStr);
		break;
	// CONTROL
	case NR50: // Channel Control / On/Off / Volume (R/W)
		sprintf(WriteStr, "Master Volume L: %hu = %u%%, Volume R: %hu = %u%%",
				Data & 0x07, 100 * (Data & 0x07) / 0x07,
				(Data & 0x70) >> 4, 100 * (Data & 0x70) / 0x70);
		break;
	case NR51: // Selection of Sound Output Terminal
		sprintf(WriteStr, "Sound Output Left:\t");
		StrPos = strlen(WriteStr);
		for (TempByt = 0x00; TempByt < 0x04; TempByt ++)
		{
			if ((TempByt & 0x03) != 0x03)
				TempSByt = '0' + (TempByt & 0x03);
			else
				TempSByt = 'N';
			WriteStr[StrPos] = (Data & (0x10 << TempByt)) ? TempSByt : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		
		sprintf(WriteStr, "%s, Right:\t", WriteStr);
		StrPos = strlen(WriteStr);
		for (TempByt = 0x00; TempByt < 0x04; TempByt ++)
		{
			if ((TempByt & 0x03) != 0x03)
				TempSByt = '0' + (TempByt & 0x03);
			else
				TempSByt = 'N';
			WriteStr[StrPos] = (Data & (0x01 << TempByt)) ? TempSByt : '-';
			StrPos ++;
		}
		WriteStr[StrPos] = 0x00;
		break;
	case NR52: // Sound On/Off (R/W)
		/* Only bit 7 is writable, writing to bits 0-3 does NOT enable or
		   disable sound.  They are read-only */
		sprintf(WriteStr, "Sound %s", OnOff(Data & 0x80));
		if (Data & 0x80)
			sprintf(WriteStr, "%s (Reset Chip if chip was disabled)", WriteStr);
		break;
	default:
		sprintf(WriteStr, "Reg 0x%02X, Data 0x%02X", Register, Data);
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	
	return;
}

void nes_psg_write(char* TempStr, UINT8 Register, UINT8 Data)
{
	WriteChipID(0x14);
	
	switch(Register)
	{
	default:
		sprintf(WriteStr, "Reg 0x%02X, Data 0x%02X", Register, Data);
		break;
	}
	
	sprintf(TempStr, "%s%s", ChipStr, WriteStr);
	
	return;
}
