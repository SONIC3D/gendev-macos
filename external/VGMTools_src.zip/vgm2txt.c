// vgm2txt.c - VGM Text Writer
//

#include <stdio.h>
#include <stdlib.h>
#include "stdbool.h"
#include <string.h>
#include <math.h>	// for pow()

#ifdef WIN32
#include <conio.h>
#include <windows.h>	// for GetTickCount
#endif

#include "zlib.h"

#include "stdtype.h"
#include "VGMFile.h"


static bool OpenVGMFile(const char* FileName);
static void WriteVGM2Txt(const char* FileName);
static void WriteClockText(char* Buffer, UINT32 Clock, char* ChipName);
static void WriteVGMData2Txt(FILE* hFile);
static void PrintMinSec(const UINT32 SamplePos, char* TempStr);


void InitChips(UINT32* ChipCounts);
void SetChip(UINT8 ChipID);
void GGStereo(char* TempStr, UINT8 Data);
void sn76496_write(char* TempStr, UINT8 Command);
void ym2413_write(char* TempStr, UINT8 Register, UINT8 Data);
void ym2612_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void ym2151_write(char* TempStr, UINT8 Register, UINT8 Data);
void segapcm_mem_write(char* TempStr, UINT16 Offset, UINT8 Data);
void rf5c68_reg_write(char* TempStr, UINT8 Register, UINT8 Data);
void rf5c68_mem_write(char* TempStr, UINT16 Offset, UINT8 Data);
void ym2203_write(char* TempStr, UINT8 Register, UINT8 Data);
void ym2608_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void ym2610_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void ym3812_write(char* TempStr, UINT8 Register, UINT8 Data);
void ym3526_write(char* TempStr, UINT8 Register, UINT8 Data);
void y8950_write(char* TempStr, UINT8 Register, UINT8 Data);
void ymf262_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void ymz280b_write(char* TempStr, UINT8 Register, UINT8 Data);
void ymf278b_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void ymf271_write(char* TempStr, UINT8 Port, UINT8 Register, UINT8 Data);
void rf5c164_reg_write(char* TempStr, UINT8 Register, UINT8 Data);
void rf5c164_mem_write(char* TempStr, UINT16 Offset, UINT8 Data);
void ay8910_reg_write(char* TempStr, UINT8 Register, UINT8 Data);
void pwm_write(char* TempStr, UINT16 Port, UINT16 Data);
void gb_sound_write(char* TempStr, UINT8 Register, UINT8 Data);
void nes_psg_write(char* TempStr, UINT8 Register, UINT8 Data);


VGM_HEADER VGMHead;
UINT32 VGMDataLen;
UINT8* VGMData;
UINT32 VGMPos;
INT32 VGMSmplPos;
INT32 VGMWriteFrom;
INT32 VGMWriteTo;
char FileBase[0x100];

int main(int argc, char* argv[])
{
	int ErrVal;
	UINT32 TimeMin;
	UINT32 TimeSec;
	UINT32 TimeMS;
	char FileName[0x100];
	
	printf("VGM Text Writer\n---------------\n\n");
	
	ErrVal = 0;
	printf("File Name:\t");
	if (argc <= 0x01)
	{
		gets(FileName);
	}
	else
	{
		strcpy(FileName, argv[0x01]);
		printf("%s\n", FileName);
	}
	if (! strlen(FileName))
		return 0;
	
	if (! OpenVGMFile(FileName))
	{
		printf("Error opening the file!\n");
		ErrVal = 1;
		goto EndProgram;
	}
	printf("\n");
	
	TimeMin = TimeSec = TimeMS = 0;
	printf("Start Time:\t");
	if (argc <= 0x02)
		gets(FileName);
	else
		strcpy(FileName, argv[0x02]);
	sscanf(FileName, "%02lu:%02lu.%02lu", &TimeMin, &TimeSec, &TimeMS);
	VGMWriteFrom = (TimeMin * 6000 + TimeSec * 100 + TimeMS) * 441;
	
	TimeMin = TimeSec = TimeMS = 0;
	printf("End Time:\t");
	if (argc <= 0x03)
		gets(FileName);
	else
		strcpy(FileName, argv[0x03]);
	sscanf(FileName, "%02lu:%02lu.%02lu", &TimeMin, &TimeSec, &TimeMS);
	VGMWriteTo = (TimeMin * 6000 + TimeSec * 100 + TimeMS) * 441;
	//if (! VGMWriteTo)
	//	VGMWriteTo = VGMHead.lngTotalSamples;
	
	strcpy(FileName, FileBase);
	strcat(FileName, ".txt");
	WriteVGM2Txt(FileName);
	
	free(VGMData);
	
EndProgram:
#ifdef WIN32
	if (argv[0][1] == ':')
	{
		// Executed by Double-Clicking (or Drap and Drop)
		if (_kbhit())
			_getch();
		_getch();
	}
#endif
	
	return ErrVal;
}

static bool OpenVGMFile(const char* FileName)
{
	gzFile hFile;
	UINT32 CurPos;
	UINT32 TempLng;
	char* TempPnt;
	
	hFile = gzopen(FileName, "rb");
	if (hFile == NULL)
		return false;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &TempLng, 0x04);
	if (TempLng != FCC_VGM)
		goto OpenErr;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &VGMHead, sizeof(VGM_HEADER));
	
	// Header preperations
	if (VGMHead.lngVersion < 0x00000101)
	{
		VGMHead.lngRate = 0;
	}
	if (VGMHead.lngVersion < 0x00000110)
	{
		VGMHead.shtPSG_Feedback = 0x0000;
		VGMHead.bytPSG_SRWidth = 0x00;
		VGMHead.lngHzYM2612 = VGMHead.lngHzYM2413;
		VGMHead.lngHzYM2151 = VGMHead.lngHzYM2413;
		VGMHead.lngHzYM2612 = 0x00000000;
		VGMHead.lngHzYM2151 = 0x00000000;
	}
	if (VGMHead.lngVersion < 0x00000150)
	{
		VGMHead.lngDataOffset = 0x00000000;
	}
	if (VGMHead.lngVersion < 0x00000151)
	{
		VGMHead.lngHzSPCM = 0x0000;
		VGMHead.lngSPCMIntf = 0x00000000;
		// all others are zeroed by memset
	}
	// relative -> absolute addresses
	VGMHead.lngEOFOffset += 0x00000004;
	if (VGMHead.lngGD3Offset)
		VGMHead.lngGD3Offset += 0x00000014;
	if (VGMHead.lngLoopOffset)
		VGMHead.lngLoopOffset += 0x0000001C;
	if (! VGMHead.lngDataOffset)
		VGMHead.lngDataOffset = 0x0000000C;
	VGMHead.lngDataOffset += 0x00000034;
	
	CurPos = VGMHead.lngDataOffset;
	if (VGMHead.lngVersion < 0x00000150)
		CurPos = 0x40;
	TempLng = sizeof(VGM_HEADER);
	if (TempLng > CurPos)
		TempLng -= CurPos;
	else
		TempLng = 0x00;
	memset((UINT8*)&VGMHead + CurPos, 0x00, TempLng);
	
	// Read Data
	VGMDataLen = VGMHead.lngEOFOffset;
	VGMData = (UINT8*)malloc(VGMDataLen);
	if (VGMData == NULL)
		goto OpenErr;
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, VGMData, VGMDataLen);
	
	gzclose(hFile);
	
	strcpy(FileBase, FileName);
	TempPnt = strrchr(FileBase, '.');
	if (TempPnt != NULL)
		*TempPnt = 0x00;
	
	return true;

OpenErr:

	gzclose(hFile);
	return false;
}

static void WriteVGM2Txt(const char* FileName)
{
	const char* AY_NAMES[0x08] = {
		"AY-3-8910A", "AY-3-8912A", "AY-3-8913A", "AY8930", "YM2149", "YM3439", "YMZ284",
		"YMZ294"};
	FILE* hFile;
	UINT32 TempLng;
	char TempStr[0x80];
	INT16 TempSSht;
	double TempDbl;
	
	memset(TempStr, 0x00, 0x80);
	
	hFile = fopen(FileName, "wt");
	if (hFile == NULL)
		return;
	
	fprintf(hFile, "VGM Header:\n");
	memcpy(TempStr, &VGMData[0x00], 0x04);
	fprintf(hFile, "VGM Signature:\t\t\"%s\"\n", TempStr);
	fprintf(hFile, "File Version:\t\t0x%08lX (%lu.%02lX)\n", VGMHead.lngVersion,
					VGMHead.lngVersion >> 8, VGMHead.lngVersion & 0xFF);
	fprintf(hFile, "EOF Offset:\t\t0x%08lX (absolute)\n", VGMHead.lngEOFOffset);
	fprintf(hFile, "GD3 Tag Offset:\t\t0x%08lX (absolute)\n", VGMHead.lngGD3Offset);
	fprintf(hFile, "Data Offset:\t\t0x%08lX (absolute)\n", VGMHead.lngDataOffset);
	
	PrintMinSec(VGMHead.lngTotalSamples, TempStr);
	fprintf(hFile, "Total Length:\t\t%lu samples (%s s)\n", VGMHead.lngTotalSamples, TempStr);
	fprintf(hFile, "Loop Point Offset:\t0x%08lX (absolute)\n", VGMHead.lngLoopOffset);
	if (VGMHead.lngLoopSamples)
		TempLng = VGMHead.lngTotalSamples - VGMHead.lngLoopSamples;
	else
		TempLng = 0;
	PrintMinSec(TempLng, TempStr);
	fprintf(hFile, "Loop Start:\t\t%lu samples (%s s)\n", TempLng, TempStr);
	PrintMinSec(VGMHead.lngLoopSamples, TempStr);
	fprintf(hFile, "Loop Length:\t\t%lu samples (%s s)\n", VGMHead.lngLoopSamples, TempStr);
	fprintf(hFile, "Recording Rate:\t\t%lu Hz\n", VGMHead.lngRate);
	
	sprintf(TempStr, "%lu Hz", VGMHead.lngHzPSG & 0x3FFFFFF);
	if (VGMHead.lngHzPSG & 0x40000000)
	{
		if (VGMHead.lngHzPSG & 0x80000000)
			sprintf(TempStr, "%s - T6W28", TempStr);
		else
			sprintf(TempStr, "%s - Dual %s", TempStr, "SN76496");
	}
	else if (! VGMHead.lngHzPSG)
	{
		sprintf(TempStr, "%s - unused", TempStr);
	}
	fprintf(hFile, "SN76496 Clock:\t\t%s\n", TempStr);
	fprintf(hFile, "SN76496 Feedback:\t0x%02hX\n", VGMHead.shtPSG_Feedback);
	fprintf(hFile, "SN76496 ShiftRegWidth:\t%hu bits\n", VGMHead.bytPSG_SRWidth);
	fprintf(hFile, "SN76496 Flags:\t\t0x%02hX\n", VGMHead.bytPSG_Flags);
	
	WriteClockText(TempStr, VGMHead.lngHzYM2413, "YM2413");
	fprintf(hFile, "YM2413 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYM2612, "YM2612");
	fprintf(hFile, "YM2612 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYM2151, "YM2151");
	fprintf(hFile, "YM2151 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzSPCM & 0x3FFFFFFF, NULL);
	fprintf(hFile, "SegaPCM Clock:\t\t%s\n", TempStr);
	fprintf(hFile, "SegaPCM Interface:\t0x%08lX\n", VGMHead.lngSPCMIntf);
	
	WriteClockText(TempStr, VGMHead.lngHzRF5C68 & 0x3FFFFFFF, NULL);
	fprintf(hFile, "RF5C68 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYM2203, "YM2203");
	fprintf(hFile, "YM2203 Clock:\t\t%s\n", TempStr);
	fprintf(hFile, "YM2203 AY8910 Flags:\t0x%02hX\n", VGMHead.bytAYFlagYM2203);
	
	WriteClockText(TempStr, VGMHead.lngHzYM2608, "YM2608");
	fprintf(hFile, "YM2608 Clock:\t\t%s\n", TempStr);
	fprintf(hFile, "YM2608 AY8910 Flags:\t0x%02hX\n", VGMHead.bytAYFlagYM2608);
	
	sprintf(TempStr, "%lu Hz", VGMHead.lngHzYM2610 & 0x3FFFFFF);
	if (VGMHead.lngHzYM2610 & 0x80000000)
		sprintf(TempStr, "%s (YM2610B Mode)", TempStr);
	if (VGMHead.lngHzYM2610 & 0x40000000)
		sprintf(TempStr, "%s - Dual %s", TempStr, "YM2610");
	else if (! VGMHead.lngHzYM2610)
		sprintf(TempStr, "%s - unused", TempStr);
	fprintf(hFile, "YM2610 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYM3812, "YM3812");
	fprintf(hFile, "YM3812 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYM3526, "YM3526");
	fprintf(hFile, "YM3526 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzY8950, "Y8950");
	fprintf(hFile, "Y8950 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYMF262 & 0x3FFFFFFF, NULL);
	fprintf(hFile, "YMF262 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYMF278B & 0x3FFFFFFF, NULL);
	fprintf(hFile, "YMF278B Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYMF271 & 0x3FFFFFFF, NULL);
	fprintf(hFile, "YMF271 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzYMZ280B & 0x3FFFFFFF, NULL);
	fprintf(hFile, "YMZ280B Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzRF5C164 & 0x3FFFFFFF, NULL);
	fprintf(hFile, "RF5C164 Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzPWM & 0x3FFFFFFF, NULL);
	fprintf(hFile, "PWM Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzAY8910 & 0x3FFFFFFF, NULL);
	fprintf(hFile, "AY8910 Clock:\t\t%s\n", TempStr);
	if (VGMHead.bytAYType & ~0x13)
		fprintf(hFile, "AY8910 Type:\t\t0x%02hX - %s\n", "???", VGMHead.bytAYType);
	else
		fprintf(hFile, "AY8910 Type:\t\t0x%02hX - %s\n", VGMHead.bytAYType,
				AY_NAMES[(VGMHead.bytAYType >> 2) | VGMHead.bytAYType]);
	fprintf(hFile, "AY8910 Flags:\t\t0x%02hX\n", VGMHead.bytAYFlag);
	
	if (VGMHead.bytVolumeModifier <= VOLUME_MODIF_WRAP)
		TempSSht = VGMHead.bytVolumeModifier;
	else if (VGMHead.bytVolumeModifier == (VOLUME_MODIF_WRAP + 0x01))
		TempSSht = VOLUME_MODIF_WRAP - 0x100;
	else
		TempSSht = VGMHead.bytVolumeModifier - 0x100;
	TempDbl = pow(2.0, TempSSht / (double)0x20);
	fprintf(hFile, "Volume Modifier:\t0x%02hX (%hd) = %.3f\n", VGMHead.bytVolumeModifier,
			TempSSht, TempDbl);
	
	fprintf(hFile, "Reserved (0x7D):\t0x%02hX\n", VGMHead.bytReserved2);
	
	if (VGMHead.bytLoopBase > 0)
		TempStr[0x00] = '+';
	else if (VGMHead.bytLoopBase < 0)
		TempStr[0x00] = '-';
	else
		TempStr[0x00] = '�';	// 0xF1
	fprintf(hFile, "Loop Base:\t\t0x%02hX = %c%hd\n", VGMHead.bytLoopBase, TempStr[0x00],
			VGMHead.bytLoopBase);
	
	TempDbl = TempSSht / 16.0;
	fprintf(hFile, "Loop Modifier:\t\t0x%02hX (MaxLoops * %.2f)\n", VGMHead.bytLoopModifier,
			TempDbl);
	
	WriteClockText(TempStr, VGMHead.lngHzGBDMG & 0x3FFFFFFF, NULL);
	fprintf(hFile, "GB DMG Clock:\t\t%s\n", TempStr);
	
	WriteClockText(TempStr, VGMHead.lngHzNESAPU & 0x3FFFFFFF, NULL);
	fprintf(hFile, "NES APU Clock:\t\t%s\n", TempStr);
	
	fprintf(hFile, "\n");
	fprintf(hFile, "VGMData:\n");
	VGMPos = VGMHead.lngDataOffset;
	VGMSmplPos = 0;
	
#ifndef _DEBUG
	__try
	{
#endif
		WriteVGMData2Txt(hFile);
#ifndef _DEBUG
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		printf("Program Error!\n");
	}
#endif
	
	fclose(hFile);
	
	printf("File written.\n");
	
	return;
}

static void WriteClockText(char* Buffer, UINT32 Clock, char* ChipName)
{
	sprintf(Buffer, "%lu Hz", Clock & 0x3FFFFFF);
	if (Clock & 0x40000000)
		sprintf(Buffer, "%s - Dual %s", Buffer, ChipName);
	else if (! Clock)
		sprintf(Buffer, "%s - unused", Buffer);
	
	return;
}

static void WriteVGMData2Txt(FILE* hFile)
{
	UINT32 CmdTimer;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 ROMSize;
	UINT32 DataStart;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	bool WriteEvents;
	UINT32 ChipCounters[0x10];
	UINT8 ChipID;
	
	for (TempByt = 0x00; TempByt < 0x10; TempByt ++)
	{
		switch(TempByt)
		{
		case 0x00:
			TempLng = VGMHead.lngHzPSG;
			break;
		case 0x01:
			TempLng = VGMHead.lngHzYM2413;
			break;
		case 0x02:
			TempLng = VGMHead.lngHzYM2612;
			break;
		case 0x03:
			TempLng = VGMHead.lngHzYM2151;
			break;
		case 0x04:
			TempLng = VGMHead.lngHzSPCM;
			break;
		case 0x05:
			TempLng = VGMHead.lngHzRF5C68;
			break;
		case 0x06:
			TempLng = VGMHead.lngHzYM2203;
			break;
		case 0x07:
			TempLng = VGMHead.lngHzYM2608;
			break;
		case 0x08:
			TempLng = VGMHead.lngHzYM2610;
			break;
		case 0x09:
			TempLng = VGMHead.lngHzYM3812;
			break;
		case 0x0A:
			TempLng = VGMHead.lngHzYM3526;
			break;
		case 0x0B:
			TempLng = VGMHead.lngHzY8950;
			break;
		case 0x0C:
			TempLng = VGMHead.lngHzYMF262;
			break;
		case 0x0D:
			TempLng = VGMHead.lngHzYMF278B;
			break;
		case 0x0E:
			TempLng = VGMHead.lngHzYMF271;
			break;
		case 0x0F:
			TempLng = VGMHead.lngHzYMZ280B;
			break;
		case 0x10:
			TempLng = VGMHead.lngHzRF5C164;
			break;
		case 0x11:
			TempLng = VGMHead.lngHzPWM;
			break;
		case 0x12:
			TempLng = VGMHead.lngHzAY8910;
			break;
		case 0x13:
			TempLng = VGMHead.lngHzGBDMG;
			break;
		case 0x14:
			TempLng = VGMHead.lngHzNESAPU;
			break;
		default:
			TempLng = 0x00;
			break;
		}
		if (TempLng)
		{
			TempSht = (TempLng & 0x40000000) ? 0x02 : 0x01;
			TempLng = (TempLng & 0x80000000) | TempSht;
		}
		ChipCounters[TempByt] = TempLng;
	}
	InitChips(ChipCounters);
	
	CmdTimer = 0;
	StopVGM = false;
	WriteEvents = (VGMSmplPos >= VGMWriteFrom);
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				WriteEvents = (VGMSmplPos >= VGMWriteFrom);
				if (WriteEvents)
				{
					PrintMinSec(VGMSmplPos, MinSecStr);
					sprintf(TempStr, "Wait:\t%2hu sample(s) (   %03.2f ms)\t(total\t%lu (%s))",
							TempSht, TempSht / 44.1, VGMSmplPos, MinSecStr);
				}
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				WriteEvents = (VGMSmplPos >= VGMWriteFrom);
				if (WriteEvents)
				{
					PrintMinSec(VGMSmplPos, MinSecStr);
					sprintf(TempStr, "Wait:\t%2hu sample(s) (   %03.2f ms)\t(total\t%lu (%s))",
							TempSht, TempSht / 44.1, VGMSmplPos, MinSecStr);
				}
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			// Cheat Mode (to use 2 instances of 1 chip)
			ChipID = 0x00;
			switch(Command)
			{
			case 0x30:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x20;
					ChipID = 0x01;
				}
				break;
			case 0x3F:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x10;
					ChipID = 0x01;
				}
				break;
			case 0xA1:
				if (VGMHead.lngHzYM2413 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA2:
			case 0xA3:
				if (VGMHead.lngHzYM2612 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA4:
				if (VGMHead.lngHzYM2151 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA5:
				if (VGMHead.lngHzYM2203 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA6:
			case 0xA7:
				if (VGMHead.lngHzYM2608 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA8:
			case 0xA9:
				if (VGMHead.lngHzYM2610 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAA:
				if (VGMHead.lngHzYM3812 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAB:
				if (VGMHead.lngHzYM3526 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAC:
				if (VGMHead.lngHzY8950 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAE:
			case 0xAF:
				if (VGMHead.lngHzYMF262 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAD:
				if (VGMHead.lngHzYMZ280B & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			}
			SetChip(ChipID);
			
			switch(Command)
			{
			case 0x66:	// End Of File
				sprintf(TempStr, "End of Data");
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				WriteEvents = (VGMSmplPos >= VGMWriteFrom);
				if (WriteEvents)
				{
					PrintMinSec(VGMSmplPos, MinSecStr);
					sprintf(TempStr, "Wait:\t%hu samples (1/60 s)\t(total\t%lu (%s))",
							TempSht, VGMSmplPos, MinSecStr);
				}
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				WriteEvents = (VGMSmplPos >= VGMWriteFrom);
				if (WriteEvents)
				{
					PrintMinSec(VGMSmplPos, MinSecStr);
					sprintf(TempStr, "Wait:\t%hu samples (1/50 s)\t(total\t%lu (%s))",
							TempSht, VGMSmplPos, MinSecStr);
				}
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				WriteEvents = (VGMSmplPos >= VGMWriteFrom);
				if (WriteEvents)
				{
					PrintMinSec(VGMSmplPos, MinSecStr);
					sprintf(TempStr, "Wait:\t%hu samples (   %03.2f ms)\t(total\t%lu (%s))",
							TempSht, TempSht / 44.1, VGMSmplPos, MinSecStr);
				}
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
				if (WriteEvents)
				{
					sn76496_write(TempStr, VGMData[VGMPos + 0x01]);
				}
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				if (WriteEvents)
				{
					ym2413_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				if (WriteEvents)
				{
					ym2612_write(TempStr, Command & 0x01, VGMData[VGMPos + 0x01],
								VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x67:	// Data Block (PCM Data Stream)
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&TempLng, &VGMData[VGMPos + 0x03], 0x04);
				if (WriteEvents)
				{
					switch(TempByt & 0xC0)
					{
					case 0x00:	// Database Block
					case 0x40:
						DataLen = TempLng;
						switch(TempByt)
						{
						case 0x00:	// YM2612 PCM Database
							strcpy(MinSecStr, "YM2612 PCM Database");
							break;
						case 0x01:	// RF5C68 PCM Database
							strcpy(MinSecStr, "RF5C68 PCM Database");
							break;
						case 0x02:	// RF5C164 PCM Database
							strcpy(MinSecStr, "RF5C164 PCM Database");
							break;
						default:
							strcpy(MinSecStr, "Unknown Database Type");
							break;
						}
						break;
					case 0x80:	// ROM/RAM Dump
						memcpy(&ROMSize, &VGMData[VGMPos + 0x07], 0x04);
						memcpy(&DataStart, &VGMData[VGMPos + 0x0B], 0x04);
						DataLen = TempLng - 0x08;
						switch(TempByt)
						{
						case 0x80:	// SegaPCM ROM
							strcpy(MinSecStr, "SegaPCM ROM");
							break;
						case 0x81:	// YM2608 DELTA-T ROM Image
							strcpy(MinSecStr, "YM2608 DELTA-T ROM");
							break;
						case 0x82:	// YM2610 ADPCM ROM Image
							strcpy(MinSecStr, "YM2610 ADPCM ROM");
							break;
						case 0x83:	// YM2610 DELTA-T ROM Image
							strcpy(MinSecStr, "YM2610 DELTA-T ROM");
							break;
						case 0x84:	// YMF278B ROM Image
							strcpy(MinSecStr, "YMF278B ROM");
							break;
						case 0x85:	// YMF271 ROM Image
							strcpy(MinSecStr, "YMF271 ROM");
							break;
						case 0x86:	// YMZ280B ROM Image
							strcpy(MinSecStr, "YMZ280B ROM");
							break;
						case 0x87:	// YMF278B RAM Image
							strcpy(MinSecStr, "YMF278B ROM");
							break;
						default:
							strcpy(MinSecStr, "Unknown ROM Type");
							break;
						}
						break;
					case 0xC0:	// RAM Write
						memcpy(&TempSht, &VGMData[VGMPos + 0x07], 0x02);
						DataLen = TempLng - 0x02;
						switch(TempByt)
						{
						case 0xC0:	// RF5C68 PCM Data
							strcpy(MinSecStr, "RF5C68 RAM Data");
							break;
						case 0xC1:	// RF5C164 PCM Data
							strcpy(MinSecStr, "RF5C164 RAM Data");
							break;
						default:
							strcpy(MinSecStr, "Unknown RAM Data");
							break;
						}
						break;
					}
					
					sprintf(TempStr, "Data Block - Type %02hX: %s\n"
									"\t\t\tData Length: 0x%08lX", TempByt, MinSecStr, DataLen);
					switch(TempByt & 0xC0)
					{
					case 0x00:	// Database Block
					case 0x40:
						break;
					case 0x80:	// ROM/RAM Dump
						sprintf(TempStr, "%s\n\t\t\tROM Size: 0x%08lX\tData Start: 0x%08lX",
								TempStr, ROMSize, DataStart);
						break;
					case 0xC0:	// RAM Write
						sprintf(TempStr, "%s\t\tWrite to Address: 0x%04hX",
								TempStr, TempSht);
						break;
					}
				}
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				memcpy(&TempLng, &VGMData[VGMPos + 0x01], 0x04);
				if (WriteEvents)
				{
					sprintf(TempStr, "Seek to PCM Data Bank Pos: %08lX", TempLng);
				}
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				if (WriteEvents)
				{
					GGStereo(TempStr, VGMData[VGMPos + 0x01]);
				}
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				if (WriteEvents)
				{
					ym2151_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				if (WriteEvents)
				{
					segapcm_mem_write(TempStr, TempSht, VGMData[VGMPos + 0x03]);
				}
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
				if (WriteEvents)
				{
					rf5c68_reg_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				if (WriteEvents)
				{
					rf5c68_mem_write(TempStr, TempSht, VGMData[VGMPos + 0x03]);
				}
				CmdLen = 0x04;
				break;
			case 0x55:	// YM2203
				if (WriteEvents)
				{
					ym2203_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				if (WriteEvents)
				{
					ym2608_write(TempStr, Command & 0x01, VGMData[VGMPos + 0x01],
								VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				if (WriteEvents)
				{
					ym2610_write(TempStr, Command & 0x01, VGMData[VGMPos + 0x01],
								VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				if (WriteEvents)
				{
					ym3812_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				if (WriteEvents)
				{
					ym3526_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				if (WriteEvents)
				{
					y8950_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				if (WriteEvents)
				{
					ymf262_write(TempStr, Command & 0x01, VGMData[VGMPos + 0x01],
								VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				if (WriteEvents)
				{
					ymz280b_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xD0:	// YMF278B write
				if (WriteEvents)
				{
					ymf278b_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02],
									VGMData[VGMPos + 0x03]);
				}
				CmdLen = 0x04;
				break;
			case 0xD1:	// YMF271 write
				if (WriteEvents)
				{
					ymf271_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02],
								VGMData[VGMPos + 0x03]);
				}
				CmdLen = 0x04;
				break;
			case 0xB1:	// RF5C164 register write
				if (WriteEvents)
				{
					rf5c164_reg_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xC2:	// RF5C164 memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				if (WriteEvents)
				{
					rf5c164_mem_write(TempStr, TempSht, VGMData[VGMPos + 0x03]);
				}
				CmdLen = 0x04;
				break;
			case 0x68:	// PCM RAM write
				if (WriteEvents)
				{
					TempByt = VGMData[VGMPos + 0x02];
					DataStart = TempLng = DataLen = 0x00;
					memcpy(&DataStart, &VGMData[VGMPos + 0x03], 0x03);
					memcpy(&TempLng, &VGMData[VGMPos + 0x06], 0x03);
					memcpy(&DataLen, &VGMData[VGMPos + 0x09], 0x03);
					if (! DataLen)
						DataLen += 0x01000000;
					switch(TempByt)
					{
					case 0x01:	// RF5C68 PCM Database
						strcpy(MinSecStr, "RF5C68");
						break;
					case 0x02:	// RF5C164 PCM Database
						strcpy(MinSecStr, "RF5C164");
						break;
					default:
						strcpy(MinSecStr, "Unknown chip");
						break;
					}
					sprintf(TempStr, "PCM RAM write:\t%s\n"
									"\t\t\tCopy 0x%06lX Bytes from 0x%06lX (Database) "
									"to 0x%06lX (RAM)",
									MinSecStr, DataLen, DataStart, TempLng);
				}
				CmdLen = 0x0C;
				break;
			case 0xB2:	// PWM register write
				if (WriteEvents)
				{
					pwm_write(TempStr, (VGMData[VGMPos + 0x01] & 0xF0) >> 4,
										(VGMData[VGMPos + 0x01] & 0x0F) << 8 |
										(VGMData[VGMPos + 0x02] << 0));
				}
				CmdLen = 0x03;
				break;
			case 0xA0:	// AY8910 register write
				if (WriteEvents)
				{
					ay8910_reg_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xB3:	// GameBoy DMG write
				if (WriteEvents)
				{
					gb_sound_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			case 0xB4:	// NES APU write
				if (WriteEvents)
				{
					nes_psg_write(TempStr, VGMData[VGMPos + 0x01], VGMData[VGMPos + 0x02]);
				}
				CmdLen = 0x03;
				break;
			default:
				if (WriteEvents)
				{
					sprintf(TempStr, "Unknown command: %02hX", Command);
				}
				
				switch(Command & 0xF0)
				{
				case 0x30:
					CmdLen = 0x02;
					break;
				case 0x40:
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		if (WriteEvents)
		{
			if (VGMPos == VGMHead.lngLoopOffset)
				fprintf(hFile, "--- Loop Point ---\n");
			for (TempLng = 0x00; TempLng < CmdLen; TempLng ++)
			{
				if ((Command == 0x67 || Command == 0x68) && TempLng >= 0x03)
					break;
				if (TempLng >= 0x04)
					break;
				sprintf(MinSecStr + TempLng * 0x03, "%02hX ", VGMData[VGMPos + TempLng]);
			}
			if (TempLng < 0x04)
				memset(MinSecStr + TempLng * 0x03, ' ', (0x04 - TempLng) * 0x03);
			MinSecStr[0x04 * 0x03 - 0x01] = 0x00;
			
			fprintf(hFile, "0x%08lX: %s %s\n", VGMPos, MinSecStr, TempStr);
		}
		if (VGMWriteTo && VGMSmplPos > VGMWriteTo)
			StopVGM = true;
		
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			if (VGMSmplPos >= VGMWriteFrom)
				TempLng = VGMSmplPos - VGMWriteFrom;
			else
				TempLng = 0;
			if (VGMWriteTo)
				ROMSize = VGMWriteTo - VGMWriteFrom;
			else
				ROMSize = VGMHead.lngTotalSamples - VGMWriteFrom;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / ROMSize * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	printf("\t\t\t\t\t\t\t\t\r");
	
	return;
}

static void PrintMinSec(const UINT32 SamplePos, char* TempStr)
{
	double TimeSec;
	UINT16 TimeMin;
	
	TimeSec = (double)SamplePos / 44100.0f;
	TimeMin = (UINT16)TimeSec / 60;
	TimeSec -= TimeMin * 60;
	TimeSec = (UINT32)(TimeSec * 100.0f) / 100.0f;
	sprintf(TempStr, "%02hu:%05.2f", TimeMin, TimeSec);
	
	return;
}
