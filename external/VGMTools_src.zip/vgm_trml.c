// vgm_trml.c - VGM Trimming Library
//
#include <stdio.h>
#include <stdlib.h>
#include "stdbool.h"
#include <memory.h>

//#define SHOW_PROGRESS

#ifdef SHOW_PROGRESS

#ifdef WIN32
#include <windows.h>	// for GetTickCount
#endif

#endif

#include "zlib.h"

#include "stdtype.h"
#include "VGMFile.h"


void TrimVGMData(const INT32 StartSmpl, const INT32 LoopSmpl, const INT32 EndSmpl,
				 const bool HasLoop, const bool KeepESmpl);
static void WriteVGMHeader(UINT8* DstData, const UINT8* SrcData, const UINT32 EOFPos,
						   const UINT32 SampleCount, const UINT32 LoopPos,
						   const UINT32 LoopSmpls);
#ifdef SHOW_PROGRESS
static void PrintMinSec(const UINT32 SamplePos, char* TempStr);
#endif
static void VGMReadAhead(const UINT32 StartPos, const UINT32 Samples);


#define CHIP_SETS	0x02

// Rewritten Registers:
//	- PSG: NoiseMode (Reg 0xE?) / GG Stereo
//	- YM2612: LFO Frequency (Reg 0x22) / Ch 3 Mode (Reg 0x27) / DAC Enable (Reg 0x02B)
//	- YM2151: LFO Frequency (0x18) / LFO Amplitude/Phase Modul (Reg 0x19) / LFO Wave Select (Reg 0x1B)
//Todo: YM2151 AM/PM Reg 0x19 (needs 2 writes, [(Data & 0x80) >> 7] )
//	- RF5C68: Memory Bank Register (0x07) [handled in RF5Cxx Rewrite Routine]
//FarTodo: RF5Cxx Channel Address Registers
//	- YM2203: Ch 3 Mode (Reg 0x27)
//	- YM2608: LFO Frequency (Reg 0x22) / Ch 3 Mode (Reg 0x27) / ADPCM Volume (Reg 0x011) / Delta-T Volume (Reg 0x10B)
//	- YM2610: LFO Frequency (Reg 0x22) / Ch 3 Mode (Reg 0x27) / ADPCM Volume (Reg 0x101) / Delta-T Volume (Reg 0x01B)
//	- YM3812/YM3526/Y8950: Wave Select (Reg 0x01) / CSM/KeySplit (Reg 0x08) / Rhythm/AM/FM (Reg 0xBD)
//	- YMF262/YMF278B: Wave Select (Reg 0x001) / CSM/KeySplit (Reg 0x008) / Rhythm/AM/FM (Reg 0x0BD) / OPL3/4 Mode Enable (Reg 0x105) / 4-Ch-Mode (Reg 0x104)
//	- Y8950: Delta-T Volume (Reg 0x12)
//	- YMZ280B: Key On Enable (Reg 0xFF)
//	- YMF271: Group Registers (Reg 0x600 - 0x60F)
//	- RF5C164: Memory Bank Register (0x07) [handled in RF5Cxx Rewrite Routine]
//	- GB DMG: Control Regs (0x14 - 0x16), WaveRAM (0x20 - 0x2F)
#define RR_SN76496_NoiseMode	0xE0
#define RR_YM2612_LFOFreq		0x022
#define RR_YM2612_Mode			0x027
#define RR_YM2612_DACEn			0x02B
#define RR_YM2151_LFOFreq		0x18
#define RR_YM2151_LFOMod		0x19
#define RR_YM2151_LFOWaveSel	0x1B
//#define RR_RF5C68_MemoryReg	0x07	// handled by RewriteRF5Cxx
#define RR_YM2203_Mode			0x27
#define RR_YM2608_LFOFreq		0x022
#define RR_YM2608_Mode			0x027
#define RR_YM2608_ADPCMVol		0x011
#define RR_YM2608_DeltaTVol		0x10B
#define RR_YM2610_LFOFreq		0x022
#define RR_YM2610_Mode			0x027
#define RR_YM2610_ADPCMVol		0x101
#define RR_YM2610_DeltaTVol		0x01B
#define RR_YM3812_WaveSelect	0x01
#define RR_YM3812_CSMKeySplt	0x08
#define RR_YM3812_RhythmReg		0xBD
#define RR_YM3526_WaveSelect	RR_YM3812_WaveSelect
#define RR_YM3526_CSMKeySplt	RR_YM3812_CSMKeySplt
#define RR_YM3526_RhythmReg		RR_YM3812_RhythmReg
#define RR_Y8950_WaveSelect		RR_YM3812_WaveSelect
#define RR_Y8950_CSMKeySplt		RR_YM3812_CSMKeySplt
#define RR_Y8950_DeltaTVol		0x12
#define RR_Y8950_RhythmReg		RR_YM3812_RhythmReg
#define RR_YMF262_WaveSelect	(0x000 | RR_YM3812_WaveSelect)
#define RR_YMF262_CSMKeySplt	(0x000 | RR_YM3812_CSMKeySplt)
#define RR_YMF262_RhythmReg		(0x000 | RR_YM3812_RhythmReg)
#define RR_YMF278B_WaveSelect	RR_YMF262_WaveSelect
#define RR_YMF278B_CSMKeySplt	RR_YMF262_CSMKeySplt
#define RR_YMF278B_RhythmReg	RR_YMF262_RhythmReg
#define RR_YMF262_OPLMode		0x105
#define RR_YMF262_4ChMode		0x104
#define RR_YMF278B_OPLMode		RR_YMF262_OPLMode
#define RR_YMF278B_4ChMode		RR_YMF262_4ChMode
#define RR_YMZ280B_KeyOnEnable	0xFF
#define RR_YMF271_GroupPort		0x06
//#define RR_RF5C164_MemoryReg	0x07	// handled by RewriteRF5Cxx
#define RR_PWM_Control_Reg		0x00
#define RR_PWM_Cycle_Reg		0x01
#define RR_GBDMG_Ctrl_Regs		0x14
#define RR_GBDMG_WaveRAM		0x20


typedef struct rewrite_commands
{
	UINT8 SN76496_NoiseMode;
	UINT8 SN76496_GGStereo;
	UINT8 YM2612_LFOFreq;
	UINT8 YM2612_Mode;
	UINT8 YM2612_DACEn;
	UINT8 YM2151_LFOFreq;
	UINT8 YM2151_LFOMod;
	UINT8 YM2151_LFOWaveSel;
	//UINT8 RF5C68_ChAddr[0x08 * 0x03];
	UINT8 YM2203_Mode;
	UINT8 YM2608_Mode;
	UINT8 YM2608_LFOFreq;
	UINT8 YM2608_ADPCMVol;
	UINT8 YM2608_DeltaTVol;
	UINT8 YM2610_Mode;
	UINT8 YM2610_LFOFreq;
	UINT8 YM2610_ADPCMVol;
	UINT8 YM2610_DeltaTVol;
	UINT8 YM3812_WaveSelect;
	UINT8 YM3812_CSMKeySplt;
	UINT8 YM3812_RhythmReg;
	UINT8 YM3526_WaveSelect;
	UINT8 YM3526_CSMKeySplt;
	UINT8 YM3526_RhythmReg;
	UINT8 Y8950_WaveSelect;
	UINT8 Y8950_CSMKeySplt;
	UINT8 Y8950_DeltaTVol;
	UINT8 Y8950_RhythmReg;
	UINT8 YMF262_WaveSelect;
	UINT8 YMF262_CSMKeySplt;
	UINT8 YMF262_RhythmReg;
	UINT8 YMF262_OPLMode;
	UINT8 YMF262_4ChMode;
	UINT8 YMF278B_WaveSelect;
	UINT8 YMF278B_CSMKeySplt;
	UINT8 YMF278B_RhythmReg;
	UINT8 YMF278B_OPLMode;
	UINT8 YMF278B_4ChMode;
	UINT8 YMZ280B_KeyOnEnable;
	UINT8 YMF271_GroupCmds[0x10];
	//UINT8 RF5C164_ChAddr[0x08 * 0x03];
	UINT16 PWM_Control_Reg;
	UINT16 PWM_Cycle_Reg;
	UINT8 GBDMG_Ctrl_Regs[0x03];
	UINT8 GBDMG_WaveRAM[0x10];
} REWRITE_CMDS;

#define RF_RAM_SIZE	0x10000	// 64 KB
typedef struct rewrite_rf5c
{
	bool Used;
	bool HadWrt;
	UINT8 MemReg;
	UINT8* RAMData;
} REWRT_RF5C;

typedef struct rewrite_chipset
{
	REWRITE_CMDS Mask;
	REWRITE_CMDS Vals;
	REWRT_RF5C RF5C68;
	REWRT_RF5C RF5C164;
} REWRT_CHIPSET;


extern VGM_HEADER VGMHead;
extern UINT32 VGMDataLen;
extern UINT8* VGMData;
static UINT32 VGMPos;
static INT32 VGMSmplPos;
extern UINT8* DstData;
extern UINT32 DstDataLen;

REWRT_CHIPSET RC[CHIP_SETS];

void TrimVGMData(const INT32 StartSmpl, const INT32 LoopSmpl, const INT32 EndSmpl,
				 const bool HasLoop, const bool KeepESmpl)
{
	INT32 TotalSmpl;
	INT32 LoopSmplA;
	INT32 EndSmplA;
	UINT32 DstPos;
	UINT8 ChipID;
	UINT8 Command;
	UINT32 CmdDelay;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
#ifdef SHOW_PROGRESS
	UINT32 CmdTimer;
	char TempStr[0x100];
	char MinSecStr[0x80];
#endif
	UINT32 CmdLen;
	UINT16 CmdReg;
	UINT8 CmdData;
	bool StopVGM;
	bool IsDelay;
	UINT8 WriteMode;
	UINT32 LoopPos;
	REWRT_RF5C* TempRF;
	
	// +0x100 - Make sure to have enough room for additional delays
	DstDataLen = VGMDataLen + 0x100;
	CmdDelay = 0;
	VGMPos = VGMHead.lngDataOffset;
	DstPos = VGMHead.lngDataOffset;
	
	TotalSmpl = (INT32)VGMHead.lngTotalSamples;
	switch(HasLoop)
	{
	case 0x00:	// No Loop
		LoopSmplA = 0x00;
		break;
	case 0x01:	// Has Loop
		if (LoopSmpl == -1)	// Keep Loop
			LoopSmplA = TotalSmpl - VGMHead.lngLoopSamples;
		else
			LoopSmplA = LoopSmpl;
		break;
	}
	EndSmplA = EndSmpl + (KeepESmpl ? 1 : 0);
	
	for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
	{
		memset(&RC[ChipID], 0x00, sizeof(REWRT_CHIPSET));
		if (VGMHead.lngHzRF5C68)
		{
			if (! ChipID || (VGMHead.lngHzRF5C68 & 0x40000000))
			{
				TempRF = &RC[ChipID].RF5C68;
				TempRF->Used = true;
				TempRF->HadWrt = false;
				TempRF->MemReg = 0x00;
				TempRF->RAMData = (UINT8*)malloc(RF_RAM_SIZE);
				memset(TempRF->RAMData, 0x00, RF_RAM_SIZE);
				DstDataLen += RF_RAM_SIZE;
			}
		}
		if (VGMHead.lngHzRF5C164)
		{
			if (! ChipID || (VGMHead.lngHzRF5C164 & 0x40000000))
			{
				TempRF = &RC[ChipID].RF5C164;
				TempRF->Used = true;
				TempRF->HadWrt = false;
				TempRF->MemReg = 0x00;
				TempRF->RAMData = (UINT8*)malloc(RF_RAM_SIZE);
				memset(TempRF->RAMData, 0x00, RF_RAM_SIZE);
				DstDataLen += RF_RAM_SIZE;
			}
		}
	}
	
	if (DstData == NULL)	// now allocate memory, if needed
		DstData = (UINT8*)malloc(DstDataLen);
	
#ifdef SHOW_PROGRESS
	CmdTimer = 0;
#endif
	VGMSmplPos = 0x00;
	LoopPos = 0x00;
	StopVGM = false;
	WriteMode = 0x00;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		IsDelay = false;
		
		CmdDelay = 0x00;
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				IsDelay = true;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			// Cheat Mode (to use 2 instances of 1 chip)
			ChipID = 0x00;
			switch(Command)
			{
			case 0x30:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x20;
					ChipID = 0x01;
				}
				break;
			case 0x3F:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x10;
					ChipID = 0x01;
				}
				break;
			case 0xA1:
				if (VGMHead.lngHzYM2413 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA2:
			case 0xA3:
				if (VGMHead.lngHzYM2612 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA4:
				if (VGMHead.lngHzYM2151 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA5:
				if (VGMHead.lngHzYM2203 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA6:
			case 0xA7:
				if (VGMHead.lngHzYM2608 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA8:
			case 0xA9:
				if (VGMHead.lngHzYM2610 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAA:
				if (VGMHead.lngHzYM3812 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAB:
				if (VGMHead.lngHzYM3526 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAC:
				if (VGMHead.lngHzY8950 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			}
			
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x01;
				IsDelay = true;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x01;
				IsDelay = true;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x03;
				IsDelay = true;
				break;
			case 0x50:	// SN76496 write
				CmdReg = VGMData[VGMPos + 0x01] & 0xF0;
				CmdData = VGMData[VGMPos + 0x01] & 0x0F;
				if (CmdReg == RR_SN76496_NoiseMode)
				{
					RC[ChipID].Mask.SN76496_NoiseMode |= 0x01;
					RC[ChipID].Vals.SN76496_NoiseMode = CmdData;
				}
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM2612_LFOFreq)
				{
					RC[ChipID].Mask.YM2612_LFOFreq |= 0x01;
					RC[ChipID].Vals.YM2612_LFOFreq = CmdData;
				}
				else if (CmdReg == RR_YM2612_Mode)
				{
					RC[ChipID].Mask.YM2612_Mode |= 0x01;
					RC[ChipID].Vals.YM2612_Mode = CmdData;
				}
				else if (CmdReg == RR_YM2612_DACEn)
				{
					RC[ChipID].Mask.YM2612_DACEn |= 0x01;
					RC[ChipID].Vals.YM2612_DACEn = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&TempLng, &VGMData[VGMPos + 0x03], 0x04);
				
				switch(TempByt & 0xC0)
				{
				case 0x00:	// Database Block
				case 0x40:
					break;
				case 0x80:	// ROM/RAM Dump
					break;
				case 0xC0:	// RAM Write
					memcpy(&TempSht, &VGMData[VGMPos + 0x07], 0x02);
					CmdLen = TempLng - 0x02;
					switch(TempByt)
					{
					case 0xC0:	// RF5C68 RAM Database
						TempRF = &RC[ChipID].RF5C68;
						if (TempRF->Used)
						{
							TempSht |= TempRF->MemReg << 12;
							memcpy(&TempRF->RAMData[TempSht], &VGMData[VGMPos + 0x09], CmdLen);
							TempRF->HadWrt = true;
						}
						break;
					case 0xC1:	// RF5C164 RAM Database
						TempRF = &RC[ChipID].RF5C164;
						if (TempRF->Used)
						{
							TempSht |= TempRF->MemReg << 12;
							memcpy(&TempRF->RAMData[TempSht], &VGMData[VGMPos + 0x09], CmdLen);
							TempRF->HadWrt = true;
						}
						break;
					}
					break;
				}
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				memcpy(&TempLng, &VGMData[VGMPos + 0x01], 0x04);
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				CmdData = VGMData[VGMPos + 0x01];
				RC[ChipID].Mask.SN76496_GGStereo |= 0x01;
				RC[ChipID].Vals.SN76496_GGStereo = CmdData;
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM2151_LFOFreq)
				{
					RC[ChipID].Mask.YM2151_LFOFreq |= 0x01;
					RC[ChipID].Vals.YM2151_LFOFreq = CmdData;
				}
				else if (CmdReg == RR_YM2151_LFOMod)
				{
					RC[ChipID].Mask.YM2151_LFOMod |= 0x01;
					RC[ChipID].Vals.YM2151_LFOMod = CmdData;
				}
				else if (CmdReg == RR_YM2151_LFOWaveSel)
				{
					RC[ChipID].Mask.YM2151_LFOWaveSel |= 0x01;
					RC[ChipID].Vals.YM2151_LFOWaveSel = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
				CmdReg = VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == 0x07 && ! (CmdData & 0x40))
				{
					RC[ChipID].RF5C68.MemReg = CmdData & 0x0F;
				}
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				if (RC[ChipID].RF5C68.Used)
				{
					TempRF = &RC[ChipID].RF5C68;
					TempSht |= TempRF->MemReg << 12;
					TempRF->RAMData[TempSht] = VGMData[VGMPos + 0x03];
					TempRF->HadWrt = true;
				}
				CmdLen = 0x04;
				break;
			case 0x55:	// YM2203
				CmdReg = VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM2203_Mode)
				{
					RC[ChipID].Mask.YM2203_Mode |= 0x01;
					RC[ChipID].Vals.YM2203_Mode = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM2608_LFOFreq)
				{
					RC[ChipID].Mask.YM2608_LFOFreq |= 0x01;
					RC[ChipID].Vals.YM2608_LFOFreq = CmdData;
				}
				else if (CmdReg == RR_YM2608_Mode)
				{
					RC[ChipID].Mask.YM2608_Mode |= 0x01;
					RC[ChipID].Vals.YM2608_Mode = CmdData;
				}
				else if (CmdReg == RR_YM2608_ADPCMVol)
				{
					RC[ChipID].Mask.YM2608_ADPCMVol |= 0x01;
					RC[ChipID].Vals.YM2608_ADPCMVol = CmdData;
				}
				else if (CmdReg == RR_YM2608_DeltaTVol)
				{
					RC[ChipID].Mask.YM2608_DeltaTVol |= 0x01;
					RC[ChipID].Vals.YM2608_DeltaTVol = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM2610_LFOFreq)
				{
					RC[ChipID].Mask.YM2610_LFOFreq |= 0x01;
					RC[ChipID].Vals.YM2610_LFOFreq = CmdData;
				}
				else if (CmdReg == RR_YM2610_Mode)
				{
					RC[ChipID].Mask.YM2610_Mode |= 0x01;
					RC[ChipID].Vals.YM2610_Mode = CmdData;
				}
				else if (CmdReg == RR_YM2610_ADPCMVol)
				{
					RC[ChipID].Mask.YM2610_ADPCMVol |= 0x01;
					RC[ChipID].Vals.YM2610_ADPCMVol = CmdData;
				}
				else if (CmdReg == RR_YM2610_DeltaTVol)
				{
					RC[ChipID].Mask.YM2610_DeltaTVol |= 0x01;
					RC[ChipID].Vals.YM2610_DeltaTVol = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM3812_WaveSelect)
				{
					RC[ChipID].Mask.YM3812_WaveSelect |= 0x01;
					RC[ChipID].Vals.YM3812_WaveSelect = CmdData;
				}
				else if (CmdReg == RR_YM3812_CSMKeySplt)
				{
					RC[ChipID].Mask.YM3812_CSMKeySplt |= 0x01;
					RC[ChipID].Vals.YM3812_CSMKeySplt = CmdData;
				}
				else if (CmdReg == RR_YM3812_RhythmReg)
				{
					RC[ChipID].Mask.YM3812_RhythmReg |= 0x01;
					RC[ChipID].Vals.YM3812_RhythmReg = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YM3526_WaveSelect)
				{
					RC[ChipID].Mask.YM3526_WaveSelect |= 0x01;
					RC[ChipID].Vals.YM3526_WaveSelect = CmdData;
				}
				else if (CmdReg == RR_YM3526_CSMKeySplt)
				{
					RC[ChipID].Mask.YM3526_CSMKeySplt |= 0x01;
					RC[ChipID].Vals.YM3526_CSMKeySplt = CmdData;
				}
				else if (CmdReg == RR_YM3526_RhythmReg)
				{
					RC[ChipID].Mask.YM3526_RhythmReg |= 0x01;
					RC[ChipID].Vals.YM3526_RhythmReg = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				CmdReg = VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_Y8950_WaveSelect)
				{
					RC[ChipID].Mask.Y8950_WaveSelect |= 0x01;
					RC[ChipID].Vals.Y8950_WaveSelect = CmdData;
				}
				else if (CmdReg == RR_Y8950_CSMKeySplt)
				{
					RC[ChipID].Mask.Y8950_CSMKeySplt |= 0x01;
					RC[ChipID].Vals.Y8950_CSMKeySplt = CmdData;
				}
				else if (CmdReg == RR_Y8950_DeltaTVol)
				{
					RC[ChipID].Mask.Y8950_DeltaTVol |= 0x01;
					RC[ChipID].Vals.Y8950_DeltaTVol = CmdData;
				}
				else if (CmdReg == RR_Y8950_RhythmReg)
				{
					RC[ChipID].Mask.Y8950_RhythmReg |= 0x01;
					RC[ChipID].Vals.Y8950_RhythmReg = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YMF262_WaveSelect)
				{
					RC[ChipID].Mask.YMF262_WaveSelect |= 0x01;
					RC[ChipID].Vals.YMF262_WaveSelect = CmdData;
				}
				else if (CmdReg == RR_YMF262_CSMKeySplt)
				{
					RC[ChipID].Mask.YMF262_CSMKeySplt |= 0x01;
					RC[ChipID].Vals.YMF262_CSMKeySplt = CmdData;
				}
				else if (CmdReg == RR_YMF262_RhythmReg)
				{
					RC[ChipID].Mask.YMF262_RhythmReg |= 0x01;
					RC[ChipID].Vals.YMF262_RhythmReg = CmdData;
				}
				else if (CmdReg == RR_YMF262_OPLMode)
				{
					RC[ChipID].Mask.YMF262_OPLMode |= 0x01;
					RC[ChipID].Vals.YMF262_OPLMode = CmdData;
				}
				else if (CmdReg == RR_YMF262_4ChMode)
				{
					RC[ChipID].Mask.YMF262_4ChMode |= 0x01;
					RC[ChipID].Vals.YMF262_4ChMode = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				CmdReg = VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == RR_YMZ280B_KeyOnEnable)
				{
					RC[ChipID].Mask.YMZ280B_KeyOnEnable |= 0x01;
					RC[ChipID].Vals.YMZ280B_KeyOnEnable = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0xD0:	// YMF278B write
				CmdReg = (VGMData[VGMPos + 0x01] << 8) | VGMData[VGMPos + 0x02];
				CmdData = VGMData[VGMPos + 0x03];
				if (CmdReg == RR_YMF278B_WaveSelect)
				{
					RC[ChipID].Mask.YMF278B_WaveSelect |= 0x01;
					RC[ChipID].Vals.YMF278B_WaveSelect = CmdData;
				}
				else if (CmdReg == RR_YMF278B_CSMKeySplt)
				{
					RC[ChipID].Mask.YMF278B_CSMKeySplt |= 0x01;
					RC[ChipID].Vals.YMF278B_CSMKeySplt = CmdData;
				}
				else if (CmdReg == RR_YMF278B_RhythmReg)
				{
					RC[ChipID].Mask.YMF278B_RhythmReg |= 0x01;
					RC[ChipID].Vals.YMF278B_RhythmReg = CmdData;
				}
				else if (CmdReg == RR_YMF278B_OPLMode)
				{
					RC[ChipID].Mask.YMF278B_OPLMode |= 0x01;
					RC[ChipID].Vals.YMF278B_OPLMode = CmdData;
				}
				else if (CmdReg == RR_YMF278B_4ChMode)
				{
					RC[ChipID].Mask.YMF278B_4ChMode |= 0x01;
					RC[ChipID].Vals.YMF278B_4ChMode = CmdData;
				}
				CmdLen = 0x04;
				break;
			case 0xD1:	// YMF271 write
				CmdReg = VGMData[VGMPos + 0x02];
				CmdData = VGMData[VGMPos + 0x03];
				if (VGMData[VGMPos + 0x01] == RR_YMF271_GroupPort && ! (CmdReg & 0xF0))
				{
					RC[ChipID].Mask.YMF271_GroupCmds[CmdReg] |= 0x01;
					RC[ChipID].Vals.YMF271_GroupCmds[CmdReg] = CmdData;
				}
				CmdLen = 0x04;
				break;
			case 0xB1:	// RF5C164 register write
				CmdReg = VGMData[VGMPos + 0x01];
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg == 0x07 && ! (CmdData & 0x40))
				{
					RC[ChipID].RF5C164.MemReg = CmdData & 0x0F;
				}
				CmdLen = 0x03;
				break;
			case 0xC2:	// RF5C164 memory write
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				if (RC[ChipID].RF5C164.Used)
				{
					TempRF = &RC[ChipID].RF5C164;
					TempSht |= TempRF->MemReg << 12;
					TempRF->RAMData[TempSht] = VGMData[VGMPos + 0x03];
					TempRF->HadWrt = true;
				}
				CmdLen = 0x04;
				break;
			case 0xB2:	// PWM register write
				CmdReg = (VGMData[VGMPos + 0x01] & 0xF0) >> 4;
				TempSht = ((VGMData[VGMPos + 0x01] & 0x0F) << 8) |
							(VGMData[VGMPos + 0x02] << 0);
				if (CmdReg == RR_PWM_Control_Reg)
				{
					RC[ChipID].Mask.PWM_Control_Reg |= 0x01;
					RC[ChipID].Vals.PWM_Control_Reg = TempSht;
				}
				else if (CmdReg == RR_PWM_Cycle_Reg)
				{
					RC[ChipID].Mask.PWM_Cycle_Reg |= 0x01;
					RC[ChipID].Vals.PWM_Cycle_Reg = TempSht;
				}
				CmdLen = 0x03;
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			case 0xA0:	// AY8910 write
				CmdLen = 0x03;
				break;
			case 0xB3:	// GameBoy DMG write
				ChipID = (VGMData[VGMPos + 0x01] & 0x80) >> 7;
				CmdReg = VGMData[VGMPos + 0x01] & 0x7F;
				CmdData = VGMData[VGMPos + 0x02];
				if (CmdReg >= RR_GBDMG_Ctrl_Regs && CmdReg <= RR_GBDMG_Ctrl_Regs + 0x02)
				{
					CmdReg -= RR_GBDMG_Ctrl_Regs;
					RC[ChipID].Mask.GBDMG_Ctrl_Regs[CmdReg] |= 0x01;
					RC[ChipID].Vals.GBDMG_Ctrl_Regs[CmdReg] = CmdData;
				}
				else if (CmdReg >= RR_GBDMG_WaveRAM && CmdReg <= RR_GBDMG_WaveRAM + 0x0F)
				{
					CmdReg -= RR_GBDMG_WaveRAM;
					RC[ChipID].Mask.GBDMG_WaveRAM[CmdReg] |= 0x01;
					RC[ChipID].Vals.GBDMG_WaveRAM[CmdReg] = CmdData;
				}
				CmdLen = 0x03;
				break;
			case 0xB4:	// NES APU write
				CmdLen = 0x03;
				break;
			case 0x90:	// DAC Ctrl: Setup Chip
				CmdLen = 0x05;
				break;
			case 0x91:	// DAC Ctrl: Set Data
				CmdLen = 0x05;
				break;
			case 0x92:	// DAC Ctrl: Set Freq
				CmdLen = 0x06;
				break;
			case 0x93:	// DAC Ctrl: Play from Start Pos
				CmdLen = 0x0B;
				break;
			case 0x94:	// DAC Ctrl: Stop immediately
				CmdLen = 0x02;
				break;
			case 0x95:	// DAC Ctrl: Play Block (small)
				CmdLen = 0x05;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		TempSht = 0x00;
		switch(WriteMode)
		{
		case 0x00:	// before Start Point
			if (VGMSmplPos >= StartSmpl)
			{
				// Beginn to write to trimmed vgm
				
				// Rewrite neccessary commands
				VGMReadAhead(VGMPos + CmdLen, 2 * 44100);	// Read 2 seconds ahead
				
				for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
				{
					TempRF = &RC[ChipID].RF5C68;
					if (TempRF->Used && TempRF->HadWrt)
					{
						DstData[DstPos + 0x00] = 0x67;
						DstData[DstPos + 0x01] = 0x66;
						DstData[DstPos + 0x02] = 0xC0;
						TempLng = 0x10002;
						memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
						TempSht = 0x0000;
						memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
						TempLng -= 0x02;
						memcpy(&DstData[DstPos + 0x09], TempRF->RAMData, TempLng);
						DstPos += 0x07 + 0x02 + TempLng;
						
						DstData[DstPos + 0x00] = 0xB0;
						DstData[DstPos + 0x01] = 0x07;
						DstData[DstPos + 0x02] = 0x00 | TempRF->MemReg;
						DstPos += 0x03;
					}
				}
				for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
				{
					TempRF = &RC[ChipID].RF5C164;
					if (TempRF->Used && TempRF->HadWrt)
					{
						DstData[DstPos + 0x00] = 0x67;
						DstData[DstPos + 0x01] = 0x66;
						DstData[DstPos + 0x02] = 0xC1;
						TempLng = 0x10002;
						memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
						TempSht = 0x0000;
						memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
						TempLng -= 0x02;
						memcpy(&DstData[DstPos + 0x09], TempRF->RAMData, TempLng);
						DstPos += 0x07 + 0x02 + TempLng;
						
						DstData[DstPos + 0x00] = 0xB1;
						DstData[DstPos + 0x01] = 0x07;
						DstData[DstPos + 0x02] = 0x00 | TempRF->MemReg;
						DstPos += 0x03;
					}
				}
				
				if (VGMHead.lngHzPSG)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						if (RC[ChipID].Mask.SN76496_NoiseMode == 0x01)
						{
							DstData[DstPos + 0x00] = 0x50 - ChipID * 0x20;
							DstData[DstPos + 0x01] = RR_SN76496_NoiseMode |
													RC[ChipID].Vals.SN76496_NoiseMode;
							DstPos += 0x02;
						}
						if (RC[ChipID].Mask.SN76496_GGStereo == 0x01)
						{
							DstData[DstPos + 0x00] = 0x4F - ChipID * 0x10;
							DstData[DstPos + 0x01] = RC[ChipID].Vals.SN76496_GGStereo;
							DstPos += 0x02;
						}
					}
				}
				if (VGMHead.lngHzYM2612)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x52 + ChipID * 0x50;
						if (RC[ChipID].Mask.YM2612_LFOFreq == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2612_LFOFreq >> 8);
							DstData[DstPos + 0x01] = RR_YM2612_LFOFreq & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2612_LFOFreq;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2612_Mode == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2612_Mode >> 8);
							DstData[DstPos + 0x01] = RR_YM2612_Mode & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2612_Mode;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2612_DACEn == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2612_DACEn >> 8);
							DstData[DstPos + 0x01] = RR_YM2612_DACEn & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2612_DACEn;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYM2151)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x54 + ChipID * 0x50;
						if (RC[ChipID].Mask.YM2151_LFOFreq == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM2151_LFOFreq & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2151_LFOFreq;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2151_LFOMod == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM2151_LFOMod & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2151_LFOMod;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2151_LFOWaveSel == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM2151_LFOWaveSel & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2151_LFOWaveSel;
							DstPos += 0x03;
						}
					}
				}
				/*if (VGMHead.lngHzRF5C68)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						if (RC[ChipID].Mask.RF5C68_ == 0x01)
						{
						}
					}
				}*/
				if (VGMHead.lngHzYM2608)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x56 + ChipID * 0x50;
						if (RC[ChipID].Mask.YM2608_LFOFreq == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2608_LFOFreq >> 8);
							DstData[DstPos + 0x01] = RR_YM2608_LFOFreq & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2608_LFOFreq;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2608_ADPCMVol == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2608_ADPCMVol >> 8);
							DstData[DstPos + 0x01] = RR_YM2608_ADPCMVol & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2608_ADPCMVol;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2608_DeltaTVol == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2608_DeltaTVol >> 8);
							DstData[DstPos + 0x01] = RR_YM2608_DeltaTVol & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2608_DeltaTVol;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYM2610)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x58 + ChipID * 0x50;
						if (RC[ChipID].Mask.YM2610_LFOFreq == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2610_LFOFreq >> 8);
							DstData[DstPos + 0x01] = RR_YM2610_LFOFreq & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2610_LFOFreq;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2610_ADPCMVol == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2610_ADPCMVol >> 8);
							DstData[DstPos + 0x01] = RR_YM2610_ADPCMVol & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2610_ADPCMVol;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM2610_DeltaTVol == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YM2610_DeltaTVol >> 8);
							DstData[DstPos + 0x01] = RR_YM2610_DeltaTVol & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM2610_DeltaTVol;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYM3812)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x5A + ChipID * 0x50;
						if (RC[ChipID].Mask.YM3812_WaveSelect == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3812_WaveSelect & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3812_WaveSelect;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM3812_CSMKeySplt == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3812_CSMKeySplt & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3812_CSMKeySplt;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM3812_RhythmReg == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3812_RhythmReg & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3812_RhythmReg;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYM3526)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x5B + ChipID * 0x50;
						if (RC[ChipID].Mask.YM3526_WaveSelect == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3526_WaveSelect & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3526_WaveSelect;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM3526_CSMKeySplt == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3526_CSMKeySplt & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3526_CSMKeySplt;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YM3526_RhythmReg == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YM3526_RhythmReg & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YM3526_RhythmReg;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzY8950)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x5C + ChipID * 0x50;
						if (RC[ChipID].Mask.Y8950_WaveSelect == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_Y8950_WaveSelect & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.Y8950_WaveSelect;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.Y8950_CSMKeySplt == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_Y8950_CSMKeySplt & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.Y8950_CSMKeySplt;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.Y8950_DeltaTVol == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_Y8950_DeltaTVol & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.Y8950_DeltaTVol;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.Y8950_RhythmReg == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_Y8950_RhythmReg & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.Y8950_RhythmReg;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYMF262)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x5E + ChipID * 0x50;
						if (RC[ChipID].Mask.YMF262_WaveSelect == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YMF262_WaveSelect >> 8);
							DstData[DstPos + 0x01] = RR_YMF262_WaveSelect & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMF262_WaveSelect;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YMF262_CSMKeySplt == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YMF262_CSMKeySplt >> 8);
							DstData[DstPos + 0x01] = RR_YMF262_CSMKeySplt & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMF262_CSMKeySplt;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YMF262_RhythmReg == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YMF262_RhythmReg >> 8);
							DstData[DstPos + 0x01] = RR_YMF262_RhythmReg & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMF262_RhythmReg;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YMF262_OPLMode == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YMF262_OPLMode >> 8);
							DstData[DstPos + 0x01] = RR_YMF262_OPLMode & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMF262_OPLMode;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.YMF262_4ChMode == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt | (RR_YMF262_4ChMode >> 8);
							DstData[DstPos + 0x01] = RR_YMF262_4ChMode & 0xFF;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMF262_4ChMode;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYMF278B)
				{
					for (ChipID = 0x00; ChipID < 0x01; ChipID ++)
					{
						TempByt = ChipID << 7;
						if (RC[ChipID].Mask.YMF278B_WaveSelect == 0x01)
						{
							DstData[DstPos + 0x00] = 0xD0;
							DstData[DstPos + 0x01] = (RR_YMF278B_WaveSelect >> 8) | TempByt;
							DstData[DstPos + 0x02] = RR_YMF278B_WaveSelect & 0xFF;
							DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF278B_WaveSelect;
							DstPos += 0x04;
						}
						if (RC[ChipID].Mask.YMF278B_CSMKeySplt == 0x01)
						{
							DstData[DstPos + 0x00] = 0xD0;
							DstData[DstPos + 0x01] = (RR_YMF278B_CSMKeySplt >> 8) | TempByt;
							DstData[DstPos + 0x02] = RR_YMF278B_CSMKeySplt & 0xFF;
							DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF278B_CSMKeySplt;
							DstPos += 0x04;
						}
						if (RC[ChipID].Mask.YMF278B_RhythmReg == 0x01)
						{
							DstData[DstPos + 0x00] = 0xD0;
							DstData[DstPos + 0x01] = (RR_YMF278B_RhythmReg >> 8) | TempByt;
							DstData[DstPos + 0x02] = RR_YMF278B_RhythmReg & 0xFF;
							DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF278B_RhythmReg;
							DstPos += 0x04;
						}
						if (RC[ChipID].Mask.YMF278B_OPLMode == 0x01)
						{
							DstData[DstPos + 0x00] = 0xD0;
							DstData[DstPos + 0x01] = (RR_YMF278B_OPLMode >> 8) | TempByt;
							DstData[DstPos + 0x02] = RR_YMF278B_OPLMode & 0xFF;
							DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF278B_OPLMode;
							DstPos += 0x04;
						}
						if (RC[ChipID].Mask.YMF278B_4ChMode == 0x01)
						{
							DstData[DstPos + 0x00] = 0xD0;
							DstData[DstPos + 0x01] = (RR_YMF278B_4ChMode >> 8) | TempByt;
							DstData[DstPos + 0x02] = RR_YMF278B_4ChMode & 0xFF;
							DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF278B_4ChMode;
							DstPos += 0x04;
						}
					}
				}
				if (VGMHead.lngHzYMZ280B)
				{
					for (ChipID = 0x00; ChipID < 0x01; ChipID ++)
					{
						TempByt = 0x5D + ChipID * 0x50;
						if (RC[ChipID].Mask.YMZ280B_KeyOnEnable == 0x01)
						{
							DstData[DstPos + 0x00] = TempByt;
							DstData[DstPos + 0x01] = RR_YMZ280B_KeyOnEnable;
							DstData[DstPos + 0x02] = RC[ChipID].Vals.YMZ280B_KeyOnEnable;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzYMF271)
				{
					for (ChipID = 0x00; ChipID < 0x01; ChipID ++)
					{
						for (TempByt = 0x00; TempByt < 0x10; TempByt ++)
						{
							if (RC[ChipID].Mask.YMF271_GroupCmds[TempByt] == 0x01)
							{
								DstData[DstPos + 0x00] = 0xD1; 
								DstData[DstPos + 0x01] = (RR_YMF271_GroupPort) || (ChipID << 7);
								DstData[DstPos + 0x02] = TempByt;
								DstData[DstPos + 0x03] = RC[ChipID].Vals.YMF271_GroupCmds
																					[TempByt];
								DstPos += 0x04;
							}
						}
					}
				}
				/*if (VGMHead.lngHzRF5C164)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						if (RC[ChipID].Mask.RF5C164_ == 0x01)
						{
						}
					}
				}*/
				if (VGMHead.lngHzPWM)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						if (RC[ChipID].Mask.PWM_Control_Reg == 0x01)
						{
							DstData[DstPos + 0x00] = 0xB2;
							DstData[DstPos + 0x01] = (RR_PWM_Control_Reg << 4) |
											((RC[ChipID].Vals.PWM_Control_Reg & 0xF00) >> 8);
							DstData[DstPos + 0x02] = RC[ChipID].Vals.PWM_Control_Reg & 0x0FF;
							DstPos += 0x03;
						}
						if (RC[ChipID].Mask.PWM_Cycle_Reg == 0x01)
						{
							DstData[DstPos + 0x00] = 0xB2;
							DstData[DstPos + 0x01] = (RR_PWM_Cycle_Reg << 4) |
											((RC[ChipID].Vals.PWM_Cycle_Reg & 0xF00) >> 8);
							DstData[DstPos + 0x02] = RC[ChipID].Vals.PWM_Cycle_Reg & 0x0FF;
							DstPos += 0x03;
						}
					}
				}
				if (VGMHead.lngHzGBDMG)
				{
					for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
					{
						TempByt = 0x02;	// Reg 0x16 is Master Enable and must be always written
						if ((RC[ChipID].Mask.GBDMG_Ctrl_Regs[TempByt] & 0x01) &&
							(RC[ChipID].Vals.GBDMG_Ctrl_Regs[TempByt] & 0x80))
						{
							DstData[DstPos + 0x00] = 0xB3;
							DstData[DstPos + 0x01] = (RR_GBDMG_Ctrl_Regs + TempByt) |
													(ChipID << 7);
							DstData[DstPos + 0x02] = RC[ChipID].Vals.GBDMG_Ctrl_Regs[TempByt];
							DstPos += 0x03;
						}
						
						// was completely written / complete write ahead?
						TempSht = 0x01;
						for (TempByt = 0x00; TempByt < 0x10; TempByt ++)
						{
							TempSht &= (RC[ChipID].Mask.GBDMG_WaveRAM[TempByt] & 0x01) | ~0x01;
							TempSht |= (RC[ChipID].Mask.GBDMG_WaveRAM[TempByt] & 0x10);
						}
						// write WaveRAM
						for (TempByt = 0x00; TempByt < 0x10; TempByt ++)
						{
							if (TempSht == 0x01 || ((TempSht & 0x10) && (RC[ChipID].Mask.GBDMG_WaveRAM[TempByt] & 0x01)))
							{
								DstData[DstPos + 0x00] = 0xB3;
								DstData[DstPos + 0x01] = (RR_GBDMG_WaveRAM + TempByt) | (ChipID << 7);
								DstData[DstPos + 0x02] = RC[ChipID].Vals.GBDMG_WaveRAM[TempByt];
								DstPos += 0x03;
							}
						}
						
						// now write the other control regs
						for (TempByt = 0x00; TempByt < 0x02; TempByt ++)
						{
							if (RC[ChipID].Mask.GBDMG_Ctrl_Regs[TempByt] == 0x01)
							{
								DstData[DstPos + 0x00] = 0xB3;
								DstData[DstPos + 0x01] = (RR_GBDMG_Ctrl_Regs + TempByt) | (ChipID << 7);
								DstData[DstPos + 0x02] = RC[ChipID].Vals.GBDMG_Ctrl_Regs[TempByt];
								DstPos += 0x03;
							}
						}
					}
				}
				
				// Write initial delay
				CmdDelay = VGMSmplPos - StartSmpl;
				if (HasLoop && ! LoopPos && StartSmpl == LoopSmplA)
				{
					LoopPos = DstPos;	// TODO: Find a way that's less hack-like
				}
				TempLng = CmdDelay;
				while(TempLng)
				{
					if (TempLng <= 0xFFFF)
						TempSht = (UINT16)CmdDelay;
					else
						TempSht = 0xFFFF;
					
					if (TempSht <= 0x10)
					{
						DstData[DstPos + 0x00] = 0x70 | (TempSht - 0x01);
						DstPos += 0x01;
					}
					else
					{
						DstData[DstPos + 0x00] = 0x61;
						memcpy(&DstData[DstPos + 0x01], &TempSht, 0x02);
						DstPos += 0x03;
					}
					TempLng -= TempSht;
				}
				
				TempSht = 0x01;
				WriteMode = 0x01;
			}
			if (WriteMode == 0x00)
			{
				if (Command == 0x67 && (VGMData[VGMPos + 0x02] & 0xC0) != 0xC0)
				{
					memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
					DstPos += CmdLen;
				}
				break;
			}
			// Fall through for Loop Point Check
		case 0x01:
			if (HasLoop && ! LoopPos)
			{
				if (VGMSmplPos >= LoopSmplA)
				{
					// Insert Loop Point
					TempLng = LoopSmplA - (VGMSmplPos - CmdDelay);	// Delay before Loop
					if (TempLng & 0x80000000)	// if TempLng < 0
						TempLng = 0x00;
					while(TempLng)
					{
						if (TempLng <= 0xFFFF)
							TempSht = (UINT16)TempLng;
						else
							TempSht = 0xFFFF;
						
						if (TempSht <= 0x10)
						{
							DstData[DstPos + 0x00] = 0x70 | (TempSht - 0x01);
							DstPos += 0x01;
						}
						else
						{
							DstData[DstPos + 0x00] = 0x61;
							memcpy(&DstData[DstPos + 0x01], &TempSht, 0x02);
							DstPos += 0x03;
						}
						TempLng -= TempSht;
					}
					
					LoopPos = DstPos;
					
					TempLng = VGMSmplPos - LoopSmplA;				// Delay after Loop
					if (TempLng & 0x80000000)	// if TempLng < 0
						TempLng = 0x00;
					while(TempLng)
					{
						if (TempLng <= 0xFFFF)
							TempSht = (UINT16)TempLng;
						else
							TempSht = 0xFFFF;
						
						if (TempSht <= 0x10)
						{
							DstData[DstPos + 0x00] = 0x70 | (TempSht - 0x01);
							DstPos += 0x01;
						}
						else
						{
							DstData[DstPos + 0x00] = 0x61;
							memcpy(&DstData[DstPos + 0x01], &TempSht, 0x02);
							DstPos += 0x03;
						}
						TempLng -= TempSht;
					}
					
					TempSht = 0x01;
				}
			}
			if (IsDelay || StopVGM)
			{
				if (VGMSmplPos >= EndSmplA && VGMSmplPos < TotalSmpl || StopVGM)
				{
					// Finish trimming
					TempLng = EndSmpl - (VGMSmplPos - CmdDelay);	// it's EndSmpl, not EndSmplA
					if (TempLng & 0x80000000)	// if TempLng < 0
						TempLng = 0x00;
					while(TempLng)
					{
						if (TempLng <= 0xFFFF)
							TempSht = (UINT16)TempLng;
						else
							TempSht = 0xFFFF;
						
						if (TempSht <= 0x10)
						{
							DstData[DstPos + 0x00] = 0x70 | (TempSht - 0x01);
							DstPos += 0x01;
						}
						else
						{
							DstData[DstPos + 0x00] = 0x61;
							memcpy(&DstData[DstPos + 0x01], &TempSht, 0x02);
							DstPos += 0x03;
						}
						TempLng -= TempSht;
					}
					DstData[DstPos] = 0x66;
					DstPos ++;
					
					if (HasLoop)
						WriteVGMHeader(DstData, VGMData, DstPos, EndSmpl - StartSmpl,
										LoopPos, EndSmpl - LoopSmplA);
					else
						WriteVGMHeader(DstData, VGMData, DstPos, EndSmpl - StartSmpl,
										0x00, 0x00);
					
					StopVGM = true;
					IsDelay = true;
					WriteMode = 0x02;
				}
				else if (! TempSht || VGMSmplPos >= TotalSmpl)
				{
					IsDelay = false;
				}
			}
			if (! IsDelay)
			{
				memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
				DstPos += CmdLen;
			}
			break;
		case 0x02:	// after End Point
			break;
		}
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
#ifdef SHOW_PROGRESS
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			CmdLen = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / CmdLen * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
#endif
	}
	
	for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
	{
		if (RC[ChipID].RF5C68.Used)
			free(RC[ChipID].RF5C68.RAMData);
		if (RC[ChipID].RF5C164.Used)
			free(RC[ChipID].RF5C164.RAMData);
	}
	
	return;
}

static void WriteVGMHeader(UINT8* DstData, const UINT8* SrcData, const UINT32 EOFPos,
						   const UINT32 SampleCount, const UINT32 LoopPos,
						   const UINT32 LoopSmpls)
{
	UINT32 CurPos;
	UINT32 DstPos;
	UINT32 CmdLen;
	UINT32 TempLng;
	
	memcpy(DstData, VGMData, VGMHead.lngDataOffset);	// Copy Header
	memcpy(&DstData[0x18], &SampleCount, 0x04);
	TempLng = LoopPos;
	if (TempLng)
		TempLng -= 0x1C;
	memcpy(&DstData[0x1C], &TempLng, 0x04);
	memcpy(&DstData[0x20], &LoopSmpls, 0x04);
	
	DstPos = EOFPos;
	if (VGMHead.lngGD3Offset)
	{
		CurPos = VGMHead.lngGD3Offset;
		memcpy(&TempLng, &VGMData[CurPos + 0x00], 0x04);
		if (TempLng == FCC_GD3)
		{
			memcpy(&CmdLen, &VGMData[CurPos + 0x08], 0x04);
			CmdLen += 0x0C;
			
			TempLng = DstPos - 0x14;
			memcpy(&DstData[0x14], &TempLng, 0x04);
			memcpy(&DstData[DstPos], &VGMData[CurPos], CmdLen);	// Copy GD3 Tag
			DstPos += CmdLen;
		}
	}
	
	DstDataLen = DstPos;
	TempLng = DstDataLen - 0x04;
	memcpy(&DstData[0x04], &TempLng, 0x04);	// Write EOF Position
	
	return;
}

#ifdef SHOW_PROGRESS
static void PrintMinSec(const UINT32 SamplePos, char* TempStr)
{
	float TimeSec;
	UINT16 TimeMin;
	
	TimeSec = (float)SamplePos / (float)44100.0;
	TimeMin = (UINT16)TimeSec / 60;
	TimeSec -= TimeMin * 60;
	sprintf(TempStr, "%02hu:%05.2f", TimeMin, TimeSec);
	
	return;
}
#endif

static void VGMReadAhead(const UINT32 StartPos, const UINT32 Samples)
{
	// Read ahead to check for neccessary commands
	UINT32 CurPos;
	UINT32 CurSmpl;
	UINT8 ChipID;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 CmdLen;
	UINT16	 CmdReg;
	UINT8* TempPnt;
	bool StopVGM;
	
	StopVGM = true;
	for (ChipID = 0x00; ChipID < CHIP_SETS; ChipID ++)
	{
		CmdLen = sizeof(REWRITE_CMDS);
		TempPnt = (UINT8*)&RC[ChipID].Mask;
		for (TempLng = 0x00; TempLng < CmdLen; TempLng ++, TempPnt ++)
		{
			if (*TempPnt & 0x01)
			{
				StopVGM = false;
				break;
			}
		}
		if (! StopVGM)
			break;
	}
	if (StopVGM)	// no important commands read
		return;
	
	CurPos = StartPos;
	CurSmpl = 0x00;
	StopVGM = false;
	while(CurPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[CurPos + 0x00];
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				CurSmpl += TempSht;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				CurSmpl += TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			// Cheat Mode (to use 2 instances of 1 chip)
			ChipID = 0x00;
			switch(Command)
			{
			case 0x30:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x20;
					ChipID = 0x01;
				}
				break;
			case 0x3F:
				if (VGMHead.lngHzPSG & 0x40000000)
				{
					Command += 0x10;
					ChipID = 0x01;
				}
				break;
			case 0xA1:
				if (VGMHead.lngHzYM2413 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA2:
			case 0xA3:
				if (VGMHead.lngHzYM2612 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA4:
				if (VGMHead.lngHzYM2151 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA5:
				if (VGMHead.lngHzYM2203 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA6:
			case 0xA7:
				if (VGMHead.lngHzYM2608 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xA8:
			case 0xA9:
				if (VGMHead.lngHzYM2610 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAA:
				if (VGMHead.lngHzYM3812 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAB:
				if (VGMHead.lngHzYM3526 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			case 0xAC:
				if (VGMHead.lngHzY8950 & 0x40000000)
				{
					Command -= 0x50;
					ChipID = 0x01;
				}
				break;
			}
			
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				CurSmpl += TempSht;
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				CurSmpl += TempSht;
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[CurPos + 0x01], 0x02);
				CurSmpl += TempSht;
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
				CmdReg = VGMData[CurPos + 0x01];
				if ((CmdReg & 0xF0) == RR_SN76496_NoiseMode)
					RC[ChipID].Mask.SN76496_NoiseMode |= 0x10;
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM2612_LFOFreq)
					RC[ChipID].Mask.YM2612_LFOFreq |= 0x10;
				else if (CmdReg == RR_YM2612_Mode)
					RC[ChipID].Mask.YM2612_Mode |= 0x10;
				else if (CmdReg == RR_YM2612_DACEn)
					RC[ChipID].Mask.YM2612_DACEn |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[CurPos + 0x02];
				memcpy(&TempLng, &VGMData[CurPos + 0x03], 0x04);
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				memcpy(&TempLng, &VGMData[CurPos + 0x01], 0x04);
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				CmdReg = ((Command & 0x01) << 8) | VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM2151_LFOFreq)
					RC[ChipID].Mask.YM2151_LFOFreq |= 0x10;
				else if (CmdReg == RR_YM2151_LFOMod)
					RC[ChipID].Mask.YM2151_LFOMod |= 0x10;
				else if (CmdReg == RR_YM2151_LFOWaveSel)
					RC[ChipID].Mask.YM2151_LFOWaveSel |= 0x10;
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				memcpy(&TempSht, &VGMData[CurPos + 0x01], 0x02);
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
				memcpy(&TempSht, &VGMData[CurPos + 0x01], 0x02);
				CmdLen = 0x04;
				break;
			case 0x55:	// YM2203
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM2608_LFOFreq)
					RC[ChipID].Mask.YM2608_LFOFreq |= 0x10;
				else if (CmdReg == RR_YM2608_ADPCMVol)
					RC[ChipID].Mask.YM2608_ADPCMVol |= 0x10;
				else if (CmdReg == RR_YM2608_DeltaTVol)
					RC[ChipID].Mask.YM2608_DeltaTVol |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM2610_LFOFreq)
					RC[ChipID].Mask.YM2610_LFOFreq |= 0x10;
				else if (CmdReg == RR_YM2610_ADPCMVol)
					RC[ChipID].Mask.YM2610_ADPCMVol |= 0x10;
				else if (CmdReg == RR_YM2610_DeltaTVol)
					RC[ChipID].Mask.YM2610_DeltaTVol |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				CmdReg = VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM3812_WaveSelect)
					RC[ChipID].Mask.YM3812_WaveSelect |= 0x10;
				else if (CmdReg == RR_YM3812_CSMKeySplt)
					RC[ChipID].Mask.YM3812_CSMKeySplt |= 0x10;
				else if (CmdReg == RR_YM3812_RhythmReg)
					RC[ChipID].Mask.YM3812_RhythmReg |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				CmdReg = VGMData[CurPos + 0x01];
				if (CmdReg == RR_YM3526_WaveSelect)
					RC[ChipID].Mask.YM3526_WaveSelect |= 0x10;
				else if (CmdReg == RR_YM3526_CSMKeySplt)
					RC[ChipID].Mask.YM3526_CSMKeySplt |= 0x10;
				else if (CmdReg == RR_YM3526_RhythmReg)
					RC[ChipID].Mask.YM3526_RhythmReg |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				CmdReg = VGMData[CurPos + 0x01];
				if (CmdReg == RR_Y8950_WaveSelect)
					RC[ChipID].Mask.Y8950_WaveSelect |= 0x10;
				else if (CmdReg == RR_Y8950_CSMKeySplt)
					RC[ChipID].Mask.Y8950_CSMKeySplt |= 0x10;
				else if (CmdReg == RR_Y8950_DeltaTVol)
					RC[ChipID].Mask.Y8950_DeltaTVol |= 0x10;
				else if (CmdReg == RR_Y8950_RhythmReg)
					RC[ChipID].Mask.Y8950_RhythmReg |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				CmdReg = ((Command & 0x01) << 8) | VGMData[CurPos + 0x01];
				if (CmdReg == RR_YMF262_WaveSelect)
					RC[ChipID].Mask.YMF262_WaveSelect |= 0x10;
				else if (CmdReg == RR_YMF262_CSMKeySplt)
					RC[ChipID].Mask.YMF262_CSMKeySplt |= 0x10;
				else if (CmdReg == RR_YMF262_RhythmReg)
					RC[ChipID].Mask.YMF262_RhythmReg |= 0x10;
				else if (CmdReg == RR_YMF262_OPLMode)
					RC[ChipID].Mask.YMF262_OPLMode |= 0x10;
				else if (CmdReg == RR_YMF262_4ChMode)
					RC[ChipID].Mask.YMF262_4ChMode |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				CmdReg = VGMData[CurPos + 0x01];
				if (CmdReg == RR_YMZ280B_KeyOnEnable)
					RC[ChipID].Mask.YMZ280B_KeyOnEnable |= 0x10;
				CmdLen = 0x03;
				break;
			case 0xD0:	// YMF278B write
				CmdReg = (VGMData[CurPos + 0x01] << 8) | VGMData[CurPos + 0x02];
				if (CmdReg == RR_YMF278B_WaveSelect)
					RC[ChipID].Mask.YMF278B_WaveSelect |= 0x10;
				else if (CmdReg == RR_YMF278B_CSMKeySplt)
					RC[ChipID].Mask.YMF278B_CSMKeySplt |= 0x10;
				else if (CmdReg == RR_YMF278B_RhythmReg)
					RC[ChipID].Mask.YMF278B_RhythmReg |= 0x10;
				else if (CmdReg == RR_YMF278B_OPLMode)
					RC[ChipID].Mask.YMF278B_OPLMode |= 0x10;
				else if (CmdReg == RR_YMF278B_4ChMode)
					RC[ChipID].Mask.YMF278B_4ChMode |= 0x10;
				CmdLen = 0x04;
				break;
			case 0xD1:	// YMF271 write
				CmdReg = VGMData[VGMPos + 0x02];
				if (VGMData[VGMPos + 0x01] == RR_YMF271_GroupPort && ! (CmdReg & 0xF0))
					RC[ChipID].Mask.YMF271_GroupCmds[CmdReg] |= 0x10;
				CmdLen = 0x04;
				break;
			case 0xB2:	// PWM register write
				CmdReg = (VGMData[VGMPos + 0x01] & 0xF0) >> 4;
				if (CmdReg == RR_PWM_Control_Reg)
					RC[ChipID].Mask.PWM_Control_Reg |= 0x10;
				else if (CmdReg == RR_PWM_Cycle_Reg)
					RC[ChipID].Mask.PWM_Cycle_Reg |= 0x10;
				CmdLen = 0x03;
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			case 0xA0:	// AY8910 write
				CmdLen = 0x03;
				break;
			case 0xB3:	// GameBoy DMG write
				CmdReg = VGMData[CurPos + 0x01];
				if (CmdReg >= RR_GBDMG_Ctrl_Regs && CmdReg <= RR_GBDMG_Ctrl_Regs + 0x02)
					RC[ChipID].Mask.GBDMG_Ctrl_Regs[CmdReg - RR_GBDMG_Ctrl_Regs] |= 0x10;
				else if (CmdReg >= RR_GBDMG_WaveRAM && CmdReg <= RR_GBDMG_WaveRAM + 0x0F)
					RC[ChipID].Mask.GBDMG_WaveRAM[CmdReg - RR_GBDMG_WaveRAM] |= 0x10;
				CmdLen = 0x03;
				break;
			case 0xB4:	// NES APU write
				CmdLen = 0x03;
				break;
			case 0x90:	// DAC Ctrl: Setup Chip
				CmdLen = 0x05;
				break;
			case 0x91:	// DAC Ctrl: Set Data
				CmdLen = 0x05;
				break;
			case 0x92:	// DAC Ctrl: Set Freq
				CmdLen = 0x06;
				break;
			case 0x93:	// DAC Ctrl: Play from Start Pos
				CmdLen = 0x0B;
				break;
			case 0x94:	// DAC Ctrl: Stop immediately
				CmdLen = 0x02;
				break;
			case 0x95:	// DAC Ctrl: Play Block (small)
				CmdLen = 0x05;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		CurPos += CmdLen;
		if (CurSmpl >= Samples)
			break;
		if (StopVGM)
			break;
	}
	
	return;
}
