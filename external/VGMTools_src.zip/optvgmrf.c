// optvgmrf.c - VGM RF-PCM Optimizer
//

// TODO:
//	- implement UnOpt
//	- optimize output (smaller blocks, expand block writes)


#include <stdio.h>
#include <stdlib.h>
#include "stdbool.h"
#include <string.h>

#ifdef WIN32
#include <conio.h>
#include <windows.h>	// for GetTickCount
#endif

#include "zlib.h"

#include "stdtype.h"
#include "VGMFile.h"


static bool OpenVGMFile(const char* FileName);
static void WriteVGMFile(const char* FileName);
static void MergePCMData(void);
static UINT32 ReadConsecutiveMemWrites(UINT8 RFMode);
static void EnumeratePCMData(void);
static bool CompareData(UINT32 DataLen, const UINT8* DataA,
						const UINT8* DataB);
static void RewriteVGMData(void);
static void PrintMinSec(const UINT32 SamplePos, char* TempStr);


#define RF5C68_MODE		0x00
#define RF5C164_MODE	0x01

// sometimes the chip races with the memory writes, so I tried different methods
#define BP_FRONT	0x00	// works best (some single samples are still incorrect)
				// I should be able to get around that by simulating that stream
#define BP_BACK		0x01	// works worst (audible bugs)
#define BP_MIDDLE	0x02	// works average (some audible bugs)

#define BLOCK_POS	BP_FRONT


typedef struct rfpcm_block_data
{
	UINT8 Mode;
	UINT32 DataSize;
	UINT8* Data;
	UINT32 DBPos;	// Database Position
	UINT32 UsageCounter;
} RF_BLK_DATA;
typedef struct block_in_file_list
{
	UINT32 BlockID;
	UINT32 FilePos;
	UINT32 StartAddr;
	UINT32 DataSize;
} IN_FILE_LIST;
typedef struct rfpcm_ram_data
{
	UINT16 BankReg;
	bool FirstBnkWrt;
	UINT32 DataLen;
	UINT16 RAMStart;
	UINT32 RAMSkip;
	UINT8 PCMRam[0x10000];
} RF_CHIP_DATA;


VGM_HEADER VGMHead;
UINT32 VGMDataLen;
UINT8* VGMData;
UINT32 VGMPos;
INT32 VGMSmplPos;
UINT8* DstData;
UINT32 DstDataLen;
char FileBase[0x100];
UINT32 DataSizeA;
UINT32 DataSizeB;
bool CancelFlag;
UINT8 OptMode;

RF_CHIP_DATA RF_RData[0x02];
UINT32 RFBlkAlloc;
UINT32 RFBlkCount;
RF_BLK_DATA* RFBlock;
UINT32 InFileAlloc;
UINT32 InFileCount;
IN_FILE_LIST* InFileList;

int main(int argc, char* argv[])
{
	int ErrVal;
	char FileName[0x100];
	
	printf("VGM RF-PCM Optimizer\n--------------------\n\n");
	
	ErrVal = 0;
	printf("File Name:\t");
	if (argc <= 0x01)
	{
		gets(FileName);
	}
	else
	{
		strcpy(FileName, argv[0x01]);
		printf("%s\n", FileName);
	}
	if (! strlen(FileName))
		return 1;
	
	if (! OpenVGMFile(FileName))
	{
		printf("Error opening the file!\n");
		ErrVal = 1;
		goto EndProgram;
	}
	printf("\n");
	
	DstData = NULL;
	if (VGMHead.lngVersion < 0x00000151)
	{
		printf("VGM Version %lX.%02hX!? Are kidding me??\n",
				VGMHead.lngVersion >> 8, VGMHead.lngVersion & 0xFF);
		ErrVal = 2;
		goto BreakProgress;
	}
	if (! VGMHead.lngHzRF5C68 && ! VGMHead.lngHzRF5C164)
	{
		printf("No RF-PCM chips used!\n");
		ErrVal = 2;
		goto BreakProgress;
	}
	
	CancelFlag = false;
	OptMode = 0x00;
	printf("Step 1: Merge single memory writes into larger blocks ...\n");
	MergePCMData();
	if (CancelFlag)
		goto BreakProgress;
	switch(OptMode)
	{
	case 0x00:	// 1 PCM block - remove unused space
		// this feature was planned and scrapped, because it's easier to implement in vgm_sro
		printf("This tool can only optimize PCM streams and this vgm has no PCM stream.\n");
		printf("You should try the VGM Sample-ROM Optimizer for further compression.\n");
		break;
	case 0x01:	// PCM stream - optimize this way
		//break;
		// Swap Pointers (I love C for this)
		free(VGMData);
		VGMData = DstData;
		DstData = NULL;
		
		printf("Step 2: Generate Block Data ...\n");
		EnumeratePCMData();
		if (CancelFlag)
			goto BreakProgress;
		printf("Step 3: Rewrite VGM with PCM database ...\n");
		RewriteVGMData();
		break;
	}
	printf("Data Compression: %lu -> %lu (%.1f %%)\n",
			DataSizeA, DataSizeB, 100.0f * DataSizeB / DataSizeA);
	
	if (DataSizeB < DataSizeA)
	{
		if (argc > 0x02)
			strcpy(FileName, argv[0x02]);
		else
			strcpy(FileName, "");
		if (! FileName[0x00])
		{
			strcpy(FileName, FileBase);
			strcat(FileName, "_optimized.vgm");
		}
		WriteVGMFile(FileName);
	}
	
BreakProgress:
	free(VGMData);
	free(DstData);
	
EndProgram:
#ifdef WIN32
	if (argv[0][1] == ':')
	{
		// Executed by Double-Clicking (or Drap and Drop)
		if (_kbhit())
			_getch();
		_getch();
	}
#endif
	
	return ErrVal;
}

static bool OpenVGMFile(const char* FileName)
{
	gzFile hFile;
	UINT32 CurPos;
	UINT32 TempLng;
	char* TempPnt;
	
	hFile = gzopen(FileName, "rb");
	if (hFile == NULL)
		return false;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &TempLng, 0x04);
	if (TempLng != FCC_VGM)
		goto OpenErr;
	
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, &VGMHead, sizeof(VGM_HEADER));
	
	// Header preperations
	if (VGMHead.lngVersion < 0x00000150)
	{
		VGMHead.lngDataOffset = 0x00000000;
	}
	if (VGMHead.lngVersion < 0x00000151)
	{
		VGMHead.lngHzSPCM = 0x0000;
		VGMHead.lngSPCMIntf = 0x00000000;
		// all others are zeroed by memset
	}
	// relative -> absolute addresses
	VGMHead.lngEOFOffset += 0x00000004;
	if (VGMHead.lngGD3Offset)
		VGMHead.lngGD3Offset += 0x00000014;
	if (VGMHead.lngLoopOffset)
		VGMHead.lngLoopOffset += 0x0000001C;
	if (! VGMHead.lngDataOffset)
		VGMHead.lngDataOffset = 0x0000000C;
	VGMHead.lngDataOffset += 0x00000034;
	
	CurPos = VGMHead.lngDataOffset;
	if (VGMHead.lngVersion < 0x00000151)
		CurPos = 0x40;
	TempLng = sizeof(VGM_HEADER);
	if (TempLng > CurPos)
		TempLng -= CurPos;
	else
		TempLng = 0x00;
	memset((UINT8*)&VGMHead + CurPos, 0x00, TempLng);
	
	// Read Data
	VGMDataLen = VGMHead.lngEOFOffset;
	VGMData = (UINT8*)malloc(VGMDataLen);
	if (VGMData == NULL)
		goto OpenErr;
	gzseek(hFile, 0x00, SEEK_SET);
	gzread(hFile, VGMData, VGMDataLen);
	
	gzclose(hFile);
	
	strcpy(FileBase, FileName);
	TempPnt = strrchr(FileBase, '.');
	if (TempPnt != NULL)
		*TempPnt = 0x00;
	
	return true;

OpenErr:

	gzclose(hFile);
	return false;
}

static void WriteVGMFile(const char* FileName)
{
	FILE* hFile;
	
	hFile = fopen(FileName, "wb");
	fwrite(DstData, 0x01, DstDataLen, hFile);
	fclose(hFile);
	
	printf("File written.\n");
	
	return;
}

static void MergePCMData(void)
{
	UINT32 DstPos;
	UINT32 CmdTimer;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 BlockLen;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	bool WriteEvent;
	UINT32 NewLoopS;
	RF_CHIP_DATA* TempRFD;
	UINT8 WarningFlags;
	UINT32 WriteLen;
	UINT32 BlkFound;
	
	DstData = (UINT8*)malloc(VGMDataLen + 0x100);
	VGMPos = VGMHead.lngDataOffset;
	DstPos = VGMHead.lngDataOffset;
	VGMSmplPos = 0;
	NewLoopS = 0x00;
	memcpy(DstData, VGMData, VGMPos);	// Copy Header
	
	memset(RF_RData, 0x00, sizeof(RF_CHIP_DATA) * 0x02);
	for (TempByt = 0x00; TempByt < 0x02; TempByt ++)
		RF_RData[TempByt].FirstBnkWrt = true;
	
	CmdTimer = 0;
	WarningFlags = 0x00;
	StopVGM = false;
	BlkFound = 0x00;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		WriteEvent = true;
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
			case 0x54:	// YM2151 write
			case 0x55:	// YM2203
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
			case 0x5A:	// YM3812 write
			case 0x5B:	// YM3526 write
			case 0x5C:	// Y8950 write
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
			case 0x5D:	// YMZ280B write
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&BlockLen, &VGMData[VGMPos + 0x03], 0x04);
				
				CmdLen = 0x07 + BlockLen;
				
				if ((TempByt & 0xC0) != 0xC0)
					break;
				TempByt &= ~0xC0;
				
				if (TempByt == RF5C68_MODE)
					TempRFD = &RF_RData[RF5C68_MODE];
				else if (TempByt == RF5C164_MODE)
					TempRFD = &RF_RData[RF5C164_MODE];
				else
					break;
				BlkFound ++;
				if (! TempRFD->RAMSkip)
				{
					TempRFD->DataLen = ReadConsecutiveMemWrites(TempByt);
					if (TempRFD->DataLen > 0x01)
					{
						TempRFD->RAMSkip = TempRFD->DataLen;
						memcpy(&TempSht, &VGMData[VGMPos + 0x07], 0x02);
						TempSht += TempRFD->BankReg;
						TempRFD->RAMStart = TempSht;
						
						if (BLOCK_POS == BP_FRONT)
						{
							while(TempRFD->DataLen)
							{
								if (TempRFD->DataLen > 0x1000)
									WriteLen = 0x1000;
								else
									WriteLen = TempRFD->DataLen;
								
								DstData[DstPos + 0x00] = 0x67;
								DstData[DstPos + 0x01] = 0x66;
								DstData[DstPos + 0x02] = 0xC0 | TempByt;
								TempLng = WriteLen + 0x02;
								memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
								
								memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
								memcpy(&DstData[DstPos + 0x09], TempRFD->PCMRam + TempSht,
																					WriteLen);
								DstPos += 0x07 + TempLng;
								TempSht += (UINT16)WriteLen;
								TempRFD->DataLen -= WriteLen;
							}
						}
					}
				}
				if (TempRFD->RAMSkip)
				{
					DataLen = BlockLen - 0x02;
					
					if ((BLOCK_POS == BP_BACK && ! TempRFD->RAMSkip) ||
						(BLOCK_POS == BP_MIDDLE &&
							(TempRFD->RAMSkip >= TempRFD->DataLen / 2 &&
							TempRFD->RAMSkip - DataLen < TempRFD->DataLen / 2)))
					{
						TempSht = TempRFD->RAMStart;
						while(TempRFD->DataLen)
						{
							if (TempRFD->DataLen > 0x1000)
								WriteLen = 0x1000;
							else
								WriteLen = TempRFD->DataLen;
							
							DstData[DstPos + 0x00] = 0x67;
							DstData[DstPos + 0x01] = 0x66;
							DstData[DstPos + 0x02] = 0xC0 | TempByt;
							TempLng = WriteLen + 0x02;
							memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
							
							memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
							memcpy(&DstData[DstPos + 0x09], TempRFD->PCMRam + TempSht,
																					WriteLen);
							DstPos += 0x07 + TempLng;
							TempSht += (UINT16)WriteLen;
							TempRFD->DataLen -= WriteLen;
						}
					}
					
					WriteEvent = false;
					TempRFD->RAMSkip -= DataLen;
				}
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0xC0:	// Sega PCM memory write
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
			case 0xB1:	// RF5C164 register write
				CmdLen = 0x03;
				
				if (VGMData[VGMPos + 0x01] == 0x07 && ! (VGMData[VGMPos + 0x02] & 0x40))
				{
					if (Command == 0xB0)
						TempRFD = &RF_RData[RF5C68_MODE];
					else if (Command == 0xB1)
						TempRFD = &RF_RData[RF5C164_MODE];
					else
						TempRFD = NULL;
					
					// Bank Select
					TempRFD->BankReg = (VGMData[VGMPos + 0x02] & 0x0F) << 12;
				
					// write Bank Select just one time, the memory write includes all
					// neccessary data
					if (TempRFD->FirstBnkWrt)
					{
						VGMData[VGMPos + 0x02] &= ~0x0F;
						WriteEvent = true;
						TempRFD->FirstBnkWrt = false;
					}
					else
					{
						WriteEvent = false;
					}
				}
				break;
			case 0xC1:	// RF5C68 memory write
			case 0xC2:	// RF5C164 memory write
				CmdLen = 0x04;
				
				if (Command == 0xC1)
				{
					TempByt = RF5C68_MODE;
					TempRFD = &RF_RData[RF5C68_MODE];
				}
				else if (Command == 0xC2)
				{
					TempByt = RF5C164_MODE;
					TempRFD = &RF_RData[RF5C164_MODE];
				}
				else
				{
					TempByt = 0x00;
					TempRFD = NULL;
				}
				BlkFound ++;
				if (! TempRFD->RAMSkip)
				{
					TempRFD->DataLen = ReadConsecutiveMemWrites(TempByt);
					if (TempRFD->DataLen > 0x01)
					{
						TempRFD->RAMSkip = TempRFD->DataLen;
						memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
						TempSht += TempRFD->BankReg;
						TempRFD->RAMStart = TempSht;
						
						if (BLOCK_POS == BP_FRONT)
						{
							DstData[DstPos + 0x00] = 0x67;
							DstData[DstPos + 0x01] = 0x66;
							DstData[DstPos + 0x02] = 0xC0 | TempByt;
							TempLng = TempRFD->DataLen + 0x02;
							memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
							
							memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
							memcpy(&DstData[DstPos + 0x09], TempRFD->PCMRam + TempSht,
																			TempRFD->DataLen);
							DstPos += 0x07 + TempLng;
						}
					}
					else if (! (WarningFlags & 0x01))
					{
						WarningFlags |= 0x01;
						printf("\t\t\t\t\t\t\t\t\r");	CmdTimer = 0;
						printf("Warning! Single Memory Writes left!\n");
					}
				}
				if (TempRFD->RAMSkip)
				{
					if ((BLOCK_POS == BP_BACK && ! TempRFD->RAMSkip) ||
						(BLOCK_POS == BP_MIDDLE && TempRFD->RAMSkip * 2 == TempRFD->DataLen))
					{
						TempSht = TempRFD->RAMStart;
						DstData[DstPos + 0x00] = 0x67;
						DstData[DstPos + 0x01] = 0x66;
						DstData[DstPos + 0x02] = 0xC0 | TempByt;
						TempLng = TempRFD->DataLen + 0x02;
						memcpy(&DstData[DstPos + 0x03], &TempLng, 0x04);
						
						memcpy(&DstData[DstPos + 0x07], &TempSht, 0x02);
						memcpy(&DstData[DstPos + 0x09], TempRFD->PCMRam + TempSht,
																			TempRFD->DataLen);
						DstPos += 0x07 + TempLng;
					}
					
					WriteEvent = false;
					TempRFD->RAMSkip --;
				}
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				//break;
				printf("\t\t\t\t\t\t\t\t\r");	CmdTimer = 0;
				printf("VGM already optimized!\n");
				CancelFlag = true;
				return;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					printf("\t\t\t\t\t\t\t\t\r");	CmdTimer = 0;
					printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		if (VGMPos == VGMHead.lngLoopOffset)
			NewLoopS = DstPos;
		if (WriteEvent)
		{
			memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
			DstPos += CmdLen;
		}
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			BlockLen = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / BlockLen * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	printf("\t\t\t\t\t\t\t\t\r");
	DataSizeA = VGMPos - VGMHead.lngDataOffset;
	if (VGMHead.lngLoopOffset)
	{
		VGMHead.lngLoopOffset = NewLoopS;
		if (! NewLoopS)
			printf("Error! Failed to relocate Loop Point!\n");
		else
			NewLoopS -= 0x1C;
		memcpy(&DstData[0x1C], &NewLoopS, 0x04);
	}
	
	if (VGMHead.lngGD3Offset)
	{
		VGMPos = VGMHead.lngGD3Offset;
		memcpy(&TempLng, &VGMData[VGMPos + 0x00], 0x04);
		if (TempLng == FCC_GD3)
		{
			memcpy(&CmdLen, &VGMData[VGMPos + 0x08], 0x04);
			CmdLen += 0x0C;
			
			VGMHead.lngGD3Offset = DstPos;
			TempLng = VGMHead.lngGD3Offset - 0x14;
			memcpy(&DstData[0x14], &TempLng, 0x04);
			memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
			DstPos += CmdLen;
		}
	}
	DstDataLen = DstPos;
	VGMHead.lngEOFOffset = DstDataLen;
	TempLng = VGMHead.lngEOFOffset - 0x04;
	memcpy(&DstData[0x04], &TempLng, 0x04);
	
	OptMode = (BlkFound == 0x01) ? 0x00 : 0x01;
	
	return;
}

static UINT32 ReadConsecutiveMemWrites(UINT8 RFMode)
{
	RF_CHIP_DATA* TempRFD;
	UINT32 TmpPos;
	UINT32 PCMPos;
	UINT32 DataLen;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 CmdLen;
	bool StopVGM;
	UINT16 BankReg;	// this function mustn't change the global one
	
	TempRFD = &RF_RData[RFMode];
	TmpPos = VGMPos;
	BankReg = TempRFD->BankReg;
	PCMPos = 0xFFFFFFFF;
	DataLen = 0x00;
	
	StopVGM = false;
	while(TmpPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[TmpPos + 0x00];
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
				CmdLen = 0x03;
				break;
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[TmpPos + 0x02];
				memcpy(&TempLng, &VGMData[TmpPos + 0x03], 0x04);
				
				CmdLen = 0x07 + TempLng;
				
				if ((TempByt & 0xC0) != 0xC0)
					break;
				TempByt &= ~0xC0;
				
				if (TempByt != RFMode)
					break;
				
				memcpy(&TempSht, &VGMData[TmpPos + 0x07], 0x02);
				TempSht += BankReg;
				if (PCMPos == 0xFFFFFFFF)
					PCMPos = TempSht;
				if (TempSht != PCMPos)
				{
					StopVGM = true;
					break;
				}
				
				TempLng -= 0x02;
				if (TempLng > 0x10000)
					TempLng = 0x10000;
				memcpy(&TempRFD->PCMRam[PCMPos], &VGMData[TmpPos + 0x09], TempLng);
				PCMPos += TempLng;
				DataLen += TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x54:	// YM2151 write
				CmdLen = 0x03;
				break;
			case 0xC0:	// Sega PCM memory write
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
			case 0xB1:	// RF5C164 register write
				CmdLen = 0x03;
				if ((Command == 0xB0 && RFMode != RF5C68_MODE) ||
					(Command == 0xB1 && RFMode != RF5C164_MODE))
					break;
				
				if (VGMData[TmpPos + 0x01] == 0x07 && ! (VGMData[TmpPos + 0x02] & 0x40))
				{
					// Bank Select
					//StopVGM = true;
					BankReg = (VGMData[TmpPos + 0x02] & 0x0F) << 12;
				}
				break;
			case 0xC1:	// RF5C68 memory write
			case 0xC2:	// RF5C164 memory write
				CmdLen = 0x04;
				if ((Command == 0xC1 && RFMode != RF5C68_MODE) ||
					(Command == 0xC2 && RFMode != RF5C164_MODE))
					break;
				
				memcpy(&TempSht, &VGMData[TmpPos + 0x01], 0x02);
				TempSht += BankReg;
				if (PCMPos == 0xFFFFFFFF)
					PCMPos = TempSht;
				if (TempSht != PCMPos)
				{
					StopVGM = true;
					break;
				}
				
				TempRFD->PCMRam[PCMPos] = VGMData[TmpPos + 0x03];
				PCMPos ++;
				DataLen ++;
				//if (! (PCMPos & 0xFFF))
				//	StopVGM = true;
				break;
			case 0x55:	// YM2203
				CmdLen = 0x03;
				break;
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
				CmdLen = 0x03;
				break;
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
				CmdLen = 0x03;
				break;
			case 0x5A:	// YM3812 write
				CmdLen = 0x03;
				break;
			case 0x5B:	// YM3526 write
				CmdLen = 0x03;
				break;
			case 0x5C:	// Y8950 write
				CmdLen = 0x03;
				break;
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
				CmdLen = 0x03;
				break;
			case 0x5D:	// YMZ280B write
				CmdLen = 0x03;
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					//printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		TmpPos += CmdLen;
		if (StopVGM || PCMPos >= 0x10000)
			break;
	}
	
	return DataLen;
}

static void EnumeratePCMData(void)
{
	UINT32 CmdTimer;
	UINT8 Command;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 BlockLen;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	UINT32 CurBlk;
	bool FoundBlk;
	RF_BLK_DATA* TempBlk;
	IN_FILE_LIST* TempLst;
	UINT32 BlkUsage;
	UINT32 BlkSize;
	UINT32 BlkSngUse;
	
	RFBlkAlloc = 0x40;	// usually there are only few blocks ...
	RFBlock = (RF_BLK_DATA*)malloc(RFBlkAlloc * sizeof(RF_BLK_DATA));
	RFBlkCount = 0x00;
	InFileAlloc = 0x8000;	// ... but block usage is very high
	InFileList = (IN_FILE_LIST*)malloc(InFileAlloc * sizeof(IN_FILE_LIST));
	InFileCount = 0x00;
	BlkUsage = BlkSize = 0x00;
	
	VGMPos = VGMHead.lngDataOffset;
	VGMSmplPos = 0;
	
	CmdTimer = 0;
	StopVGM = false;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdLen = 0x01;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdLen = 0x03;
				break;
			case 0x50:	// SN76496 write
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
			case 0x54:	// YM2151 write
			case 0x55:	// YM2203
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
			case 0x5A:	// YM3812 write
			case 0x5B:	// YM3526 write
			case 0x5C:	// Y8950 write
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
			case 0x5D:	// YMZ280B write
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&BlockLen, &VGMData[VGMPos + 0x03], 0x04);
				
				CmdLen = 0x07 + BlockLen;
				
				if ((TempByt & 0xC0) != 0xC0)
					break;
				TempByt &= ~0xC0;
				
				if (TempByt != RF5C68_MODE && TempByt != RF5C164_MODE)
					break;
				
				memcpy(&TempSht, &VGMData[VGMPos + 0x07], 0x02);
				DataLen = BlockLen - 0x02;
				FoundBlk = false;
				for (CurBlk = 0x00; CurBlk < RFBlkCount; CurBlk ++)
				{
					TempBlk = &RFBlock[CurBlk];
					if (TempBlk->Mode != TempByt)
						continue;
					
					//if (TempBlk->DataStart != TempSht)
					//	break;
					if (TempBlk->DataSize < DataLen)
						TempLng = TempBlk->DataSize;
					else
						TempLng = DataLen;
					
					if (CompareData(TempLng, &VGMData[VGMPos + 0x09], TempBlk->Data))
					{
						if (TempBlk->DataSize < DataLen)
						{
							// expand block with additional data
							BlkSize -= TempBlk->DataSize;
							TempBlk->DataSize = DataLen;
							TempBlk->Data = (UINT8*)realloc(TempBlk->Data, DataLen);
							memcpy(TempBlk->Data, &VGMData[VGMPos + 0x09], DataLen);
							BlkSize += DataLen;
						}
						
						if (InFileCount >= InFileAlloc)
						{
							InFileAlloc += 0x1000;
							InFileList = (IN_FILE_LIST*)realloc(InFileList,
															InFileAlloc * sizeof(IN_FILE_LIST));
						}
						TempLst = &InFileList[InFileCount];
						TempLst->BlockID = CurBlk;
						TempLst->FilePos = VGMPos;
						TempLst->StartAddr = TempSht;
						TempLst->DataSize = DataLen;
						TempBlk->UsageCounter ++;
						InFileCount ++;
						BlkUsage ++;
						
						FoundBlk = true;
					}
				}
				if (! FoundBlk)
				{
					if (RFBlkCount >= RFBlkAlloc)
					{
						RFBlkAlloc += 0x40;
						RFBlock = (RF_BLK_DATA*)realloc(RFBlock,
														RFBlkAlloc * sizeof(RF_BLK_DATA));
					}
					
					TempBlk = &RFBlock[RFBlkCount];
					RFBlkCount ++;
					
					TempBlk->Mode = TempByt;
					TempBlk->DataSize = DataLen;
					TempBlk->Data = (UINT8*)malloc(DataLen);
					memcpy(TempBlk->Data, &VGMData[VGMPos + 0x09], DataLen);
					TempBlk->UsageCounter = 0x00;
					BlkSize += DataLen;
					
					if (InFileCount >= InFileAlloc)
					{
						InFileAlloc += 0x1000;
						InFileList = (IN_FILE_LIST*)malloc(InFileAlloc * sizeof(IN_FILE_LIST));
					}
					TempLst = &InFileList[InFileCount];
					TempLst->BlockID = CurBlk;
					TempLst->FilePos = VGMPos;
					TempLst->StartAddr = TempSht;
					TempLst->DataSize = DataLen;
					TempBlk->UsageCounter ++;
					InFileCount ++;
					BlkUsage ++;
				}
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0xC0:	// Sega PCM memory write
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
			case 0xB1:	// RF5C164 register write
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
			case 0xC2:	// RF5C164 memory write
				CmdLen = 0x04;
				// this time they are ignored
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					//printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		VGMPos += CmdLen;
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			BlockLen = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / BlockLen * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	printf("\t\t\t\t\t\t\t\t\r");
	
	BlkSngUse = 0x00;
	for (CurBlk = 0x00; CurBlk < RFBlkCount; CurBlk ++)
	{
		TempBlk = &RFBlock[CurBlk];
		if (TempBlk->UsageCounter == 0x01)
		{
			TempBlk->Mode |= 0x80;	// mark the block, so that the PCM bank doesn't include it
			BlkSngUse ++;
		}
	}
	
	printf("%lu Blocks created (%.2f MB, %lux used, %lux single use).\n",
			RFBlkCount, BlkSize / 1048576.0f, BlkUsage, BlkSngUse);
	if (BlkUsage == BlkSngUse)
	{
		printf("Can't optimize further.\n");
		CancelFlag = true;
	}
	
	return;
}

static bool CompareData(UINT32 DataLen, const UINT8* DataA,
						const UINT8* DataB)
{
	UINT32 CurPos;
	const UINT8* TempDA;
	const UINT8* TempDB;
	
	TempDA = DataA;
	TempDB = DataB;
	for (CurPos = 0x00; CurPos < DataLen; CurPos ++, TempDA ++, TempDB ++)
	{
		if (*TempDA != *TempDB)
			return false;
	}
	
	return true;
}

static void RewriteVGMData(void)
{
	UINT32 DstPos;
	UINT32 CurType;
	UINT32 CurBlk;
	UINT32 CurEntry;
	UINT32 CmdTimer;
	UINT8 Command;
	UINT32 CmdDelay;
	UINT32 AllDelay;
	UINT8 TempByt;
	UINT16 TempSht;
	UINT32 TempLng;
	UINT32 DataLen;
	char TempStr[0x80];
	char MinSecStr[0x80];
	UINT32 CmdLen;
	bool StopVGM;
	bool WriteEvent;
	UINT32 NewLoopS;
	RF_BLK_DATA* TempBlk;
	IN_FILE_LIST* TempLst;
	bool WriteCmd68;
	
	DstData = (UINT8*)malloc(VGMDataLen + 0x100);
	AllDelay = 0;
	VGMPos = VGMHead.lngDataOffset;
	DstPos = VGMHead.lngDataOffset;
	VGMSmplPos = 0;
	NewLoopS = 0x00;
	memcpy(DstData, VGMData, VGMPos);	// Copy Header
	
	// Write Blocks for PCM Data
	for (CurType = 0x00; CurType < 0x02; CurType ++)
	{
		switch(CurType)
		{
		case 0x00:
			TempByt = RF5C68_MODE;
			break;
		case 0x01:
			TempByt = RF5C164_MODE;
			break;
		default:
			TempByt = 0xFF;
			break;
		}
		if (TempByt == 0xFF)
			break;
		
		DataLen = 0x00;
		for (CurBlk = 0x00; CurBlk < RFBlkCount; CurBlk ++)
		{
			TempBlk = &RFBlock[CurBlk];
			if (TempBlk->Mode != TempByt)
				continue;
			
			TempBlk->DBPos = DataLen;
			DataLen += TempBlk->DataSize;
		}
		if (DataLen)
		{
			DstData[DstPos + 0x00] = 0x67;
			DstData[DstPos + 0x01] = 0x66;
			DstData[DstPos + 0x02] = 0x01 + TempByt;
			memcpy(&DstData[DstPos + 0x03], &DataLen, 0x04);
			DstPos += 0x07;
			
			for (CurBlk = 0x00; CurBlk < RFBlkCount; CurBlk ++)
			{
				TempBlk = &RFBlock[CurBlk];
				if (TempBlk->Mode != TempByt)
					continue;
				
				memcpy(&DstData[DstPos + 0x00], TempBlk->Data, TempBlk->DataSize);
				DstPos += TempBlk->DataSize;
			}
		}
	}
	
	CmdTimer = 0;
	StopVGM = false;
	WriteCmd68 = false;
	CurEntry = 0x00;
	while(VGMPos < VGMHead.lngEOFOffset)
	{
		CmdDelay = 0;
		CmdLen = 0x00;
		Command = VGMData[VGMPos + 0x00];
		WriteEvent = true;
		
		if (Command >= 0x70 && Command <= 0x8F)
		{
			switch(Command & 0xF0)
			{
			case 0x70:
				TempSht = (Command & 0x0F) + 0x01;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				WriteEvent = false;
				break;
			case 0x80:
				TempSht = Command & 0x0F;
				VGMSmplPos += TempSht;
				//CmdDelay = TempSht;
				break;
			}
			CmdLen = 0x01;
		}
		else
		{
			switch(Command)
			{
			case 0x66:	// End Of File
				CmdLen = 0x01;
				StopVGM = true;
				break;
			case 0x62:	// 1/60s delay
				TempSht = 735;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x01;
				WriteEvent = false;
				break;
			case 0x63:	// 1/50s delay
				TempSht = 882;
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x01;
				WriteEvent = false;
				break;
			case 0x61:	// xx Sample Delay
				memcpy(&TempSht, &VGMData[VGMPos + 0x01], 0x02);
				VGMSmplPos += TempSht;
				CmdDelay = TempSht;
				CmdLen = 0x03;
				WriteEvent = false;
				break;
			case 0x50:	// SN76496 write
			case 0x4F:	// GG Stereo
				CmdLen = 0x02;
				break;
			case 0x51:	// YM2413 write
			case 0x52:	// YM2612 write port 0
			case 0x53:	// YM2612 write port 1
			case 0x54:	// YM2151 write
			case 0x55:	// YM2203
			case 0x56:	// YM2608 write port 0
			case 0x57:	// YM2608 write port 1
			case 0x58:	// YM2610 write port 0
			case 0x59:	// YM2610 write port 1
			case 0x5A:	// YM3812 write
			case 0x5B:	// YM3526 write
			case 0x5C:	// Y8950 write
			case 0x5E:	// YMF262 write port 0
			case 0x5F:	// YMF262 write port 1
			case 0x5D:	// YMZ280B write
				CmdLen = 0x03;
				break;
			case 0x67:	// PCM Data Stream
				TempByt = VGMData[VGMPos + 0x02];
				memcpy(&TempLng, &VGMData[VGMPos + 0x03], 0x04);
				
				switch(TempByt & 0xC0)
				{
				case 0x00:	// Database Block
				case 0x40:
					switch(TempByt)
					{
					case 0x00:	// YM2612 PCM Data
						break;
					case 0x01:
					case 0x02:
						WriteEvent = false;
						break;
					}
					break;
				case 0x80:	// ROM/RAM Dump
					break;
				case 0xC0:	// RAM Write
					switch(TempByt)
					{
					case 0xC0:
					case 0xC1:
						while(CurEntry < InFileCount)
						{
							TempLst = &InFileList[CurEntry];
							if (TempLst->FilePos > VGMPos)
							{
								break;
							}
							else if (TempLst->FilePos == VGMPos)
							{
								TempBlk = &RFBlock[TempLst->BlockID];
								if (TempBlk->Mode & 0x80)
									break;	// Single-Use Blocks are left
								
								CurEntry ++; 
								WriteEvent = false;
								// writing the block here would cause some sort of bug, because
								// I would miss the delay
								WriteCmd68 = true;
								break;
							}
							CurEntry ++; 
						}
						break;
					}
					break;
				default:
					break;
				}
				CmdLen = 0x07 + TempLng;
				break;
			case 0xE0:	// Seek to PCM Data Bank Pos
				CmdLen = 0x05;
				break;
			case 0xC0:	// Sega PCM memory write
				CmdLen = 0x04;
				break;
			case 0xB0:	// RF5C68 register write
			case 0xB1:	// RF5C164 register write
				CmdLen = 0x03;
				break;
			case 0xC1:	// RF5C68 memory write
			case 0xC2:	// RF5C164 memory write
				CmdLen = 0x04;
				break;
			case 0x68:	// PCM RAM write
				CmdLen = 0x0C;
				break;
			default:
				switch(Command & 0xF0)
				{
				case 0x30:
				case 0x40:
					CmdLen = 0x02;
					break;
				case 0x50:
				case 0xA0:
				case 0xB0:
					CmdLen = 0x03;
					break;
				case 0xC0:
				case 0xD0:
					CmdLen = 0x04;
					break;
				case 0xE0:
				case 0xF0:
					CmdLen = 0x05;
					break;
				default:
					//printf("Unknown Command: %hX\n", Command);
					CmdLen = 0x01;
					//StopVGM = true;
					break;
				}
				break;
			}
		}
		
		if (WriteEvent || WriteCmd68 || VGMPos == VGMHead.lngLoopOffset)
		{
			if (VGMPos != VGMHead.lngLoopOffset)
			{
				AllDelay += CmdDelay;
				CmdDelay = 0x00;
			}
			while(AllDelay || CmdDelay)
			{
				if (! AllDelay && CmdDelay)
				{
					AllDelay += CmdDelay;
					CmdDelay = 0x00;
					if (VGMPos == VGMHead.lngLoopOffset)
						NewLoopS = DstPos;
				}
				
				if (AllDelay <= 0xFFFF)
					TempSht = (UINT16)AllDelay;
				else
					TempSht = 0xFFFF;
				
				if (! TempSht)
				{
					// don't do anything - I just want to be safe
				}
				if (TempSht <= 0x10)
				{
					DstData[DstPos] = 0x70 | (TempSht - 0x01);
					DstPos ++;
				}
				else if (TempSht <= 0x20)
				{
					DstData[DstPos] = 0x7F;
					DstPos ++;
					DstData[DstPos] = 0x70 | (TempSht - 0x11);
					DstPos ++;
				}
				else if ((TempSht >=  735 && TempSht <=  751) ||
						 (TempSht >= 1470 && TempSht <= 1486))
				{
					TempLng = TempSht;
					while(TempLng >= 735)
					{
						DstData[DstPos] = 0x62;
						DstPos ++;
						TempLng -= 735;
					}
					TempSht -= (UINT16)TempLng;
				}
				else if ((TempSht >=  882 && TempSht <=  898) ||
						 (TempSht >= 1764 && TempSht <= 1780))
				{
					TempLng = TempSht;
					while(TempLng >= 882)
					{
						DstData[DstPos] = 0x63;
						DstPos ++;
						TempLng -= 882;
					}
					TempSht -= (UINT16)TempLng;
				}
				else if (TempSht == 1617)
				{
					DstData[DstPos] = 0x63;
					DstPos ++;
					DstData[DstPos] = 0x62;
					DstPos ++;
				}
				else
				{
					DstData[DstPos + 0x00] = 0x61;
					memcpy(&DstData[DstPos + 0x01], &TempSht, 0x02);
					DstPos += 0x03;
				}
				AllDelay -= TempSht;
			}
			
			if (WriteEvent)
			{
				if (VGMPos == VGMHead.lngLoopOffset)
					NewLoopS = DstPos;
				memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
				DstPos += CmdLen;
			}
		}
		else
		{
			AllDelay += CmdDelay;
		}
		VGMPos += CmdLen;
		
		if (WriteCmd68)
		{
			WriteCmd68 = false;
			DstData[DstPos + 0x00] = 0x68;
			DstData[DstPos + 0x01] = 0x66;
			DstData[DstPos + 0x02] = 0x01 + TempBlk->Mode;
			memcpy(&DstData[DstPos + 0x03], &TempBlk->DBPos,		0x03);
			memcpy(&DstData[DstPos + 0x06], &TempLst->StartAddr,	0x03);
			memcpy(&DstData[DstPos + 0x09], &TempLst->DataSize,		0x03);
			DstPos += 0x0C;
		}
		if (StopVGM)
			break;
		
		if (CmdTimer < GetTickCount())
		{
			PrintMinSec(VGMSmplPos, MinSecStr);
			PrintMinSec(VGMHead.lngTotalSamples, TempStr);
			TempLng = VGMPos - VGMHead.lngDataOffset;
			DataLen = VGMHead.lngEOFOffset - VGMHead.lngDataOffset;
			printf("%04.3f %% - %s / %s (%08lX / %08lX) ...\r", (float)TempLng / DataLen * 100,
					MinSecStr, TempStr, VGMPos, VGMHead.lngEOFOffset);
			CmdTimer = GetTickCount() + 200;
		}
	}
	printf("\t\t\t\t\t\t\t\t\r");
	DataSizeB = DstPos - VGMHead.lngDataOffset;
	if (VGMHead.lngLoopOffset)
	{
		VGMHead.lngLoopOffset = NewLoopS;
		if (! NewLoopS)
			printf("Error! Failed to relocate Loop Point!\n");
		else
			NewLoopS -= 0x1C;
		memcpy(&DstData[0x1C], &NewLoopS, 0x04);
	}
	
	if (VGMHead.lngGD3Offset)
	{
		VGMPos = VGMHead.lngGD3Offset;
		memcpy(&TempLng, &VGMData[VGMPos + 0x00], 0x04);
		if (TempLng == FCC_GD3)
		{
			memcpy(&CmdLen, &VGMData[VGMPos + 0x08], 0x04);
			CmdLen += 0x0C;
			
			VGMHead.lngGD3Offset = DstPos;
			TempLng = VGMHead.lngGD3Offset - 0x14;
			memcpy(&DstData[0x14], &TempLng, 0x04);
			memcpy(&DstData[DstPos], &VGMData[VGMPos], CmdLen);
			DstPos += CmdLen;
		}
	}
	DstDataLen = DstPos;
	VGMHead.lngEOFOffset = DstDataLen;
	TempLng = VGMHead.lngEOFOffset - 0x04;
	memcpy(&DstData[0x04], &TempLng, 0x04);
	
	if (VGMHead.lngVersion < 0x00000160)
	{
		VGMHead.lngVersion = 0x00000160;
		memcpy(&DstData[0x08], &VGMHead.lngVersion, 0x04);
	}
	
	return;
}

static void PrintMinSec(const UINT32 SamplePos, char* TempStr)
{
	float TimeSec;
	UINT16 TimeMin;
	
	TimeSec = (float)SamplePos / (float)44100.0;
	TimeMin = (UINT16)TimeSec / 60;
	TimeSec -= TimeMin * 60;
	sprintf(TempStr, "%02hu:%05.2f", TimeMin, TimeSec);
	
	return;
}
